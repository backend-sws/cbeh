<?php

namespace App\Http\Controllers;

use App\Events\PaymentCollectionEvent;
use App\Models\User;
use Barryvdh\DomPDF\PDF;
use App\Models\Diagnosis;
use App\Models\OpdPatient;
use Illuminate\Http\Request;
use App\Models\OpdDiagnosisTest;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class OpdPatientController extends Controller
{


    public function index(Request $request)
    {
        $perPage = $request->input('perPage', 5);

        $search = $request->input('search');
        $doctor_id = $request->input('doctor_id');
        $from_date = $request->input('from_date');
        $to_date = $request->input('to_date');

        $query = OpdPatient::with('doctor', 'patient');
        // dd($query);

        // Search by patient name OR OPD No
        if ($search) {
            $query->where(function ($q) use ($search) {
                $q->whereHas('patient', function ($q2) use ($search) {
                    $q2->where('name', 'like', "%$search%");
                })
                    ->orWhere('opd_no', 'like', "%$search%")
                    ->orWhere('patient_unique_id', 'like', "%$search%"); // <-- Add this line
            });
        }

        if ($doctor_id) {
            $query->where('doctor_id', $doctor_id);
        }
        if ($from_date) {
            $query->whereDate('appointment_date', '>=', $from_date);
        }
        if ($to_date) {
            $query->whereDate('appointment_date', '<=', $to_date);
        }

        // Default sorting by latest
        $query->orderBy('id', 'desc');

        $opd_patients = $query->paginate($perPage);
        // dd($opd_patients);

        $doctors = User::role('Doctor')->select('id', 'name')->get();

        return view('opd.opdpatient', compact('opd_patients', 'doctors', 'search', 'doctor_id', 'from_date', 'to_date'));
    }
    public function add_opd_patient()
    {
        $doctors = User::role('Doctor')->select('id', 'name', 'email')->get();
        //   dd($doctors);
        // Sare patients lao
         $patients = User::role('Patient')->select('id', 'name', 'email')->orderBy('id', 'desc')->get();


        // dd($patients);
        return view('opd.new-opdpatient', compact('patients', 'doctors'));
    }
    public function edit_ipd_patient($id)
    {
        $patient = OpdPatient::where('id', $id)->first();
        if ($patient) {
            $doctors = User::role('Doctor')->select('id', 'name', 'email')->get();
            $patients = User::role('Patient')->select('id', 'name', 'email')->get();
            return view('opd.edit-opdpatient', compact('patient', 'id', 'patients', 'doctors'));
        } else {
            return redirect()->back();
        }
    }



    public function opd_patient_save(Request $request)
    {
        try {
            // Validate the incoming request
            $validator = Validator::make($request->all(), [
                'patient' => 'required',
                'case' => 'nullable|string|max:255',
                'opd_no' => 'required|string|max:255|unique:opd_patients,opd_no',
                'height' => 'nullable|numeric|min:0',
                'weight' => 'nullable|numeric|min:0',
                'casuality' => 'nullable|string|max:255',
                'reference' => 'nullable|string|max:255',
                'blood_pressure' => 'nullable|string|max:50',
                'symptoms' => 'nullable|string|max:1000',
                'notes' => 'nullable|string|max:1000',
                'appointment_date' => 'required|date',
                'doctor' => 'required|exists:users,id',
                'standard_charge' => 'required|numeric|min:0',
                'tax' => 'nullable|numeric|min:0',
                'discount' => 'nullable|numeric|min:0',
                'final_amount' => 'required|numeric|min:0',
                'payment_mode' => 'required|string|max:100',
                'is_old_patient' => 'required|boolean',
                'bp' => 'nullable|string|max:100',
                'SpO2' => 'nullable|string|max:100',
                'pulse' => 'nullable|string', // New field for pulse
                'temperature' => 'nullable|string', // New field for temperature
                // 'age' => 'nullable|string|max:50', // Optional field for age
                // 'invoice_no' => 'nullable|string|max:50', // Optional field for invoice number
            ]);

            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            DB::beginTransaction();

            $invoice_no = 'INV' . date('YmdHis') . mt_rand(100, 999);

            // Calculate tax/discount amount if needed (already calculated in JS, but double-check)
            $charge = floatval($request->standard_charge);
            $taxPercent = floatval($request->tax);
            $discountPercent = floatval($request->discount);
            $taxAmount = ($charge * $taxPercent) / 100;
            $discountAmount = ($charge * $discountPercent) / 100;
            $finalAmount = $charge + $taxAmount - $discountAmount;


            $patient_unique_id = DB::table('patients')
                ->where('user_id', $request->patient)
                ->value('patient_unique_id');

            // Create a new OPD Patient record
            $opdPatient = OpdPatient::create([
                'patient_id' => $request->patient,
                'patient_unique_id' => $patient_unique_id, // Store the patient's unique ID
                'case' => $request->case,
                'opd_no' => $request->opd_no,
                'height' => $request->height,
                'weight' => $request->weight,
                'casuality' => $request->casuality,
                'reference' => $request->reference,
                'blood_pressure' => $request->blood_pressure,
                'symptoms' => $request->symptoms,
                'notes' => $request->notes,
                'appointment_date' => $request->appointment_date,
                'doctor_id' => $request->doctor,
                'standard_charge' => $charge,
                'tax' => $taxPercent,
                'discount' => $discountPercent,
                'final_amount' => $finalAmount,
                'payment_mode' => $request->payment_mode,
                'is_old_patient' => $request->is_old_patient,
                'bp' => $request->bp,
                'SpO2' => $request->SpO2,
                'pulse' => $request->pulse, // Store pulse
                'temperature' => $request->temperature, // Store temperature
                'invoice_no' => $invoice_no, // Store the generated invoice number
            ]);



            $data = new \stdClass();
            $data->amount = $finalAmount;
            $data->payment_mode_id = $request->payment_mode;
            $data->patient_id = $request->patient;

            // dd($data);
            DB::commit();


            event(new PaymentCollectionEvent($data, 'Opd New Payment', 1));

            // Decide redirect route based on action
            if ($request->input('action') === 'save_print') {
                $redirect_to = route('admin.opd.print', $opdPatient->id);
            } else {
                $redirect_to = route('admin.opd.index');
            }

            return redirect($redirect_to)->with('success', 'OPD Patient Record Saved Successfully!');
        } catch (\Throwable $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('error', 'An error occurred while saving the OPD Patient record! ' . $e->getMessage())
                ->withInput();
        }
    }

    public function opd_patient_edit_save(Request $request, $id)
    {
        try {
            // Validate the incoming request
            $validator = Validator::make($request->all(), [
                'patient' => 'required',
                'case' => 'nullable|string|max:255',
                'opd_no' => "required|string|max:255|unique:opd_patients,opd_no,$id,id", // Ensure opd_no is unique, excluding current record
                'height' => 'nullable|numeric|min:0',
                'weight' => 'nullable|numeric|min:0',
                'blood_pressure' => 'nullable|string|max:50',
                'symptoms' => 'nullable|string|max:1000',
                'notes' => 'nullable|string|max:1000',
                'appointment_date' => 'required|date',
                'doctor' => "required|exists:users,id", // Ensure doctor exists in the users table
                'standard_charge' => 'required|numeric|min:0',
                'payment_mode' => 'required|string|max:100',
                'is_old_patient' => 'required|boolean',
                'bp' => 'nullable|string|max:100',
                'SpO2' => 'nullable|string|max:100',
                'pulse' => 'nullable|string|max:50',
                'temperature' => 'nullable|string|max:50',
            ]);

            // Check if validation fails
            if ($validator->fails()) {
                return redirect()->back()
                    ->withErrors($validator)
                    ->withInput();
            }

            // Start a database transaction
            DB::beginTransaction();

            // Find the existing OPD Patient record by ID
            $opdPatient = OpdPatient::findOrFail($id); // Throws a 404 error if the record doesn't exist

            // Fetch the patient's unique ID
            $patient_unique_id = DB::table('patients')
                ->where('user_id', $request->patient)
                ->value('patient_unique_id');
            // Update the OPD Patient record
            $opdPatient->update([
                'patient_unique_id' => $patient_unique_id,
                'patient_id' => $request->patient, // Foreign key for patient
                'case' => $request->case,
                'opd_no' => $request->opd_no, // Unique OPD number
                'height' => $request->height,
                'weight' => $request->weight,
                'blood_pressure' => $request->blood_pressure,
                'symptoms' => $request->symptoms,
                'notes' => $request->notes,
                'appointment_date' => $request->appointment_date,
                'doctor_id' => $request->doctor, // Foreign key for doctor
                'standard_charge' => $request->standard_charge,
                'payment_mode' => $request->payment_mode,
                'is_old_patient' => $request->is_old_patient,
                'bp' => $request->bp,
                'SpO2' => $request->SpO2,
                'pulse' => $request->pulse,
                'temperature' => $request->temperature,
            ]);

            // Commit the transaction
            DB::commit();

            // Redirect with success message
            return redirect()->route('admin.opd.index')->with('success', 'OPD Patient updated successfully!');
        } catch (\Throwable $e) {
            // Rollback the transaction on error
            DB::rollBack();

            // Redirect back with error message
            return redirect()->back()
                ->with('error', 'An error occurred while updating the OPD Patient record: ' . $e->getMessage())
                ->withInput();
        }
    }

    public function getPatientCases($patientId)
    {
        $cases = DB::table('patient_cases')
            ->where('patient_id', $patientId)
            ->select('id', 'case_id')
            ->get();
        return response()->json($cases);
    }



    public function generateOpdNo()
    {
        $year = date('y'); // e.g. 25 for 2025

        // Get last OPD number for this year
        $lastOpd = OpdPatient::whereYear('created_at', now()->year)
            ->orderByDesc('id')
            ->first();

        if ($lastOpd && preg_match('/\/OPD\/(\d{5})\/' . $year . '/', $lastOpd->opd_no, $matches)) {
            $nextNumber = intval($matches[1]) + 1;
        } else {
            $nextNumber = 1;
        }

        // Ensure unique OPD number
        do {
            $opd_no = 'TH/OPD/' . str_pad($nextNumber, 5, '0', STR_PAD_LEFT) . '/' . $year;
            $exists = OpdPatient::where('opd_no', $opd_no)->exists();
            $nextNumber++;
        } while ($exists);

        return response()->json(['opd_no' => $opd_no]);
    }



    public function opd_patient_detail($id)
    {
        $opd_patient = OpdPatient::with(['patient', 'doctor'])->findOrFail($id);

        // Fetch appointments for this patient (latest first)
        $appointments = OpdPatient::with('doctor')->where('patient_id', $opd_patient->patient_id)->latest()->get();
        // dd($appointments);

        $appointments_count = OpdPatient::where('patient_id', $opd_patient->patient_id)->count();

        // Fetch diagnoses for this OPD patient
        $diagnoses = Diagnosis::where('opd_patient_id', $opd_patient->id)
            ->orderBy('report_date', 'desc')
            ->get();

        // Fetch medicine categories
        $medicine_categories = \App\Models\MedicineCategory::all();

        // Fetch prescriptions for this patient (with medicines and doctor)
        $prescriptions = \App\Models\Prescription::with(['medicines.medicine'])
            ->where('patient_id', $opd_patient->patient_id)
            ->orderByDesc('id')
            ->get();

        // **Fetch diagnosis tests for this OPD patient**
        $diagnosis_tests = OpdDiagnosisTest::where('opd_patient_id', $opd_patient->id)->where('opd_no', $opd_patient->opd_no)->orderBy('test_date', 'desc')->get();
        // dd($diagnosis_tests);
        $diagnosis_tests_groups = OpdDiagnosisTest::where('opd_patient_id', $opd_patient->id)
            ->where('opd_no', $opd_patient->opd_no)
            ->orderBy('created_at', 'desc')
            ->get()
            ->groupBy('group_test_no');
        // dd($diagnosis_tests_groups);
        $chargeCategories = \App\Models\ChargeCategory::all();
        // dd($chargeCategories); 
        $chargeTypes = \App\Models\ChargeType::all();

        return view('opd.opdpatient-details', compact(
            'opd_patient',
            'appointments',
            'appointments_count',
            'diagnoses',
            'medicine_categories',
            'prescriptions',
            'chargeCategories',
            'chargeTypes',
            'diagnosis_tests' // <-- Add this line
            ,
            'diagnosis_tests_groups' // <-- Add this line
        ));
    }


    public function print($id)
    {
        $opdPatient = OpdPatient::with(['doctor', 'patient'])->findOrFail($id);
        // dd($opdPatient);
        $patient_uhid = DB::table('patients')
            ->where('user_id', $opdPatient->patient_id)
            ->value('patient_unique_id');

        // dd($patient_uhid);

        return view('opd.print-opdpatient', compact('opdPatient', 'patient_uhid'));
    }

    public function groupPdf(Request $request)
    {
        $opd_patient_id = $request->opd_patient_id;
        $group_test_no = $request->group_test_no;
        // dd($opd_patient_id, $group_test_no);

        $tests = OpdDiagnosisTest::where('opd_patient_id', $opd_patient_id)
            ->where('group_test_no', $group_test_no)
            ->get();

        $opd_patient = OpdPatient::with(['patient', 'doctor'])->find($opd_patient_id);
        // dd($tests, $opd_patient);

        $pdf = app('dompdf.wrapper');
        $pdf->loadView('opd.diagnosis-tests-pdf', [
            'tests' => $tests,
            'opd_patient' => $opd_patient,
        ]);
        return $pdf->stream('diagnosis-tests.pdf'); // open in new tab
    }


    public function searchPatients(Request $request)
    {
        $term = $request->input('term');

        // Join users & patients table for UHID
        $results = \DB::table('users')
            ->leftJoin('patients', 'users.id', '=', 'patients.user_id')
            ->where('users.role', 'Patient') // ya aapke role system ke hisab se
            ->where(function ($query) use ($term) {
                $query->where('users.name', 'like', "%{$term}%")
                    ->orWhere('patients.patient_unique_id', 'like', "%{$term}%");
            })
            ->select('users.id', 'users.name', 'patients.patient_unique_id')
            ->orderBy('id', 'desc')
            ->get();

        // Format for Select2
        $data = [];
        foreach ($results as $row) {
            $data[] = [
                'id' => $row->id,
                'name' => $row->name . ' (' . ($row->patient_unique_id ?? 'N/A') . ')'
            ];
        }

        return response()->json($data);
    }


    public function moveToIpd($id)
    {
        $opd = OpdPatient::with(['patient', 'doctor'])->findOrFail($id);
        // dd($opd);

        // Data array for prefill
        $prefill = [
            'uhid' => $opd->patient_unique_id,
            'patient_id' => $opd->patient_id,
            'doctor_id' => $opd->doctor_id,
            'symptoms' => $opd->symptoms,
            'height' => $opd->height,
            'weight' => $opd->weight,
            'blood_pressure' => $opd->blood_pressure,
            // aur bhi fields jo aapko chahiye
        ];

        // Redirect to IPD add page with prefill data as query string
        return redirect()->route('admin.ipd.add', $prefill);
    }

    public function blankReceipt($id)
    {
        $opdPatient = OpdPatient::with(['doctor', 'patient'])->findOrFail($id);
        // dd($opdPatient);
        $patient_uhid = DB::table('patients')
            ->where('user_id', $opdPatient->patient_id)
            ->value('patient_unique_id');
        return view('opd.blank-receipt', compact('opdPatient', 'patient_uhid'));
    }
}
