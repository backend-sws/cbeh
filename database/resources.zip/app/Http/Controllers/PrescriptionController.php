<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Medicine;
use App\Models\IpdPatient;
use Illuminate\Support\Str;
use App\Models\Prescription;
use Illuminate\Http\Request;
use App\Models\MedicineBrand;
use App\Models\MedicineCategory;
use Illuminate\Support\Facades\DB;
use App\Models\PrescriptionMedicine;
use Illuminate\Support\Facades\Validator;



class PrescriptionController extends Controller
{
    public function index()
    {
        $perPage = request()->input('perPage', 10);
        $prescriptions = Prescription::with('doctor', 'patient')->paginate($perPage);
        return view('prescription.prescription', compact('prescriptions'));
    }
    public function add()
    {
        $doctors = User::role('Doctor')->select('id', 'name', 'email')->get();
        $patients = User::role('Patient')->select('id', 'name', 'email')->get();
        return view('prescription.newprescription', compact('doctors', 'patients'));
    }
    public function getMedicines(Request $request)
    {
        $query = $request->input('query');
        $medicines = Medicine::with(['category', 'brand', 'type'])
            ->where('name', 'LIKE', "%{$query}%")
            ->orWhere('generic_name', 'LIKE', "%{$query}%")
            ->orWhere('code', 'LIKE', "%{$query}%")
            ->get();

        return response()->json($medicines);
    }
    public function getMedicineCategories()
    {
        $categories = MedicineCategory::all();
        return response()->json($categories);
    }
    public function getMedicineBrands()
    {
        $brands = MedicineBrand::all();
        return response()->json($brands);
    }

    public function getPrescriptionMedicines($prescriptionId)
    {
        $medicines = PrescriptionMedicine::where('prescription_id', $prescriptionId)
            ->with(['medicine', 'medicine.category', 'medicine.brand', 'medicine.type'])
            ->get();

        return response()->json($medicines);
    }
    public function getPrescriptionDetails($id)
    {
        $prescription = Prescription::with(['doctor', 'patient', 'patient.ipd', 'medicines.medicine', 'medicines.medicine.categoryRelation', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->findOrFail($id);

        return response()->json($prescription);
    }
    public function prescription_by_patient($patientId)
    {
        $prescriptions = Prescription::where('patient_id', $patientId)
            ->with(['patient', 'doctor'])
            ->get();

        return response()->json($prescriptions);
    }
    public function prescriptionDetail($id)
    {
        $prescription = Prescription::with(['doctor', 'patient', 'medicines.medicine', 'medicines.medicine', 'medicines.medicine', 'medicines.medicine.category'])
            ->findOrFail($id);

        return response()->json($prescription);
    }
    public function getPrescriptionByDoctor($doctorId)
    {
        $prescriptions = Prescription::where('doctor_id', $doctorId)
            ->with(['patient', 'medicines.medicine', 'medicines.medicine.category', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->get();

        return response()->json($prescriptions);
    }
    public function getPrescriptionByIpdNo($ipdNo)
    {
        $prescriptions = Prescription::where('ipd_no', $ipdNo)
            ->with(['doctor', 'patient', 'medicines.medicine', 'medicines.medicine.category', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->get();

        return response()->json($prescriptions);
    }
    public function getPrescriptionByCase($case)
    {
        $prescriptions = Prescription::where('case', 'LIKE', "%{$case}%")
            ->with(['doctor', 'patient', 'medicines.medicine', 'medicines.medicine.category', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->get();

        return response()->json($prescriptions);
    }
    public function getPrescriptionByStatus($status)
    {
        $prescriptions = Prescription::where('status', $status)
            ->with(['doctor', 'patient', 'medicines.medicine', 'medicines.medicine.category', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->get();

        return response()->json($prescriptions);
    }
    public function getPrescriptionByDateRange($startDate, $endDate)
    {
        $prescriptions = Prescription::whereBetween('created_at', [$startDate, $endDate])
            ->with(['doctor', 'patient', 'medicines.medicine', 'medicines.medicine.category', 'medicines.medicine.brand', 'medicines.medicine.type'])
            ->get();

        return response()->json($prescriptions);
    }
    public function edit($id)
    {
        return view('prescription.editprescription', compact('id'));
    }
    public function view($id)
    {
        return view('prescription.viewprescription', compact('id'));
    }
    public function delete($id)
    {
        $prescription = Prescription::findOrFail($id);
        // Delete associated prescription medicines
        $prescription->delete();
        return redirect()->back()->with('success', 'Prescription deleted successfully.');
    }
    public function save(Request $request)
    {
        // Validate general prescription data
        $validator = Validator::make($request->all(), [
            'patient_id' => 'required|exists:users,id',
            'doctor_id' => 'required|exists:users,id',
            'status' => 'boolean',
            // Optional validation for medicine arrays
            'medicine_id' => 'array',
            'dosage' => 'array',
            'dose_duration' => 'array',
            'dose_interval' => 'array',
            'time' => 'array',
            'instruction' => 'array',
        ]);

        if ($validator->fails()) {
            return show_validation_error($validator, true);
        }

        // Create the main prescription
        $prescription = Prescription::create([
            'patient_id' => $request->patient_id,
            'doctor_id' => $request->doctor_id,
            'headernotes' => $request->headernotes,
            'footernotes' => $request->footernotes,
            'status' => $request->status ? 1 : 0,
            'prescription_date' => now(),
        ]);

        // Handle multiple medicines
        if ($request->has('medicine_id')) {
            foreach ($request->medicine_id as $index => $medicineId) {
                PrescriptionMedicine::create([
                    'prescription_id' => $prescription->id,
                    'medicine_id' => $medicineId,
                    'dosage' => $request->dosage[$index] ?? '',
                    'duration' => $request->dose_duration[$index] ?? '',
                    'doseInterval' => $request->dose_interval[$index] ?? '',
                    'time' => $request->time[$index] ?? '',
                    'instructions' => $request->instruction[$index] ?? '',
                ]);
            }
        }


        return redirect()->route('admin.prescription.print', $prescription->id)->with('success', 'Prescription created successfully.');
    }

    public function prescriptionSave(Request $request)
    {
        // Logic to save prescription data
        return redirect()->back()->with('success', 'Prescription saved successfully.');
    }
    public function prescriptionUpdate(Request $request, $id)
    {
        // Logic to update prescription data
        return redirect()->back()->with('success', 'Prescription updated successfully.');
    }

    public function print($id)
    {
        // dd($id);
        $prescription = Prescription::where('id', $id)
            ->with(['patient', 'doctor', 'medicines.medicine.categoryRelation', 'medicines.medicine.category'])
            ->first();
            // dd($prescription);

        $uhid = DB::table('patients')->where('user_id', $prescription->patient_id)->value('patient_unique_id');
        $beds = IpdPatient::with('beds' )->where('patient_id', $prescription->patient_id)->first();
        // dd($beds);

        return view('prescription.print-prescription', compact('prescription', 'uhid', 'beds'));
    }


}
