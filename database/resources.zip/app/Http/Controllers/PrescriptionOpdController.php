<?php

namespace App\Http\Controllers;

use App\Models\Medicine;
use App\Models\OpdPatient;
use App\Models\Prescription;
use Illuminate\Http\Request;
use Barryvdh\DomPDF\Facade\Pdf;
use App\Models\MedicineCategory;
use Illuminate\Support\Facades\DB;
use App\Models\PrescriptionMedicine;

class PrescriptionOpdController extends Controller
{
    // public function index($opd_patient)
    // {
    //      $opd_patient = \App\Models\OpdPatient::with(['patient', 'doctor'])->findOrFail($opd_patient);
    //     $prescriptions = Prescription::with('medicines.medicine')->where('patient_id', $opd_patient)->orderByDesc('id')->get();
    //     $medicine_categories = MedicineCategory::all();

    //     dd($prescriptions->toArray());
    //     return view('opd.opdpatient-details', compact('prescriptions', 'medicine_categories', 'opd_patient'));
    // }

    public function store(Request $request)
    {
        $request->validate([
            'patient_id' => 'required',
            'doctor_id' => 'required',
            'headernotes' => 'nullable|string',
            'footernotes' => 'nullable|string',
            'prescription_date' => 'required|date',
            'status' => 'required|string',
            'medicine_id' => 'nullable|array',
            'dosage' => 'nullable|array',
            'duration' => 'nullable|array',
            'doseInterval' => 'nullable|array',
            'time' => 'nullable|array',
            'instructions' => 'nullable|array',
        ]);

        $prescription = Prescription::create([
            'patient_id' => $request->patient_id,
            'doctor_id' => $request->doctor_id,
            'headernotes' => $request->headernotes,
            'footernotes' => $request->footernotes,
            'prescription_date' => $request->prescription_date,
            'status' => $request->status,
        ]);

        if($request->medicine_id){
             foreach ($request->medicine_id as $i => $medicineId) {
            PrescriptionMedicine::create([
                'prescription_id' => $prescription->id,
                'medicine_id' => $medicineId,
                'dosage' => $request->dosage[$i],
                // 'doseInterval' => $request->doseInterval[$i],
                // 'duration' => $request->duration[$i],
                // 'time' => $request->time[$i],
                'instructions' => $request->instructions[$i],
            ]);
        }
        }
       

        return redirect()->back()->with('success', 'Prescription added successfully!');
    }

    public function update(Request $request, Prescription $prescription)
    {
        $request->validate([
            'headernotes' => 'nullable|string',
            'footernotes' => 'nullable|string',
            'prescription_date' => 'required|date',
            'status' => 'required|string',
            'medicine_id' => 'nullable|array',
            'dosage' => 'nullable|array',
            'duration' => 'nullable|array',
            'doseInterval' => 'nullable|array',
            'time' => 'nullable|array',
            'instructions' => 'nullable|array',
        ]);

        $prescription->update([
            'headernotes' => $request->headernotes,
            'footernotes' => $request->footernotes,
            'prescription_date' => $request->prescription_date,
            'status' => $request->status,
        ]);

        // Delete old medicines
        $prescription->medicines()->delete();

        // Add new medicines
        if ($request->medicine_id) {
            foreach ($request->medicine_id as $i => $medicineId) {
            PrescriptionMedicine::create([
                'prescription_id' => $prescription->id,
                'medicine_id' => $medicineId,
                'dosage' => $request->dosage[$i],
                // 'doseInterval' => $request->doseInterval[$i],
                // 'duration' => $request->duration[$i],
                // 'time' => $request->time[$i],
                'instructions' => $request->instructions[$i] ?? '' ,
            ]);
        }
        }
       

        return redirect()->back()->with('success', 'Prescription updated successfully!');
    }

    public function destroy(Prescription $prescription)
    {
        $prescription->medicines()->delete();
        $prescription->delete();
        return redirect()->back()->with('success', 'Prescription deleted successfully!');
    }

    public function getMedicinesByCategory($category_id)
    {
        $medicines = Medicine::where('category', $category_id)->get();
        return response()->json($medicines);
    }


    public function show(Prescription $prescription)
    {
        $prescription->load('medicines.medicine');
        // dd($prescription->medicines->toArray());
        return response()->json([
            'id' => $prescription->id,
            'prescription_date' => $prescription->prescription_date,
            'created_at' => $prescription->created_at,
            'headernotes' => $prescription->headernotes,
            'footernotes' => $prescription->footernotes,
            'status' => $prescription->status,
            'medicines' => $prescription->medicines->map(function ($item) {
                return [
                    'category_id' => $item->medicine->category ?? null,
                    'medicine_id' => $item->medicine_id,
                    'dosage' => $item->dosage,
                    'duration' => $item->duration,
                    'doseInterval' => $item->doseInterval,
                    'time' => $item->time,
                    'instructions' => $item->instructions,
                ];
            })->toArray(),
        ]);
    }

    public function pdf(Prescription $prescription)
    {
        $prescription->load('medicines.medicine');
        // dd($prescription->toArray());
        $opd_patient = OpdPatient::with(['patient', 'doctor'])->where('patient_id', $prescription->patient_id)->first();
        // dd($opd_patient->toArray());

        $uhid = DB::table("patients")->where('user_id', $prescription->patient_id)->value('patient_unique_id');
        // dd($uhid);
        $medicine_categories = MedicineCategory::all();
        $medicines =Medicine::all();

        // $pdf = Pdf::loadView('opd.prescription-pdf', compact('prescription', 'opd_patient', 'medicine_categories', 'medicines' , 'uhid'));
        return view('opd.prescription-pdf', compact('prescription', 'opd_patient', 'medicine_categories', 'medicines' , 'uhid')); // <-- yahi line important hai
    }
}