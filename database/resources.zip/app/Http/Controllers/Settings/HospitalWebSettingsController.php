<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class HospitalWebSettingsController extends Controller
{
    public function index()
    {
        return view('settings.hospital-web-settings');
    }

    public function update(Request $request)
    {

        foreach ($request->except('_token') as $key => $value) {
            // Handle file uploads
            if ($request->hasFile($key)) {
                $file = $request->file($key);
                $filename = time() . '_' . $file->getClientOriginalName();
                $file->move(public_path('img'), $filename);
                $value = $filename;
            }

            // Update or create the setting
            \App\Models\Setting::updateOrCreate(
                ['key' => $key],
                ['value' => $value]
            );
        }
     

     
        return redirect()->route('admin.hospital-web-settings.index')->with('success', 'Settings updated successfully.');
    }
}
