<?php 
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\User;

class OpdPatient extends Model
{
    use HasFactory;

    protected $table = 'opd_patients'; // Table name

    protected $fillable = [
        'patient_id',
        'case',
        'opd_no',
        'height',
        'weight',
        'blood_pressure',
        'symptoms',
        'notes',
        'appointment_date',
        'doctor_id',
        'standard_charge',
        'payment_mode',
        'is_old_patient',
        'bp',
        'SpO2',
        'casuality',
        'reference',
        'discount',
        'tax',
        'final_amount',
        'invoice_no',
        'age',
        'patient_unique_id',
        'pulse',
        'temperature',
    ];

    // Relationship with User (Patient)
    public function patient()
    {
        return $this->belongsTo(User::class, 'patient_id');
    }

    // Relationship with User (Doctor)
    public function doctor()
    {
        return $this->belongsTo(User::class, 'doctor_id');
    }
}