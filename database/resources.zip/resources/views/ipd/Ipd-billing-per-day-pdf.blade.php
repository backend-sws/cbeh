<!DOCTYPE html>
<html>

<head>
    <title>IPD Daily Bill - {{ \Carbon\Carbon::parse($selectedDate)->format('d-m-Y') }}</title>
    <style>
        /* Base Settings */
        html,
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #f8f9fa;
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 750px;
            margin: 10px auto;
            background: #fff;
            min-height: 100vh;
            padding: 20px 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* --- Header Styles --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        /* --- Patient Info Table --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 5px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
            text-transform: uppercase;
        }

        /* --- Charges Table --- */
        .charges-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 5px;
            font-size: 11px;
        }

        .charges-table th,
        .charges-table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: center;
        }

        .charges-table th {
            background: #f3f4f6;
            color: #1e293b;
            font-weight: bold;
            text-align: center;
        }

        .charges-table td:first-child,
        .charges-table th:first-child {
            text-align: left;
        }

        /* --- Summary Table --- */
        .summary-container {
            display: flex;
            gap: 20px;
            margin-top: 15px;
            align-items: flex-start;
        }

        .summary-table {
            width: 100%;
            border-collapse: collapse;
        }

        .summary-table td {
            padding: 6px;
            border-bottom: 1px solid #eee;
            text-align: right;
        }

        .total-row {
            font-weight: bold;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            font-size: 13px;
        }

        /* --- Footer Styles (QR & Signature) --- */
        .footer-split {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: auto;
            padding-top: 20px;
            page-break-inside: avoid;
        }

        .signature-section {
            width: 40%;
        }

        .small-points {
            font-size: 9px;
            color: #555;
            text-align: left;
            margin-top: 5px;
            line-height: 1.4;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body {
                background: #fff;
            }

            .bill-container {
                width: 100%;
                border: none;
                margin: 0;
                padding: 0;
            }

            .print-btn {
                display: none;
            }

            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Bill</button>

    {{-- LOGIC: Calculate Discount vs Actual Payment --}}
    @php
        // Filter out payments where mode name is 'Discount'
        $discountPayments = $payments->filter(function ($p) {
            return optional($p->payment_mode)->name == 'Discount';
        });

        // Sum the discount amount
        $totalDiscountAmount = $discountPayments->sum('amount');

        // Calculate actual money paid (Total Payment - Discount)
        $actualPaidAmount = $TotalPayment - $totalDiscountAmount;
    @endphp

    <div class="bill-container">

        @if(setting('show_header_ipd_day_bill', 'yes') == 'yes')
        <table class="header-table">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                          {{ setting('tagline', 'Tagline') }}<br>
                        {{ setting('address', 'Address Here') }}<br>
                        Phone: +91 {{ setting('phone') }} | Email: {{ setting('email') }}<br>
                        Website: {{ setting('website', 'www.example.com') }}
                    </div>
                </td>
            </tr>
        </table>
        @else
        <div style="height: {{ setting('spacer_ipd_day_bill', '180') }}px;"></div>
        @endif

        <div style="text-align:center; font-weight:bold; font-size:16px; margin-top:5px; text-decoration: underline; color: #333;">
            DAILY IPD BILL
        </div>

        <div class="section-title">Patient Information</div>
        <table class="info-table">
            <tr>
                <td>Patient Name:</td>
                <td colspan="3"><strong>{{ $ipd_patient->patient->name }}</strong></td>
            </tr>
            <tr>
                <td>UHID:</td>
                <td>{{ $UHID ? $UHID->patient_unique_id : '' }}</td>
                <td>IPD No:</td>
                <td>{{ $ipd_patient->ipd_no }}</td>
            </tr>
            <tr>
                <td>Age/Gender:</td>
                <td>
                    {{ $ipd_patient->patient->age ?? '0' }} Y 
                    @if($ipd_patient->patient->age_month)
                        {{ $ipd_patient->patient->age_month }} M
                    @endif
                    / {{ $ipd_patient->patient->gender ?? '' }}
                </td>
                <td>Phone:</td>
                <td>{{ $ipd_patient->patient->phone }}</td>
            </tr>
            <tr>
                <td>Address:</td>
                <td colspan="3">{{ $ipd_patient->patient->address ?? '' }}</td>
            </tr>
            <tr>
                <td>Date of Bill:</td>
                <td colspan="3" style="font-size: 14px; color: blue;"><strong>{{ \Carbon\Carbon::parse($selectedDate)->format('d-m-Y') }}</strong></td>
            </tr>
        </table>

        <div class="section-title">Billing Details for {{ \Carbon\Carbon::parse($selectedDate)->format('d-m-Y') }}</div>
        
        <table class="charges-table">
            <thead>
                <tr>
                    <th width="10%">S.No</th>
                    <th width="40%" style="text-align: center;">Particulars</th>
                    <th width="15%">Rate</th>
                    <th width="15%">Qty</th>
                    <th width="20%">Amount</th>
                </tr>
            </thead>
            <tbody>
                @php $sno = 1; @endphp
                
                {{-- Bed Charge (If applicable) --}}
                @if($BedAssignCharge > 0)
                    <tr>
                        <td style="text-align: center;">{{ $sno++ }}</td>
                        <td style="text-align: center;">Bed Charge ({{ $beds->bed->bedType->bed_type ?? 'General' }} - {{ $beds->bed->name ?? '' }})</td>
                        <td>{{ number_format($BedAssignCharge, 2) }}</td>
                        <td style="text-align: center;">1</td>
                        <td>{{ number_format($BedAssignCharge, 2) }}</td>
                    </tr>
                @endif

                {{-- Other manual charges --}}
                @foreach($charges as $charge)
                    <tr>
                        <td style="text-align: center;">{{ $sno++ }}</td>
                        <td style="text-align: center;">
                           {{ $charge->chargeCategory->charge_category ?? '-' }}
                        </td>
                        <td>{{ number_format($charge->applied_charge, 2) }}</td>
                        <td style="text-align: center;">{{ $charge->quantity }}</td>
                        <td>{{ number_format($charge->total, 2) }}</td>
                    </tr>
                @endforeach

                @if($sno == 1)
                    <tr>
                        <td colspan="5" style="text-align:center;">No charges recorded on this day.</td>
                    </tr>
                @endif

                <tr style="background-color: #f9f9f9; font-weight:bold;">
                    <td colspan="4" style="text-align: right;">Total Daily Charges:</td>
                    <td>{{ number_format($Totalcharge, 2) }}</td>
                </tr>
            </tbody>
        </table>

        @if (count($payments) > 0)
            <div class="section-title">Daily Payments ({{ \Carbon\Carbon::parse($selectedDate)->format('d-m-Y') }})</div>
            <table class="charges-table">
                <thead>
                    <tr>
                        <th width="40%" style="text-align: center;">Payment Mode</th>
                        <th width="30%" style="text-align: center;">Date</th>
                        <th width="30%">Paid Amount</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($payments as $payment)
                        @if (optional($payment->payment_mode)->name == 'Discount')
                            @continue
                        @endif
                        <tr>
                            <td style="text-align: center">{{ $payment->payment_mode->name ?? 'N/A' }}</td>
                            <td style="text-align: center;">
                                {{ \Carbon\Carbon::parse($payment->payment_date)->format('d-m-Y') }}</td>
                            <td>{{ number_format($payment->amount, 2) }}</td>
                        </tr>
                    @endforeach
                    <tr style="background-color: #f9f9f9; font-weight:bold;">
                        <td colspan="2" style="text-align: right;">Daily Paid Total:</td>
                        <td>{{ number_format($actualPaidAmount, 2) }}</td>
                    </tr>
                </tbody>
            </table>
        @endif

        <div class="summary-container">
            <div class="qr-section" style="width: auto; flex: 0 0 auto; text-align: center;">
                @if (setting('hospital_qr'))
                    <img src="{{ asset('img/' . setting('hospital_qr')) }}"
                        style="height: 80px; width: 80px; border: 1px solid #ddd; padding: 3px;">
                @else
                    <div
                        style="height: 80px; width: 80px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">
                        No QR</div>
                @endif
                <div style="font-weight: bold; font-size: 12px; margin-top: 5px; color: #333;">Scan & Pay</div>
            </div>

            <div style="flex: 0 0 45%; margin-left: auto;">
                <table class="summary-table">
                    <tr>
                        <td>Total charges for Day:</td>
                        <td style="font-weight: bold;">{{ number_format($Totalcharge, 2) }}</td>
                    </tr>
                    @if ($totalDiscountAmount > 0)
                        <tr>
                            <td>Discount for Day:</td>
                            <td>- {{ number_format($totalDiscountAmount, 2) }}</td>
                        </tr>
                    @endif
                    <tr>
                        <td>Paid during Day:</td>
                        <td>- {{ number_format($actualPaidAmount, 2) }}</td>
                    </tr>
                    <tr class="total-row">
                        <td style="border:none;">Daily Balance:</td>
                        <td style="border:none; font-size: 14px;">{{ number_format($netPayable, 2) }}</td>
                    </tr>
                </table>
            </div>
        </div>

        @if(setting('show_footer_ipd_day_bill', 'yes') == 'yes')
        <div class="small-points">
            <div>* E & O.E. </div>
            <div>* This is a System Generated Receipt for the specified date. </div>
            <div>* This receipt is not Valid for Medico-legal Purpose. </div>
            <div>* All Legal Claims are Subject to Muzaffarpur Jurisdiction Only. </div>
        </div>

        <div class="footer-split" style="justify-content: flex-end;" >
            <div class="signature-section">
                <table width="100%">
                    <tr>
                        <td style="width:50%; text-align:center; border:none;">
                            <div style="height:30px;"></div>
                            <div style="border-top:1px solid #333; width:60%; margin:0 auto;"></div>
                            <div style="font-size:11px; margin-top:3px;">Authorized Signature</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div style="padding-top:5px; margin-top: 10px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
            <div style="margin-top: 2px; font-size: 16px; color: #000000; font-family: 'Monotype Corsiva', cursive; font-style: italic;">
                Thank you for Payment. Get Well Soon!
            </div>
        </div>
        @endif

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>

</body>

</html>
