@extends('layouts.admin')
@section('title', 'IPD Patients')
@section('content')

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>
        .form-control:focus,
        .form-select:focus {
            border-color: #3b82f6;
            ring: 2px;
            ring-color: #3b82f6;
        }

        .table th {
            background-color: #f9fafb;
            font-weight: 600;
            font-size: 0.75rem;
            text-transform: uppercase;
            color: #374151;
        }

        /* Select2 Custom Styling to match Tailwind */
        .select2-container .select2-selection--single {
            height: 38px !important;
            border: 1px solid #d1d5db !important;
            border-radius: 0.375rem !important;
            padding-top: 5px;
        }

        .select2-container--default .select2-selection--single .select2-selection__arrow {
            top: 6px !important;
        }
    </style>

    <div class="max-w-7xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <div class="flex justify-between items-center mb-6">
            <h1 class="text-2xl font-bold text-gray-800">IPD Patient - Add Prescription</h1>
            <div class="flex space-x-3">
                <a href="{{ route('admin.ipd.detail', $ipd->id) }}">
                    <button
                        class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        <i class="fas fa-arrow-left mr-2"></i> Back to IPD Details
                    </button>
                </a>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div class="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div class="text-sm font-medium text-blue-600">Patient Name</div>
                <div class="text-lg font-semibold text-gray-800">{{ $ipd->patient->name }}</div>
            </div>
            <div class="bg-green-50 p-4 rounded-lg border border-green-200">
                <div class="text-sm font-medium text-green-600">UHID</div>
                <div class="text-lg font-semibold text-gray-800">{{ $uhid ?? '--' }}</div>
            </div>
            <div class="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <div class="text-sm font-medium text-purple-600">Doctor</div>
                <div class="text-lg font-semibold text-gray-800">Dr. {{ $ipd->doctor->name }}</div>
            </div>
            <div class="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <div class="text-sm font-medium text-orange-600">IPD No</div>
                <div class="text-lg font-semibold text-gray-800">{{ $ipd->id }}</div>
            </div>
        </div>

        <div class="bg-white rounded-lg border border-gray-200 p-6">
            @if (session('success'))
                <div class="mb-4 p-3 bg-green-100 border border-green-400 text-green-700 rounded">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="mb-4 p-3 bg-red-100 border border-red-400 text-red-700 rounded">
                    {{ session('error') }}
                </div>
            @endif

            <form action="{{ route('admin.prescription.save', $ipd->ipd_no) }}" method="POST" id="prescriptionForm">
                @csrf
                <input type="hidden" name="patient_id" value="{{ $ipd->patient->id }}">
                <input type="hidden" name="doctor_id" value="{{ $ipd->doctor->id }}">
                <input type="hidden" name="ipd_no" value="{{ $ipd->id }}">
                <input type="hidden" name="case" value="{{ $ipd->case }}">

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Doctor Notes <span class="text-xs text-gray-500">(You can use line breaks and bullets)</span>
                    </label>
                    <textarea
                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm font-mono whitespace-pre-wrap"
                        rows="5" name="headernotes" id="headernotes" placeholder="Enter doctor notes...&#10;• Use bullets with • character&#10;• Press Enter for new lines"></textarea>
                    <small class="text-gray-500 text-xs mt-1">💡 Tip: Use ALT + 7 for bullets • and press Enter for line breaks</small>
                </div>

                <div class="mb-6">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-medium text-gray-700">Prescription Items</h3>
                        <button type="button" id="addMedicineRow"
                            class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                            <i class="fas fa-plus mr-2"></i> Add Medicine
                        </button>
                    </div>

                    <div class="overflow-x-auto border border-gray-200 rounded-lg">
                        <table class="min-w-full divide-y divide-gray-200" id="medicinesTable">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th scope="col"
                                        class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Category
                                    </th>
                                    <th scope="col"
                                        class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Medicine
                                    </th>
                                    <th scope="col"
                                        class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Dosage
                                    </th>
                                    {{-- 
                                <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Duration
                                </th>
                                <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Frequency
                                </th> 
                                --}}
                                    {{-- <th scope="col" class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                    Meal Time
                                </th> --}}

                                    <th scope="col"
                                        class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                        Instruction
                                    </th>

                                    <th scope="col"
                                        class="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-16">
                                        Action
                                    </th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200" id="medicineRows">
                                <tr id="medicineRow0">
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <select
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                            name="medicine_category_id[]" onchange="get_medicine_by_category(this)"
                                            required>
                                            <option value="">Select Category</option>
                                            @foreach ($medicineCategories as $category)
                                                <option value="{{ $category->id }}">{{ $category->medicine_category }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap" style="min-width: 200px;">
                                        <select
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 medicine-select"
                                            name="medicine_id[]" required>
                                            <option value="">Select Medicine</option>
                                            @foreach ($medicines as $medicine)
                                                <option value="{{ $medicine->id }}">
                                                    {{ $medicine->medicine }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </td>
                                    <td class="px-4 py-3 whitespace-nowrap">
                                        <select
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                            name="dosage[]" required>
                                            <option value="">Select Dosage</option>
                                            <option value="BBF">BBF</option>
                                            <option value="OD">OD</option>
                                            <option value="BD">BD</option>
                                            <option value="TDS">TDS</option>
                                            <option value="QID">QID</option>
                                            <option value="SOS">SOS</option>
                                        </select>
                                    </td>

                                    {{-- 
                                <td class="px-4 py-3 whitespace-nowrap">
                                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                                        name="dose_duration[]">
                                        <option value="Only One Day">Only One Day</option>
                                        ...
                                    </select>
                                </td>
                                <td class="px-4 py-3 whitespace-nowrap">
                                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                                        name="dose_interval[]">
                                        <option value="Daily Morning">Daily Morning</option>
                                        ...
                                    </select>
                                </td> 
                                --}}

                                    {{-- <td class="px-4 py-3 whitespace-nowrap">
                                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                                        name="time[]" required>
                                        <option value="Before meal">Before meal</option>
                                        <option value="After meal">After meal</option>
                                        <option value="Bed Time">Bed Time</option>
                                    </select>
                                </td> --}}


                                    <td class="px-4 py-3">
                                        <input type="text"
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                            name="instruction[]" placeholder="Special instructions...">
                                    </td>


                                    <td class="px-4 py-3 whitespace-nowrap text-center">
                                        <button type="button" class="text-red-500 hover:text-red-700"
                                            onclick="removeMedicineRow(0)" title="Delete">
                                            <i class="fas fa-trash-alt"></i>
                                        </button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">
                        Investigation Advise <span class="text-xs text-gray-500">(You can use line breaks and bullets)</span>
                    </label>
                    <textarea
                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm font-mono whitespace-pre-wrap"
                        rows="5" name="footernotes" id="footernotes" placeholder="Enter investigation advice...&#10;• ECG - Regular&#10;• CBC - Normal"></textarea>
                    <small class="text-gray-500 text-xs mt-1">💡 Tip: Use ALT + 7 for bullets • and press Enter for line breaks</small>
                </div>

                <div class="flex justify-end gap-3 pt-6 border-t border-gray-200">
                    <button type="submit"
                        class="px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                        Save Prescription
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        let medicineRowCount = 0;

        // Initialize Select2 on document ready
        $(document).ready(function() {
            $('.medicine-select').select2({
                width: '100%',
                placeholder: "Select Medicine",
                allowClear: true
            });
        });

        function addMedicineRow() {
            medicineRowCount++;
            // NOTE: Updated row HTML - Removed commented out columns and updated dosage input to select
            const row = `
            <tr id="medicineRow${medicineRowCount}">
                <td class="px-4 py-3 whitespace-nowrap">
                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                        name="medicine_category_id[]" onchange="get_medicine_by_category(this)" required>
                        <option value="">Select Category</option>
                        @foreach ($medicineCategories as $category)
                            <option value="{{ $category->id }}">{{ $category->medicine_category }}</option>
                        @endforeach
                    </select>
                </td>
                <td class="px-4 py-3 whitespace-nowrap">
                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 medicine-select" 
                        name="medicine_id[]" required>
                        <option value="">Select Medicine</option>
                        @foreach ($medicines as $medicine)
                            <option value="{{ $medicine->id }}">
                                {{ $medicine->medicine }}
                            </option>
                        @endforeach
                    </select>
                </td>
                <td class="px-4 py-3 whitespace-nowrap">
                    <select class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                        name="dosage[]" required>
                         <option value="">Select Dosage</option>
                        <option value="BBF">BBF</option>
                        <option value="OD">OD</option>
                        <option value="BD">BD</option>
                        <option value="TDS">TDS</option>
                        <option value="QID">QID</option>
                    </select>
                </td>
                <td class="px-4 py-3 whitespace-nowrap">
                  
                                    <input type="text" class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500" 
                                        name="instruction[]" placeholder="Special instructions...">
                      
                </td>
                <td class="px-4 py-3 whitespace-nowrap text-center">
                    <button type="button" class="text-red-500 hover:text-red-700" onclick="removeMedicineRow(${medicineRowCount})" title="Delete">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </td>
            </tr>`;

            // Append row
            $('#medicineRows').append(row);

            // Initialize Select2 on the new row's medicine select box
            $(`#medicineRow${medicineRowCount} .medicine-select`).select2({
                width: '100%',
                placeholder: "Select Medicine",
                allowClear: true
            });
        }

        function removeMedicineRow(rowId) {
            const row = document.getElementById(`medicineRow${rowId}`);
            if (row) {
                row.remove();
            }
        }

        function get_medicine_by_category(select) {
            const categoryId = select.value;
            const row = select.closest('tr');
            // Find the medicine select using jQuery to interact with Select2
            const medicineSelect = $(row).find('.medicine-select');

            // Clear existing options
            medicineSelect.empty().append('<option value="">Select Medicine</option>');

            if (!categoryId) {
                medicineSelect.trigger('change'); // Notify Select2 of update
                return;
            }

            // Construct the fetch URL dynamically
            const url = `{{ route('admin.medicine.get-medicine-by-category', '') }}/${categoryId}`;

            // Fetch medicines by category using AJAX
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    data.forEach(medicine => {
                        // Create option
                        const option = new Option(medicine.medicine, medicine.id, false, false);
                        medicineSelect.append(option);
                    });
                    medicineSelect.trigger('change'); // Refresh Select2 interface
                })
                .catch(error => console.error('Error fetching medicines:', error));
        }

        // Existing alert hide logic
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('addMedicineRow').addEventListener('click', addMedicineRow);
            setTimeout(function() {
                const alerts = document.querySelectorAll('.alert');
                alerts.forEach(alert => {
                    if (alert) {
                        alert.style.display = 'none';
                    }
                });
            }, 5000);
        });
    </script>

@endsection
