<!DOCTYPE html>
<html>

<head>
    <title>IPD Continuation Sheet - {{ $ipdPatient->ipd_no }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #fff;
            color: #222;
            line-height: 1.3;
            margin: 0;
            padding: 0;
        }

        .bill-container {
            width: 700px;
            margin: 10px auto 0 auto;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            position: relative;
            min-height: 90vh;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        .header-space {
            height: 180px;
            margin-bottom: 25px;
        }

        .section-title {
            font-size: 1rem;
            font-weight: bold;
            margin-top: 5px;
            margin-bottom: 5px;
            color: #333;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
            table-layout: fixed;
        }

        .info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border: 1px solid #333;
            word-wrap: break-word;
        }

        /* Label Column Style */
        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            width: 15%;
            /* Labels chote rakhe hain */
            font-weight: bold;
        }

        /* Value Column Style */
        .info-table td:nth-child(even) {
            width: 35%;
        }

        .blank-space {
            flex: 1;
            min-height: 250px;
            margin: 30px 0 30px 0;
        }

        .print-btn {
            margin: 20px auto 0 auto;
            display: block;
            padding: 8px 20px;
            font-size: 12px;
            background-color:
                {!! setting('theme_color', '#e91e63') !!}
            ;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        @media print {
            body {
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center;
                align-items: flex-start;
                min-height: 100vh;
            }

            .print-btn {
                display: none;
            }

            .bill-container {
                border: none;
                padding: 20px;
                margin: 0 auto;
                width: 100%;
                max-width: 700px;
                box-shadow: none;
            }

            .header-space {
                height: 120px;
            }

            @page {
                margin: 0.5cm;
                size: A4;
            }

            /* Print colors fix */
            .info-table td:nth-child(odd) {
                background-color: #f9f9f9 !important;
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }
        }
    </style>
</head>

<body>
    <div class="bill-container">
        <div class="header-space"></div>

        <div
            style="text-align:center; font-weight:bold; font-size:18px; margin-bottom:5px; text-decoration:underline; text-transform: uppercase;">
            IPD PRESCRIPTION
        </div>

        <div class="section-title">Patient Information</div>
        <table class="info-table">
            <tr>
                <td>Name:</td>
                <td colspan="3" style="font-weight: bold; font-size: 13px;">
                    {{ $ipdPatient->patient->name ?? '-' }}
                </td>
            </tr>
            <tr>
                <td>Age/Gender:</td>
                <td>
                    {{ $ipdPatient->patient->age ?? '0' }} Y 
                    @if($ipdPatient->patient->age_month)
                        {{ $ipdPatient->patient->age_month }} M
                    @endif
                    / {{ $ipdPatient->patient->gender ?? '' }}
                </td>
                <td>UHID:</td>
                <td>{{ $patient_uhid ?? '' }}</td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td>{{ $ipdPatient->patient->phone ?? '' }}</td>
                <td>Bed:</td>
                <td>
                    @if ($ipdPatient->beds)
                        {{ $ipdPatient->beds->name ?? '' }}
                    @else
                        -
                    @endif
                </td>
            </tr>
            <tr>
                <td>Date Of Admission:</td>
                <td>
                    {{ $ipdPatient->admission_date ? \Carbon\Carbon::parse($ipdPatient->admission_date)->format('d-m-Y ') : '' }}
                </td>
                <td>Date:</td>
                <td>{{ \Carbon\Carbon::now()->format('d-M-Y ') }}</td>
            </tr>
            {{-- <tr>
                <td>Address:</td>
                <td colspan="3">{{ $ipdPatient->patient->address ?? '' }}</td>
            </tr> --}}
            <!--<tr>-->
            <!--    <td>Consultant:</td>-->
            <!--    <td colspan="3" style="font-weight: bold;">-->
            <!--        {{ $ipdPatient->doctor->name ?? '' }}-->
            <!--    </td>-->
            <!--</tr>-->
        </table>



        <div class="blank-space"></div>

        <table width="100%" style="margin-top:auto; margin-bottom: 20px; visibility: hidden;">
            <tr>
                <td style="width:50%; text-align: center;"></td>
                <td style="width:50%; text-align:right; padding-right: 20px;">
                    <div style="height: 60px;"></div>
                    <div style="border-top:1px solid #333; width:200px; display:inline-block; margin-bottom: 5px;">
                    </div>
                    <div style="font-weight: bold; margin-right: 35px;">Consultant's Signature</div>
                </td>
            </tr>
        </table>
        <button onclick="window.print()" class="print-btn">
            Print Blank Receipt
        </button>
    </div>

    <script>
        window.onload = function () {
            // Uncomment to auto print
            window.print();
        };
    </script>
</body>

</html>