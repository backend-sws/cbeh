<!DOCTYPE html>
<html>

<head>
    <title>Discharge Slip - {{ $ipdPatient->ipd_no }}</title>
    <style>
        /* Base Settings */
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            background: #f3f4f6;
            color: #222;
            line-height: 1.4;
        }

        .container {
            width: 750px;
            margin: 0 auto;
            background: #fff;
            padding: 20px;
            min-height: 100vh;
            box-sizing: border-box;
        }

        h1,
        h2,
        h3,
        h4,
        h5,
        h6 {
            margin: 0;
        }

        .header-title {
            font-size: 18px;
            font-weight: bold;
            color:
                {!! setting('theme_color', '#e91e63') !!}
            ;
            margin-bottom: 5px;
            text-transform: uppercase;
        }

        .doc-title {
            font-size: 16px;
            font-weight: bolder;
            text-align: center;
            text-transform: uppercase;
            border: 3px solid #333;
            padding: 5px;
            width: 200px;
            margin: 45px auto 5px auto;
            border-radius: 4px;
        }

        .section-header {
            font-size: 13px;
            font-weight: bold;
            background: #eee;
            padding: 5px 10px;
            margin-top: 15px;
            margin-bottom: 8px;
            border-left: 4px solid
                {!! setting('theme_color', '#e91e63') !!}
            ;
            text-transform: uppercase;
            /* Header को अकेले पेज के नीचे छूटने से रोकता है */
            page-break-after: avoid;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
            table-layout: fixed;
        }

        .info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border: 1px solid #333;
            word-wrap: break-word;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        /* Medical Content Areas */
        .medical-box {
            padding: 5px 10px;
            min-height: auto;
            /* कंटेंट को पेज पर ठीक से ब्रेक होने देता है */
            page-break-inside: auto;
        }

        .print-btn {
            display: block;
            margin: 20px auto;
            padding: 10px 20px;
            background:
                {!! setting('theme_color', '#e91e63') !!}
            ;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        /* --- PRINT SPECIFIC CSS --- */
        @media print {
            body {
                background: #fff;
            }

            .container {
                width: 100%;
                padding: 0;
                margin: 0;
            }

            .print-btn {
                display: none;
            }

            /* Table Header Group: यह सुनिश्चित करता है कि thead हर पेज पर प्रिंट हो */
            thead {
                display: table-header-group;
            }

            tfoot {
                display: table-footer-group;
            }

            /* Page Margins Setup */
            @page {
                margin: 10mm 10mm 10mm 10mm;
            }

            /* content-wrap को block रखें ताकि table flow सही हो */
            .content-wrap {
                display: block !important;
            }
        }
    </style>
</head>

<body>

    <div class="container">

        <table width="100%">

            <thead>
                <tr>
                    <td>
                        <div
                            style="padding-bottom: 10px; margin-bottom: 10px; border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!}; visibility: hidden;">
                            <table width="100%">
                                <tr>
                                    <td width="20%" style="border: none; background: none;">
                                        <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}"
                                            style="height: 80px;">
                                    </td>
                                    <td width="80%" style="text-align: right; border: none; background: none;">
                                        <div class="header-title">{{ setting('hospital_name', 'Hospital Name') }}</div>
                                        <div style="font-size: 12px; color: #555;">
                                            {{ setting('address', 'Address Line 1') }}<br>
                                            Phone: +91 {{ setting('phone') }} | {{ setting('mobile') }}<br>
                                            Email: {{ setting('email') }}
                                        </div>
                                    </td>
                                </tr>
                            </table>

                        </div>
                    </td>
                </tr>
            </thead>

            <tbody>
                <tr>
                    <td>
                        <div class="doc-title">Discharge Card</div>
                        <div class="content-wrap">

                            <table class="info-table">
                                <colgroup>
                                    <col style="width: 15%;">
                                    <col style="width: 35%;">
                                    <col style="width: 15%;">
                                    <col style="width: 35%;">
                                </colgroup>

                                <tr>
                                    <td class="label">Patient Name:</td>
                                    <td colspan="3">{{ $ipdPatient->patient->name }}</td>
                                </tr>
                                <tr>
                                    <td class="label">UHID:</td>
                                    <td class="val">{{ $uhid ?? '-' }}</td>
                                    <td class="label">IPD No:</td>
                                    <td class="val" style="font-weight: bold;">{{ $ipdPatient->ipd_no }}</td>
                                </tr>
                                <tr>
                                    <td class="label">Age/Sex:</td>
                                    <td class="val">
                                        {{ $ipdPatient->patient->age ?? 'N/A' }} Yrs /
                                        {{ $ipdPatient->patient->gender ?? '-' }}
                                    </td>
                                    <td class="label">Bed/Ward:</td>
                                    <td class="val">{{ $ipdPatient->beds->name ?? 'N/A' }}</td>
                                </tr>
                                <tr>
                                    <td class="label">Address:</td>
                                    <td colspan="3">{{ $ipdPatient->patient->address ?? '' }}</td>
                                </tr>

                                {{-- STATUS LOGIC START --}}
                                @php
                                    $statusShort = $ipdPatient->discharge->discharge_status ?? '';
                                    $displayStatus = 'Not Mentioned';

                                    if ($statusShort == 'Normal') {
                                        $displayStatus = 'Normal / Cured';
                                    } elseif ($statusShort == 'Referred') {
                                        $displayStatus = 'Referred';
                                    } elseif ($statusShort == 'LAMA') {
                                        $displayStatus = 'LAMA (Left Against Medical Advice)';
                                    } elseif ($statusShort == 'Death') {
                                        $displayStatus = 'Death';
                                    } elseif ($statusShort == 'Absconded') {
                                        $displayStatus = 'Absconded';
                                    } elseif ($statusShort == 'DOPR') {
                                        $displayStatus = 'DOPR (Discharge on Patient Request)';
                                    } elseif ($statusShort == 'Improved') {
                                        $displayStatus = 'Improved';
                                    } elseif (!$ipdPatient->discharge_date) {
                                        $displayStatus = 'Admitted (Not Discharged)';
                                    }
                                @endphp
                                {{-- STATUS LOGIC END --}}

                                <tr>
                                    <!--<td class="label">Consultant:</td>-->
                                    <!--<td class="val">{{ $ipdPatient->doctor->name }}</td>-->
                                    <td class="label">Status:</td>
                                    <td class="val" style="font-weight: bold; color: #333;">
                                        {{ $displayStatus }}
                                    </td>
                                </tr>
                                <tr>
                                    <td class="label">D.O.A:</td>
                                    <td class="val">
                                        {{ \Carbon\Carbon::parse($ipdPatient->admission_date)->format('d-m-Y h:i A') }}
                                    </td>
                                    <td class="label">D.O.D:</td>
                                    <td class="val" style="color: red; font-weight: bold;">
                                        @if($ipdPatient->discharge && $ipdPatient->discharge->discharge_date)
                                            {{ \Carbon\Carbon::parse($ipdPatient->discharge->discharge_date)->format('d-m-Y h:i A') }}
                                        @elseif($ipdPatient->discharge_date)
                                            {{ \Carbon\Carbon::parse($ipdPatient->discharge_date)->format('d-m-Y h:i A') }}
                                        @else
                                            Not Discharged
                                        @endif
                                    </td>
                                </tr>
                            </table>

                            {{-- Diagnosis Section --}}
                            @if (isset($ipdPatient->discharge) && !empty($ipdPatient->discharge->diagnosis))
                                <div class="section-header">Diagnosis</div>
                                <div class="medical-box">
                                    {!! nl2br(e($ipdPatient->discharge->diagnosis)) !!}
                                </div>
                            @endif

                            {{-- History Section --}}
                            @if (isset($ipdPatient->discharge) && !empty($ipdPatient->discharge->history))
                                <div class="section-header">Case Summary / History</div>
                                <div class="medical-box">
                                    {!! nl2br(e($ipdPatient->discharge->history)) !!}
                                </div>
                            @endif

                            {{-- Treatment Given Section --}}
                            @if (isset($ipdPatient->discharge) && !empty($ipdPatient->discharge->treatment_given))
                                <div class="section-header">Treatment Given</div>
                                <div class="medical-box">
                                    {!! nl2br(e($ipdPatient->discharge->treatment_given)) !!}
                                </div>
                            @endif

                            {{-- Investigation Section --}}
                            @if (isset($ipdPatient->discharge) && !empty($ipdPatient->discharge->investigations))
                                <div class="section-header">Investigation</div>
                                <div class="medical-box">
                                    {!! nl2br(e($ipdPatient->discharge->investigations)) !!}
                                </div>
                            @endif

                            {{-- Advice Section --}}
                            @if (isset($ipdPatient->discharge) && !empty($ipdPatient->discharge->advice))
                                <div class="section-header">Advice on Discharge</div>
                                <div class="medical-box">
                                    {!! nl2br(e($ipdPatient->discharge->advice)) !!}
                                </div>
                            @endif

                        </div>
                    </td>
                </tr>

                <tr>
                    <td style="padding-top: 80px;">
                        <div class="footer-wrap">
                            <table width="100%">
                                <tr>
                                    <td width="33%" align="center"
                                        style="border:none; background:none; visibility: hidden">
                                        <div style="border-top: 1px solid #333; width: 80%;">Prepared By</div>
                                    </td>
                                    <td width="33%" align="center"
                                        style="border:none; background:none; visibility: hidden">
                                        <div style="border-top: 1px solid #333; width: 80%;">Resident Doctor</div>
                                    </td>
                                    <td width="33%" align="center" style="border:none; background:none; ">
                                        <div style="border-top: 1px solid #333; width: 80%;">Consultant Doctor</div>
                                    </td>
                                </tr>
                            </table>

                            <div
                                style="text-align: center; font-size: 11px; margin-top: 20px; padding-top: 10px; border-top: 1px dashed #ccc; visibility: hidden;">
                                <div style="font-weight: bold; color: {!! setting('theme_color', '#e91e63') !!}">
                                    For Emergency Contact: +91 {{ setting('phone') }}
                                </div>
                                <div>{{ setting('address') }}</div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>

            <tfoot>
                <tr>
                    <td style="height: 80px;">
                        &nbsp; </td>
                </tr>
            </tfoot>
        </table>

        <button onclick="window.print()" class="print-btn">Print Discharge Slip</button>
    </div>

</body>

</html>