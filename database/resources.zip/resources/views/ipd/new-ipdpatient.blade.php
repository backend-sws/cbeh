{{-- filepath: c:\Users\bipin\Downloads\hms\hms\resources\views\ipd\new-ipdpatient.blade.php --}}
@extends('layouts.admin')
@section('title', 'New IPD Patient')
@section('content')
    @push('css')
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    @endpush

    <body class="bg-gray-50 min-h-screen">
        <div class="container mx-auto px-4 py-8">
            @if (session('success'))
                <div class="mb-4 px-4 py-3 rounded bg-green-100 text-green-800 border border-green-300">
                    {{ session('success') }}
                </div>
            @endif
            @if (session('error'))
                <div class="mb-4 px-4 py-3 rounded bg-red-100 text-red-800 border border-red-300">
                    {{ session('error') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="mb-4 px-4 py-3 rounded bg-red-100 text-red-800 border border-red-300">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6">
                <h1 class="text-2xl font-bold text-gray-800">New IPD Patient</h1>
                <a href="{{ url()->previous() }}"
                    class="inline-flex items-center text-main-color hover:text-pink-700 mt-4 sm:mt-0">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd"
                            d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                            clip-rule="evenodd" />
                    </svg>
                    Back
                </a>
            </div>

            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <div class="msg-container px-6 py-4"></div>

                <form id="add_ipd_patient" class="grid grid-cols-1 md:grid-cols-2 gap-6 p-6" method="post"
                    action="{{ route('admin.ipd.save') }}">
                    @csrf

                    <!-- Patient -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Patient <span
                                class="text-red-500">*</span></label>
                        <select name="patient" id="patient"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            required>
                            <option value="">Select Patient</option>
                            @foreach ($patients as $patient)
                                <option value="{{ $patient->id }}"
                                    {{ old('patient', $prefill['patient_id'] ?? '') == $patient->id ? 'selected' : '' }}>
                                    {{ $patient->name }} ({{ $patient->uhid }})
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Case -->
                    <div id="case-container">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Case </label>
                        <input type="text" name="case"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            placeholder="Enter case details">
                    </div>

                    <!-- IPD No -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">IPD No <span
                                class="text-red-500">*</span></label>
                        <input type="text" name="ipd_no"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md bg-gray-50 focus:ring-2 focus:ring-main-color focus:border-main-color"
                            value="{{ $ipdno }}" readonly>
                    </div>

                    <!-- Admission Date -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Admission Date <span
                                class="text-red-500">*</span></label>
                        <input type="datetime-local" name="admission_date" id="admission_date"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color">

                    </div>

                    <!-- Height -->
                    <!-- <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Height (cm) </label>
                                <input type="text" name="height" value="{{ old('height', $prefill['height'] ?? '') }}"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                                    placeholder="Enter height">
                            </div> -->

                    <!-- Blood Pressure -->
                    <!-- <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Blood Pressure</label>
                                <input type="text" name="blood_pressure"
                                    value="{{ old('blood_pressure', $prefill['blood_pressure'] ?? '') }}"
                                    class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                                    placeholder="Enter blood pressure">
                            </div> -->

                    <!-- Doctor -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Doctor <span
                                class="text-red-500">*</span></label>
                        <select name="doctor" id="doctor"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            required>
                            <option value="">Select Doctor</option>
                            @foreach ($doctors as $doctor)
                                <option value="{{ $doctor->id }}"
                                    {{ old('doctor', $prefill['doctor_id'] ?? '') == $doctor->id ? 'selected' : '' }}>
                                    {{ $doctor->name }} <span class="text-xs text-gray-500">{{ $doctor->email }}</span>
                                </option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Bed Type -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Bed Type <span
                                class="text-red-500">*</span></label>
                        <select name="bed_type"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            id="bedType">
                            <option value="">Select Bed Type</option>
                            @foreach ($bedtype as $type)
                                <option value="{{ $type->id }}">{{ $type->name }}</option>
                            @endforeach
                        </select>
                    </div>

                    <!-- Bed -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Bed <span
                                class="text-red-500">*</span></label>
                        <select name="bed"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            id="bed">
                            <option value="">Select Bed</option>
                        </select>
                    </div>

                    <!-- Status -->
                    {{-- <div >
                        <label class="block text-sm font-medium text-gray-700 mb-1">Status <span
                                class="text-red-500">*</span></label>
                        <div class="flex space-x-4 mt-2">
                            <input type="hidden" name="status" value="0" id="status">
                            <button type="button"
                                class="status-success-btn px-4 py-2 rounded-md border border-green-500 bg-green-50 text-green-700 hover:bg-green-100 focus:ring-2 focus:ring-green-500 focus:border-green-500 transition-colors duration-200">
                                <span class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                            clip-rule="evenodd" />
                                    </svg>
                                    Active
                                </span>
                            </button>
                            <button type="button"
                                class="status-danger-btn px-4 py-2 rounded-md border border-red-500 bg-red-50 text-red-700 hover:bg-red-100 focus:ring-2 focus:ring-red-500 focus:border-red-500 transition-colors duration-200">
                                <span class="flex items-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                                            clip-rule="evenodd" />
                                    </svg>
                                    Inactive
                                </span>
                            </button>
                        </div>
                    </div> --}}

                    <!-- Symptoms -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Symptoms</label>
                        <textarea name="symptoms" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            placeholder="Enter symptoms">{{ old('symptoms', $prefill['symptoms'] ?? '') }}</textarea>
                    </div>

                    <!-- Notes -->
                    <div class="md:col-span-2">
                        <label class="block text-sm font-medium text-gray-700 mb-1">Admission Notes</label>
                        <textarea name="notes" rows="3"
                            class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-main-color focus:border-main-color"
                            placeholder="Enter notes"></textarea>
                    </div>

                    <!-- Form Buttons -->
                    <div class="md:col-span-2 flex justify-end space-x-4 pt-4">
                        <button type="button"
                            class="cancel-btn px-6 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-main-color transition-colors duration-200">
                            Cancel
                        </button>
                        <button type="submit"
                            class="px-6 py-2 bg-main-color text-white rounded-md hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-main-color transition-colors duration-200">
                            Save Patient
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </body>
@endsection

@push('js')
    <script src="{{ asset('assets/js/jquery-3.6.0.min.js') }}"></script>
    <script src="{{ asset('assets/js/jquery.validate.min.js') }}"></script>
    <script src="{{ asset('assets/js/ipd-patient.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {

            // Auto-set current datetime for admission date
            let now = new Date();
            now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
            document.getElementById('admission_date').value = now.toISOString().slice(0, 16);

            // Patient select2 for search by name or UHID
            $('#patient').select2({
                placeholder: "Search by name or UHID",
                allowClear: true,
                width: '100%'
            });

            // Doctor select2 for better search
            $('#doctor').select2({
                placeholder: "Select Doctor",
                allowClear: true,
                width: '100%'
            });

            // Bed Type change handler
            $('#bedType').change(function() {
                var bedTypeId = $(this).val();
                if (bedTypeId) {
                    $.ajax({
                        url: '/admin/bed/allbeds/' + bedTypeId,
                        type: 'GET',
                        success: function(response) {
                            if (response.status === 'success') {
                                var beds = response.data;
                                var bedSelect = $('#bed');
                                bedSelect.empty();
                                bedSelect.append('<option value="">Select Bed</option>');
                                $.each(beds, function(index, bed) {
                                    bedSelect.append($('<option>', {
                                        value: bed.id,
                                        text: bed.name
                                    }));
                                });
                            }
                        }
                    });
                } else {
                    $('#bed').empty().append('<option value="">Select Bed</option>');
                }
            });

            // Patient change handler - REMOVED the case loading functionality
            // Now case field will remain as input box always
            $('#patient').on('change', function() {
                // You can add other functionality here if needed
                // But case field will remain as input box
            });

            // Status toggle buttons
            $('.status-success-btn').on('click', function() {
                $('#status').val(1);
                $(this).addClass('bg-green-100 ring-2 ring-green-400');
                $('.status-danger-btn').removeClass('bg-red-100 ring-2 ring-red-400');
            });

            $('.status-danger-btn').on('click', function() {
                $('#status').val(0);
                $(this).addClass('bg-red-100 ring-2 ring-red-400');
                $('.status-success-btn').removeClass('bg-green-100 ring-2 ring-green-400');
            });

            // Cancel button behavior
            $('.cancel-btn').on('click', function() {
                window.location.href = "{{ url()->previous() }}";
            });
        });
    </script>
@endpush
