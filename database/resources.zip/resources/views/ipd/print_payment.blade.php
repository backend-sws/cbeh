<!DOCTYPE html>
<html>

<head>
    <title>IPD Payment Receipt - #{{ $payment->id }}</title>
    <style>
        /* Base Settings */
        html, body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #f8f9fa; /* Light background for screen */
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 750px; /* Standard width */
            margin: 10px auto;
            background: #fff;
            min-height: 100vh;
            padding: 20px 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* --- Header Styles --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        /* --- Patient Info Table --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 5px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
            text-transform: uppercase;
        }

        /* --- Items Table --- */
        .charges-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        .charges-table th, .charges-table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: left;
        }

        .charges-table th {
            background: #f3f4f6; /* Light Gray Header */
            color: #1e293b;
            font-weight: bold;
            text-align: center;
        }

        /* --- Summary Table --- */
        .summary-table {
            width: 45%;
            margin-left: auto;
            margin-top: 15px;
            border-collapse: collapse;
        }

        .summary-table td {
            padding: 6px;
            border-bottom: 1px solid #eee;
            text-align: right;
        }

        .total-row {
            font-weight: bold;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            font-size: 13px;
        }

        /* --- Footer Styles (QR & Signature) --- */
        .footer-split {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: auto; /* Pushes to bottom */
            padding-top: 20px;
        }
        .qr-section { width: 35%; text-align: center; }
        .signature-section { width: 40%; }
        
        .small-points {
            font-size: 9px;
            color: #555;
            text-align: left;
            margin-top: 5px;
            line-height: 1.4;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body { background: #fff; }
            .bill-container { width: 100%; border: none; margin: 0; padding: 0; }
            .print-btn { display: none; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Receipt</button>

    <div class="bill-container">
        
        @if(setting('show_header_ipd_payment', 'yes') == 'yes')
        <table class="header-table">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        {{ setting('tagline', 'Tagline') }}<br>
                        {{ setting('address', 'Address Here') }}<br>
                        Phone: +91 {{ setting('phone') }} | Email: {{ setting('email') }}<br>
                        Website: {{ setting('website', 'www.example.com') }}
                    </div>
                </td>
            </tr>
        </table>
        @else
        <div style="height: {{ setting('spacer_ipd_payment', '180') }}px;"></div>
        @endif

        <div style="text-align:center; font-weight:bold; font-size:16px; margin-top:5px; text-decoration: underline; color: #333;">
            HOSPITAL PAYMENT RECEIPT
        </div>
        {{-- <div style="text-align:center; font-weight:bold; font-size:14px; text-decoration:underline; color: #555; margin-bottom: 10px;">
            PAYMENT RECEIPT
        </div> --}}

        @php
            // Extract Data Logic
            $ipdPatient = $payment->ipdPatient ?? null;
            $billNo = $ipdPatient ? $ipdPatient->ipd_no : 'N/A';
            $patientName = $ipdPatient && $ipdPatient->patient ? $ipdPatient->patient->name : 'N/A';
            // $uhid = $ipdPatient && $ipdPatient->patient ? ($ipdPatient->patient->patient_unique_id ?? '-') : '-'; 
            
            // Calculate Total Bill Amount (Sum of Charges)
            $totalBillAmount = 0;
            if($ipdPatient && $ipdPatient->charges) {
                $totalBillAmount = $ipdPatient->charges->sum('total');
            }
        @endphp

        <div class="section-title">Patient Information</div>
        <table class="info-table">
            <tr>
                <td>Receipt No:</td>
                <td>#IPD-PAY-{{ $payment->id }}</td>
                <td>Date:</td>
                <td>{{ \Carbon\Carbon::parse($payment->payment_date)->format('d-M-Y') }}</td>
            </tr>
            <tr>
                <td>Patient Name:</td>
                <td colspan="3"><strong>{{ $patientName }}</strong></td>
         
            </tr>
            <tr>

                  <td>UHID:</td>
                <td>{{ $uhid }}</td>
                       <td>IPD No:</td>
                <td>{{ $billNo }}</td>
            </tr>
            <tr>

                              
                <td>Age/Gender:</td>
                <td>
                    {{ $ipdPatient->patient->age ?? '0' }} Y 
                    @if($ipdPatient->patient->age_month)
                        {{ $ipdPatient->patient->age_month }} M
                    @endif
                    / {{ $ipdPatient->patient->gender ?? '' }}
                </td>
                <td>Phone:</td>
                <td>{{ $ipdPatient->patient->phone ?? '' }}</td>
                 
            </tr>
            <tr>
                <td>Address:</td>
                <td colspan="3">{{ $ipdPatient->patient->address ?? '' }}</td>
            </tr>
            <!--<tr>-->
            <!--    <td>Consultant:</td>-->
            <!--    <td colspan="3">{{ $ipdPatient->doctor->name ?? '' }}</td>-->
            <!--</tr>-->
        </table>

        <div class="section-title">Transaction Details</div>
        <table class="charges-table">
            <thead>
                <tr>
                    <th width="10%">S.No</th>
                    <th width="50%" style="text-align: left;">Description</th>
                    <th width="20%">Payment Mode</th>
                    <th width="20%" style="text-align: right;">Paid Amount (₹)</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td style="text-align: center;">1</td>
                    <td>
                        Payment Received 
                        {{-- <br><small style="color: #666;">Ref IPD No: {{ $billNo }}</small>
                        @if($payment->note)
                            <br><small style="color: #666; font-style: italic;">Note: {{ $payment->note }}</small>
                        @endif --}}
                    </td>
                    <td style="text-align: center;">{{ $payment->payment_mode->name ?? 'Cash' }}</td>
                    <td style="text-align: right; font-weight: bold;">{{ number_format($payment->amount, 2) }}</td>
                </tr>
            </tbody>
        </table>
        
        <div style="margin-top: 10px; font-style: italic; background: #f9f9f9; padding: 5px; border-left: 3px solid #ccc;">
            <strong>Amount in words:</strong> {{ amountToWords($payment->amount) }} Only.
        </div>

        <div style="margin-top: 20px;">
            <table class="summary-table">
                <tr class="total-row">
                    <td style="border: none;">Amount Received:</td>
                    <td style="border: none;">₹ {{ number_format($payment->amount, 2) }}</td>
                </tr>
                
                <tr><td colspan="2" style="padding:5px;"></td></tr>

                {{-- <tr>
                    <td>Total Bill Amount (Charges):</td>
                    <td>₹ {{ number_format($totalBillAmount, 2) }}</td>
                </tr>
                <tr>
                    <td style="color: #dc2626; font-weight: bold;">Remaining Due Balance:</td>
                    <td style="color: #dc2626; font-weight: bold;">₹ {{ number_format($balanceDue, 2) }}</td>
                </tr> --}}
            </table>
        </div>


        @if(setting('show_footer_ipd_payment', 'yes') == 'yes')
        <div class="footer-split">
            <div class="qr-section">
                @if(setting('hospital_qr'))
                    <img src="{{ asset('img/' . setting('hospital_qr')) }}" style="height: 80px; width: 80px; border: 1px solid #ddd; padding: 3px;">
                @else
                    <div style="height: 80px; width: 80px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">No QR</div>
                @endif
                <div style="font-weight: bold; font-size: 12px; margin-top: 5px; color: #333;">Scan & Pay</div>
                <div class="small-points">
                    <div>* E & O.E. </div>
                        <div>* This is a System Generated Receipt. </div>
                        <div>* This receipt is not Valid for Medico-legal Purpose. </div>
                        <div>* All Legal Claims are Subject to Muzaffarpur Judicial Only.  </div>
                </div>
            </div>

            <div class="signature-section">
                <table width="100%">
                    <tr>
                        <td style="width:50%; text-align:center; border:none;">
                            <div style="height:30px;"></div>
                            <div style="border-top:1px solid #333; width:60%; margin:0 auto;"></div>
                            <div style="font-size:11px; margin-top:3px;">Authorized Signatory</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

        <div style="padding-top:5px; margin-top: 10px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
            {{-- <div style="font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!};">
                For Emergency: +91 {{ setting('phone') }}
            </div> --}}
            <div style="margin-top: 2px; font-size: 14px; color: #000000; font-family: 'Monotype Corsiva', cursive; font-style: italic;">
                Thank you for Payment . Get Well Soon!
            </div>
        </div>
        @endif
    </div>

    <script>
        window.onload = function() {
            window.print(); 
        };
    </script>

</body>
</html>