<!DOCTYPE html>
<html>

<head>
    <title>Purchase Invoice - {{ $purchase->purchase_no }}</title>
    <style>
        /* --- Base Settings --- */
        html, body {
            margin: 0;
            padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            background: #f3f4f6;
            color: #222;
            line-height: 1.3;
        }

        /* --- Print Specifics --- */
        @page {
            margin: 0;
            size: A4;
        }

        /* --- Container --- */
        .bill-container {
            width: 750px;
            margin: 0 auto;
            background: #fff;
            min-height: 100vh;
            box-sizing: border-box;
            position: relative;
        }

        /* --- FIXED HEADER --- */
        .page-header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            height: 190px;
            background: #fff;
            padding: 20px 40px 0 40px;
            z-index: 1000;
        }

        /* --- FIXED FOOTER --- */
        .page-footer {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            height: 230px;
            background: #fff;
            padding: 0 40px 0px 40px;
            z-index: 1000;
        }

        /* --- MAIN TABLE (Controls flow) --- */
        table.main-layout-table {
            width: 100%;
            border-collapse: collapse;
        }

        /* Spacers */
        .header-space { height: 200px; } 
        .footer-space { height: 230px; }

        /* Content Area Padding */
        .content-wrap {
            padding: 0 40px;
        }

        /* --- Inner Content Styles --- */
        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 10px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
        }

        /* Info Tables */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
        }
        .info-table td {
            padding: 5px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }
        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        /* Charges Table */
        .charges-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }
        .charges-table th, .charges-table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: right;
        }
        .charges-table th {
            background: #c2bebe;
            text-align: center;
            font-weight: bold;
            color: #1e293b;
        }
        .charges-table td:nth-child(1) { text-align: left; }

        /* Summary Table */
        .summary-table {
            width: 45%;
            margin-left: auto;
            border-collapse: collapse;
            margin-top: 15px;
            page-break-inside: avoid;
        }
        .summary-table td {
            padding: 5px;
            border-bottom: 1px solid #eee;
            text-align: right;
        }
        .total-row {
            font-weight: bold;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            font-size: 13px;
        }

        /* Note Style */
        .note {
            background: #f9fafb;
            border-radius: 4px;
            padding: 8px 12px;
            margin-top: 10px;
            font-style: italic;
            border-left: 3px solid #ccc;
            color: #555;
        }

        /* Footer Styles */
        .footer-split {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 5px;
            border-top: 1px solid #eee;
            padding-top: 10px;
        }
        .qr-section { width: 35%; text-align: center; }
        .signature-section { width: 60%; }
        
        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body { background: #fff; }
            .bill-container { width: 100%; border: none; margin: 0; padding: 0; }
            .print-btn { display: none; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Invoice</button>

    <div class="bill-container">

        <div class="page-header">
            @if(setting('show_header_pharmacy_purchase', 'yes') == 'yes')
            <table width="100%" style="border-bottom:2px solid {!! setting('theme_color', '#e91e63') !!}; padding-bottom:10px;">
                <tr>
                    <td style="width:90px; vertical-align:top;">
                        <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Logo" style="height:70px;">
                    </td>
                    <td style="text-align:right; vertical-align:top;">
                        <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                            {{ setting('hospital_name', 'Hospital Name') }}
                        </div>
                        <div style="font-size:12px; color:#555;">
                            {{ setting('tagline', 'Tagline') }}<br>
                            {{ setting('address', 'Hospital Address Here') }}<br>
                            Phone: +91 {{ setting('phone', '0000000000') }}<br>
                            Email: {{ setting('email', 'email@example.com') }}
                        </div>
                    </td>
                </tr>
            </table>
            @else
            <div style="height: {{ setting('spacer_pharmacy_purchase', '180') }}px;"></div>
            @endif

            <div style="text-align:center; font-weight:bold; font-size:16px; text-decoration: underline; margin-top:8px; color: #333;">
                PURCHASE INVOICE
            </div>
        </div>

        <div class="page-footer">
            <div class="footer-split">
                {{-- <div class="qr-section">
                    @if(setting('hospital_qr'))
                        <img src="{{ asset('img/' . setting('hospital_qr')) }}" style="height: 85px; width: 85px; border: 1px solid #ddd; padding: 3px;">
                    @else
                        <div style="height: 85px; width: 85px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">No QR</div>
                    @endif
                    <div style="font-weight: bold; font-size: 11px; margin-top: 5px; color: #333;">Scan for Info</div>
                </div> --}}

                {{-- <div class="signature-section">
                    <table width="100%">
                        <tr>
                            <td style="width:50%; text-align:center; border:none;">
                                <div style="height:40px;"></div>
                                <div style="border-top:1px solid #333; width:80%; margin:0 auto;"></div>
                                <div style="font-size:11px; margin-top:3px;">Supplier Signature</div>
                            </td>
                            <td style="width:50%; text-align:center; border:none;">
                                <div style="height:40px;"></div>
                                <div style="border-top:1px solid #333; width:80%; margin:0 auto;"></div>
                                <div style="font-size:11px; margin-top:3px;">Receiver Signature</div>
                            </td>
                        </tr>
                    </table>
                </div> --}}
            </div>

            {{-- <div style="padding-top:5px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555; margin-bottom: 20px;">
                <div style="margin-top: 2px;">
                    This is a computer generated purchase record.
                </div>
            </div> --}}
        </div>

        <table class="main-layout-table">
            
            <thead>
                <tr><td><div class="header-space">&nbsp;</div></td></tr>
            </thead>

            <tbody>
                <tr>
                    <td>
                        <div class="content-wrap">
                            
                            <div class="section-title">Purchase Details</div>
                            <table class="info-table">
                                <tr>
                                    <td>Purchase No:</td>
                                    <td>{{ $purchase->purchase_no }}</td>
                                    <td>Purchase Date:</td>
                                    <td>{{ \Carbon\Carbon::parse($purchase->created_at)->format('d-M-Y') }}</td>
                                </tr>
                                <tr>
                                    <td>Supplier Name:</td>
                                    <td>{{ $purchase->supplier_name ?? 'N/A' }}</td>
                                    <td>Bill/Invoice No:</td>
                                    <td>{{ $purchase->bill_number ?? 'N/A' }}</td>
                                </tr>
                            </table>

                            <div class="section-title">Purchased Items</div>
                            <table class="charges-table">
                                <thead>
                                    <tr>
                                        <th width="5%">S.No</th>
                                        <th >Medicine Name</th>
                                        <th width="15%">Batch No</th>
                                        <th width="12%">Expiry</th>
                                        <th width="10%">Qty</th>
                                        <th width="10%">Tax%</th>
                                        <th width="15%">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($purchase->purchasedMedicines as $index => $item)
                                        <tr>
                                            <td style="text-align: center;">{{ $index + 1 }}</td>
                                            <td style="text-align: center">
                                                {{ $item->medicine->medicine ?? 'N/A' }}
                                            </td>
                                            <td style="text-align: center;">{{ $item->lot_no ?? '-' }}</td>
                                            <td style="text-align: center;">
                                                {{ $item->expiry_date ? \Carbon\Carbon::parse($item->expiry_date)->format('M-Y') : '-' }}
                                            </td>
                                            <td style="text-align: center;">{{ $item->quantity }}</td>
                                            <td style="text-align: center;">{{ $item->tax }}%</td>
                                            <td>{{ number_format($item->amount, 2) }}</td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>

                            <div style="margin-top: 15px;">
                                <table class="summary-table">
                                    <tr>
                                        <td>Sub Total:</td>
                                        <td>₹ {{ number_format($purchase->total, 2) }}</td>
                                    </tr>
                                    @if($purchase->tax > 0)
                                        <tr>
                                            <td>Total Tax:</td>
                                            <td>+ ₹ {{ number_format($purchase->tax, 2) }}</td>
                                        </tr>
                                    @endif
                                    @if($purchase->discount > 0)
                                        <tr>
                                            <td>Discount:</td>
                                            <td>- ₹ {{ number_format($purchase->discount, 2) }}</td>
                                        </tr>
                                    @endif
                                    <tr>
                                        <td style="font-weight: bold; border-top: 1px dashed #ccc;">Net Payable:</td>
                                        <td style="font-weight: bold; border-top: 1px dashed #ccc; font-size: 14px;">₹ {{ number_format($purchase->net_amount, 2) }}</td>
                                    </tr>
                                </table>
                            </div>

                            @if ($purchase->payment_note)
                                <div class="note"><strong>Payment Note:</strong> {{ $purchase->payment_note }}</div>
                            @endif

                            @if ($purchase->note)
                                <div class="note"><strong>Note:</strong> {{ $purchase->note }}</div>
                            @endif

                        </div>
                    </td>
                </tr>
            </tbody>

            <tfoot>
                <tr><td><div class="footer-space">&nbsp;</div></td></tr>
            </tfoot>

        </table>
    </div>

    <script>
        window.onload = function() {
            window.print(); 
        };
    </script>
</body>
</html>