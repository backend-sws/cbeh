<!DOCTYPE html>
<html>

<head>
    <title>OPD Blank Receipt - {{ $opdPatient->opd_no }}</title>
    <style>
        /* Base Settings */
        html,
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #f8f9fa;
            /* Light background for screen */
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 750px;
            /* Standard width */
            margin: 10px auto;
            background: #fff;
            min-height: 100vh;
            padding: 20px 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* --- Header Styles --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        /* --- Patient Info Table --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 5px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
            width: 15%;
        }

        .info-table td:nth-child(even) {
            width: 35%;
        }

        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 5px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
            text-transform: uppercase;
        }

        /* --- Vitals Table --- */
        .vitals-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #333;
            margin-bottom: 10px;
        }

        .vitals-table td {
            border: 1px solid #333;
            padding: 6px 8px;
            vertical-align: top;
        }

        .vitals-label {
            font-weight: bold;
            background-color: #f9f9f9;
            white-space: nowrap;
            width: 1%;
        }

        /* --- Writing Area --- */
        .writing-area {
            flex: 1;
            border-radius: 4px;
            min-height: 300px;
            margin-top: 10px;
            margin-bottom: 50px;
        }

        /* --- Footer Styles --- */
        .footer-content {
            margin-top: auto;
            text-align: center;
            border-top: 1px dashed {!! setting('theme_color', '#e91e63') !!};
            padding-top: 10px;
            font-size: 11px;
            color: #555;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body {
                background: #fff;
            }

            .bill-container {
                width: 100%;
                border: none;
                margin: 0;
                padding: 0;
            }

            .print-btn {
                display: none;
            }

            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* Ensure writing area takes available space */
            .writing-area {
                min-height: auto;
                height: auto;
            }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Blank Prescription</button>

    <div class="bill-container">

        @if(setting('show_header_opd_blank', 'yes') == 'yes')
        <table class="header-table">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div
                        style="font-size:18px; font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        {{ setting('tagline', 'Tagline') }}<br>
                        {{ setting('address', 'Address Here') }}<br>
                        Phone: +91 {{ setting('phone') }} | Email: {{ setting('email') }}<br>
                        Website: {{ setting('website', 'www.example.com') }}
                    </div>
                </td>
            </tr>
        </table>
        @else
        <div style="height: {{ setting('spacer_opd_blank', '180') }}px;"></div>
        @endif

        <div
            style="text-align:center; font-weight:bold; font-size:16px; margin-top:45px; text-decoration: underline; color: #333;">
            OPD PRESCRIPTION
        </div>

        <div class="section-title">Patient Information</div>
        <table class="info-table">
            <tr>
                <td>Patient Name:</td>
                <td colspan="3"><strong>{{ $opdPatient->patient->name ?? '-' }}</strong></td>
            </tr>
            <tr>
                <td>OPD No:</td>
                <td>{{ $opdPatient->opd_no ?? '-' }}</td>
                <td>UHID:</td>
                <td>{{ $patient_uhid ?? '-' }}</td>

            </tr>
            <tr>
                <td>Age/Gender:</td>
                <td>
                    {{ $opdPatient->patient->age ?? '0' }} Y 
                    @if($opdPatient->patient->age_month)
                        {{ $opdPatient->patient->age_month }} M
                    @endif
                    / {{ $opdPatient->patient->gender ?? '' }}
                </td>
                <td>Date:</td>
                <td>{{ \Carbon\Carbon::parse($opdPatient->date)->format('d-m-Y') ?? '-' }}</td>

            </tr>
            <tr>
                <td>Address:</td>
                <td colspan="3">{{ $opdPatient->patient->address ?? '' }}</td>
            </tr>
            <!--<tr>-->
            <!--    <td>Consultant:</td>-->
            <!--    <td colspan="3"><strong>{{ $opdPatient->doctor->name ?? '-' }}</strong></td>-->
            <!--</tr>-->
        </table>

        @php
            $spo2 = $opdPatient->spo2 ?? ($opdPatient->SpO2 ?? null);
            // Updated check to include Pulse and Temperature
            $hasVitals =
                $opdPatient->height ||
                $opdPatient->weight ||
                $opdPatient->blood_pressure ||
                $opdPatient->pulse ||
                $opdPatient->temperature ||
                $spo2 ||
                $opdPatient->symptoms;
        @endphp

        @if ($hasVitals)
            <div class="section-title">Clinical Vitals</div>
            <table class="vitals-table">
                @if (
                    $opdPatient->height ||
                        $opdPatient->weight ||
                        $opdPatient->blood_pressure ||
                        $opdPatient->pulse ||
                        $opdPatient->temperature ||
                        $spo2)
                    <tr>
                        @if ($opdPatient->height)
                            <td class="vitals-label">Height:</td>
                            <td>{{ $opdPatient->height }} cm</td>
                        @endif
                        @if ($opdPatient->weight)
                            <td class="vitals-label">Weight:</td>
                            <td>{{ $opdPatient->weight }} kg</td>
                        @endif
                         {{-- Added Pulse --}}
                        @if ($opdPatient->pulse)
                            <td class="vitals-label">Pulse:</td>
                            <td>{{ $opdPatient->pulse }} bpm</td>
                        @endif
                        @if ($opdPatient->blood_pressure)
                            <td class="vitals-label">BP:</td>
                            <td>{{ $opdPatient->blood_pressure }} mmHg</td>
                        @endif
                       
                        {{-- Added Temperature --}}
                        @if ($opdPatient->temperature)
                            <td class="vitals-label">Temp:</td>
                            <td>{{ $opdPatient->temperature }} °F</td>
                        @endif
                        @if ($spo2)
                            <td class="vitals-label">SpO2:</td>
                            <td>{{ $spo2 }}%</td>
                        @endif
                    </tr>
                @endif

                @if ($opdPatient->symptoms)
                    <tr>
                        <td class="vitals-label">Chief Complaint (C/E):</td>
                        <td colspan="12">{{ $opdPatient->symptoms }}</td>
                    </tr>
                @endif
            </table>
        @endif

        <div class="section-title"></div>
        <div class="writing-area">
        </div>

        @if(setting('show_footer_opd_blank', 'yes') == 'yes')
        <table width="100%" style="margin-top:auto; margin-bottom: 20px;">
            <tr>
                <td style="width:50%; text-align: center;"></td>
                <td style="width:50%; text-align:right; padding-right: 20px;">
                    <div style="height: 60px;"></div>
                    <div style="border-top:1px solid #333; width:200px; display:inline-block; margin-bottom: 5px;">
                    </div>
                    <div style="font-weight: bold; margin-right: 35px;">Consultant's Signature</div>
                </td>
            </tr>
        </table>

        <div class="footer-content">
            <div style="font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!};">
                For Emergency Services: +91 {{ setting('phone', '0000000000') }}
            </div>
            <div>
                {{ setting('address', 'Patna: Opposite SBI, Bhootnath Road, Patna-800026') }}
            </div>
        </div>
        @endif

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>