<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Diagnosis Report - {{ $group_test_no }}</title>

    <style>
        /* Base Settings */
        html,
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #f8f9fa;
            /* Light background for screen */
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 750px;
            /* Standard A4 width */
            margin: 10px auto;
            background: #fff;
            min-height: 100vh;
            padding: 20px 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        /* --- Header Styles --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 25px;
        }

        /* --- Patient Info Table --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 5px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
            width: 15%;
        }

        .info-table td:nth-child(even) {
            width: 35%;
        }

        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 5px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
            text-transform: uppercase;
        }

        /* --- Test/Investigation Table --- */
        .test-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        .test-table th,
        .test-table td {
            border: 1px solid #ccc;
            padding: 6px 8px;
            text-align: left;
            vertical-align: middle;
        }

        .test-table th {
            background: #ccc;
            /* Light Gray Header */
            color: #1e293b;
            font-weight: bold;
        }

        /* Badges for Urgency */
        .badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 10px;
            font-weight: bold;
            display: inline-block;
            border: 1px solid transparent;
        }

        /* --- Footer Styles (QR & Signature) --- */
        .footer-split {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: auto;
            padding-top: 20px;
        }

        .qr-section {
            width: 35%;
            text-align: center;
        }

        .signature-section {
            width: 40%;
        }

        .small-points {
            font-size: 9px;
            color: #555;
            text-align: left;
            margin-top: 5px;
            line-height: 1.4;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body {
                background: #fff;
            }

            .bill-container {
                width: 100%;
                border: none;
                margin: 0;
                padding: 0;
            }

            .print-btn {
                display: none;
            }

            * {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
            }

            /* Print Specific Border Fixes */
            .info-table,
            .info-table td,
            .test-table,
            .test-table th,
            .test-table td {
                border: 1px solid #000 !important;
            }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Report</button>

    <div class="bill-container">

        {{-- ===== HEADER ===== --}}
        @if(setting('show_header_opd_diagnosis', 'yes') == 'yes')
        <table class="header-table">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #555;">
                        {{ setting('tagline', 'Tagline') }}<br>
                        {{ setting('address', 'Address Here') }}<br>
                        Phone: +91 {{ setting('phone') }}, {{ setting('mobile') }}<br>
                        Website: {{ setting('website', 'www.example.com') }}
                    </div>
                </td>
            </tr>
        </table>
        @else
        <div style="height: {{ setting('spacer_opd_diagnosis', '180') }}px;"></div>
        @endif

        <div
            style="text-align:center; font-weight:bold; font-size:16px; margin-top:45px; text-decoration: underline; color: #333;"">
            DIAGNOSIS 
        </div>

        {{-- ===== PATIENT INFORMATION ===== --}}
        <div class="section-title">Patient Information</div>
        <table class="info-table">
            {{-- <tr>
                <td>Group ID:</td>
                <td>{{ $group_test_no ?? '-' }}</td>
                
            </tr> --}}
            <tr>
                <td>Name:</td>
                <td colspan="3"><strong>{{ $patient->name ?? '' }}</strong></td>
            </tr>
            <tr>
                <td>Age/Gender:</td>
                <td>{{ $patient->age ?? '' }} Y / {{ $patient->gender ?? '' }}</td>
                <td>UHID:</td>
                <td>{{ $patient_uhid ?? '' }}</td>
            </tr>
            <tr>
                <td>Phone:</td>
                <td>{{ $patient->phone ?? '' }}</td>
                <td>Date:</td>
                <td>{{ $generated_date }}</td>
            </tr>
            <tr>
                <td>Address:</td>
                <td colspan="3">{{ $patient->address ?? '' }}</td>
            </tr>
            <!--<tr>-->
            <!--    <td>Consultant:</td>-->
            <!--    <td colspan="3"><strong>Dr. {{ $doctor->name ?? '' }}</strong></td>-->
            <!--</tr>-->

        </table>

        {{-- ===== REQUIRED INVESTIGATIONS ===== --}}
        <div class="section-title">Required Investigations</div>
        <table class="test-table">
            <thead>
                <tr>
                    <th width="5%">#</th>
                    <th width="45%">Test Name</th>
                    <th width="30%">Department / Category</th>
                    <th width="20%">Priority</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($tests as $index => $test)
                    <tr>
                        <td>{{ $index + 1 }}</td>
                        <td>
                            <strong>{{ $test->test_name }}</strong>
                        </td>
                        <td>{{ $test->chargeCategory->charge_category ?? 'N/A' }}</td>
                        <td>
                            @php
                                $urgency = $test->urgency ?? 'Normal';
                                $bg = '#e8f5e9';
                                $color = '#2e7d32'; // Normal (Green)

                                if ($urgency == 'Urgent') {
                                    $bg = '#fff8e1';
                                    $color = '#ff8f00'; // Orange
                                } elseif ($urgency == 'Stat') {
                                    $bg = '#ffebee';
                                    $color = '#c62828'; // Red
                                }
                            @endphp
                            <span class="badge"
                                style="background-color: {{ $bg }}; color: {{ $color }}; border-color: {{ $bg }};">
                                {{ $urgency }}
                            </span>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        {{-- ===== FOOTER SPLIT (QR + SIGNATURE) ===== --}}
        @if(setting('show_footer_opd_diagnosis', 'yes') == 'yes')
        <div class="footer-split">
            <div class="qr-section">
                @if (setting('hospital_qr'))
                    <img src="{{ asset('img/' . setting('hospital_qr')) }}"
                        style="height: 80px; width: 80px; border: 1px solid #ddd; padding: 3px;">
                @else
                    <div
                        style="height: 80px; width: 80px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">
                        No QR</div>
                @endif
                <div style="font-weight: bold; font-size: 12px; margin-top: 5px; color: #333;">Scan & Pay</div>
                <div class="small-points">
                    <div>* Sample collection as per standard protocols.</div>
                    <div>* Report delivery time depends on test type.</div>
                </div>
            </div>

            <div class="signature-section">
                <table width="100%">
                    <tr>
                        <td style="width:50%; text-align:center; border:none;">
                            <div style="height:30px;"></div>
                            <div style="border-top:1px solid #333; width:60%; margin:0 auto;"></div>
                            <div style="font-size:11px; margin-top:3px;">Authorized Signatory / Lab In-charge</div>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        @endif

        {{-- ===== BOTTOM STRIP ===== --}}
        {{-- <div style="padding-top:5px; margin-top: 10px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
            <div style="font-weight:bold; color: {!! setting('theme_color', '#e91e63') !!};">
                For Emergency Services: +91 {{ setting('phone') }}, {{ setting('mobile') }}
            </div>
            <div>
                {{ setting('address') }}
            </div>
        </div> --}}

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>

</body>

</html>
