@extends('layouts.admin')
@section('title', 'OPD Patient Details')
@section('content')

    <body class="bg-gray-50">
        <div class="container mx-auto px-4 py-8">
            @if ($errors->any())
                <div class="mb-4">
                    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded">
                        <ul class="list-disc pl-5 text-sm">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            @endif

            @if (session('success'))
                <div class="mb-4">
                    <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-2 rounded">
                        {{ session('success') }}
                    </div>
                </div>
            @endif
            <div class="bg-white rounded-xl shadow-md overflow-hidden">
                <!-- Patient Header Section -->
                <div class="p-6 md:p-8 flex flex-col md:flex-row items-start md:items-center gap-6 border-b border-gray-100">
                    <div class="shrink-0">
                        @if ($opd_patient->patient->image)
                            <img src="{{ asset('avatar/' . $opd_patient->patient->image) }}"
                                class="w-24 h-24 md:w-28 md:h-28 rounded-full border-2 border-white shadow-sm object-cover"
                                alt="Patient Image">
                        @else
                            @php
                                $name = $opd_patient->patient->name ?? '';
                                $initials = collect(explode(' ', $name))
                                    ->map(fn($part) => strtoupper(substr($part, 0, 1)))
                                    ->take(2)
                                    ->implode('');
                            @endphp
                            <div class="w-24 h-24 md:w-28 md:h-28 rounded-full flex items-center justify-center text-white text-3xl font-bold shadow-sm"
                                style="background: linear-gradient(135deg, #ec4899 0%, #f472b6 100%);">
                                {{ $initials }}
                            </div>
                        @endif
                    </div>
                    <div class="flex-1 w-full">
                        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                            <div>
                                <span
                                    class="inline-block px-2 py-1 text-xs font-medium bg-pink-50 text-pink-600 rounded-md mb-1">#{{ $opd_patient->opd_no }}</span>
                                <h1 class="text-2xl md:text-3xl font-bold text-gray-800">{{ $opd_patient->patient->name }}
                                </h1>
                                <p class="text-gray-600">{{ $opd_patient->patient->email }}</p>
                            </div>
                            <div class="flex-shrink-0">
                                <span
                                    class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium 
                            {{ $opd_patient->is_old_patient ? 'bg-green-100 text-green-800' : 'bg-pink-100 text-pink-800' }}">
                                    {{ $opd_patient->is_old_patient ? 'Returning Patient' : 'New Patient' }}
                                </span>
                            </div>
                        </div>

                        <div class="flex flex-wrap gap-4 md:gap-6 mt-4 pt-4 border-t border-gray-100">
                            <div class="text-center">
                                <div class="text-xl font-bold text-pink-600">{{ $opd_patient->patient->cases_count ?? 1 }}
                                </div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Cases</div>
                            </div>
                            <div class="text-center">
                                <div class="text-xl font-bold text-pink-600">
                                    {{ $opd_patient->patient->admissions_count ?? 1 }}</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Admissions</div>
                            </div>
                            <div class="text-center">
                                <div class="text-xl font-bold text-pink-600">
                                    {{ $appointments_count }}
                                </div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Appointments</div>
                            </div>
                            <div class="text-center">
                                <div class="text-xl font-bold text-pink-600">
                                    {{ $opd_patient->patient->prescriptions_count ?? 0 }}</div>
                                <div class="text-xs text-gray-500 uppercase tracking-wider">Prescriptions</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tab Navigation -->
                <div class="border-b border-gray-200">
                    <nav class="flex overflow-x-auto">
                        <button data-tab="overview"
                            class="tab-button active px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 border-pink-500 text-pink-600">
                            <i class="fas fa-info-circle mr-2"></i>Overview
                        </button>
                        <button data-tab="visits"
                            class="tab-button px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            <i class="fas fa-calendar-alt mr-2"></i>Visits
                        </button>
                        <button data-tab="diagnosis"
                            class="tab-button px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            <i class="fas fa-stethoscope mr-2"></i>Uploads Diagnosis
                        </button>
                        <button data-tab="diagnosis-tests"
                            class="tab-button px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            <i class="fas fa-vials mr-2"></i>Diagnosis Tests
                        </button>

                        <button data-tab="prescriptions"
                            class="tab-button px-6 py-4 text-sm font-medium whitespace-nowrap border-b-2 border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300">
                            <i class="fas fa-prescription-bottle-alt mr-2"></i>Prescriptions
                        </button>

                    </nav>
                </div>

                <!-- Tab Content -->
                <div class="p-6 md:p-8">
                    <!-- Overview Tab -->
                    <div id="overview" class="tab-content">
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div>
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Patient
                                    Details</h3>
                                <div class="space-y-4">
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Assigned Doctor</p>
                                            <div class="flex items-center mt-1">
                                                <div class="flex-shrink-0 h-10 w-10">
                                                    @if (!empty($opd_patient->doctor->image))
                                                        <img class="h-10 w-10 rounded-full object-cover"
                                                            src="{{ asset('avatar/' . $opd_patient->doctor->image) }}"
                                                            alt="{{ $opd_patient->doctor->name ?? 'N/A' }}">
                                                    @else
                                                        @php
                                                            $docName = $opd_patient->doctor->name ?? '';
                                                            $docInitials = collect(explode(' ', $docName))
                                                                ->map(fn($part) => strtoupper(substr($part, 0, 1)))
                                                                ->take(2)
                                                                ->implode('');
                                                        @endphp
                                                        <div class="h-10 w-10 rounded-full flex items-center justify-center text-white text-base font-bold shadow-sm"
                                                            style="background: linear-gradient(135deg, #ec4899 0%, #f472b6 100%);">
                                                            {{ $docInitials }}
                                                        </div>
                                                    @endif
                                                </div>
                                                <div class="ml-3">
                                                    <p class="font-medium">{{ $opd_patient->doctor->name ?? 'N/A' }}</p>
                                                    <p class="text-sm text-gray-500">
                                                        {{ $opd_patient->doctor->specialization ?? '' }}
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                        {{-- <div>
                                            <p class="text-sm text-gray-500">Case ID</p>
                                            <p class="font-medium">{{ $opd_patient->case ?? 'N/A' }}</p>
                                        </div> --}}
                                        <div>
                                            <p class="text-sm text-gray-500">Appointment Date</p>
                                            <p class="font-medium">
                                                {{ \Carbon\Carbon::parse($opd_patient->appointment_date)->format('jS M, Y h:i A') }}
                                            </p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Height</p>
                                            <p class="font-medium">{{ $opd_patient->height ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Weight</p>
                                            <p class="font-medium">{{ $opd_patient->weight ?? 'N/A' }}</p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Guardian Name</p>
                                            <p class="font-medium">{{ $opd_patient->patient->guardian_name ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Alternate Phone</p>
                                            <p class="font-medium">{{ $opd_patient->patient->alternate_phone ?? 'N/A' }}
                                            </p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Marital Status</p>
                                            <p class="font-medium">{{ $opd_patient->patient->marital_status ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Blood Group</p>
                                            <p class="font-medium">{{ $opd_patient->patient->blood_group ?? 'N/A' }}</p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Address</p>
                                            <p class="font-medium">{{ $opd_patient->patient->address ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Alternate Address</p>
                                            <p class="font-medium">{{ $opd_patient->patient->alternate_address ?? 'N/A' }}
                                            </p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">Remarks</p>
                                            <p class="font-medium">{{ $opd_patient->patient->remarks ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Allergies</p>
                                            <p class="font-medium">{{ $opd_patient->patient->allergies ?? 'N/A' }}</p>
                                        </div>
                                    </div>
                                    <div class="grid grid-cols-2 gap-4">
                                        <div>
                                            <p class="text-sm text-gray-500">UHID</p>
                                            <p class="font-medium">{{ $opd_patient->patient_unique_id ?? 'N/A' }}</p>
                                        </div>
                                        <div>
                                            <p class="text-sm text-gray-500">Blood Pressure</p>
                                            <p class="font-medium">{{ $opd_patient->blood_pressure ?? 'N/A' }}</p>
                                        </div>
                                    </div>


                                </div>
                            </div>

                            <div>
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b border-gray-200">Medical
                                    Information</h3>
                                <div class="space-y-4">
                                    <div>
                                        <p class="text-sm text-gray-500">Symptoms</p>
                                        <div class="mt-1 p-3 bg-gray-50 rounded-md">
                                            <p class="text-gray-700">
                                                {{ $opd_patient->symptoms ?? 'No symptoms recorded' }}
                                            </p>
                                        </div>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Notes</p>
                                        <div class="mt-1 p-3 bg-gray-50 rounded-md">
                                            <p class="text-gray-700">{{ $opd_patient->notes ?? 'No notes available' }}</p>
                                        </div>
                                    </div>
                                </div>

                                <h3 class="text-lg font-semibold text-gray-800 mt-6 mb-4 pb-2 border-b border-gray-200">
                                    Billing Information</h3>
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <p class="text-sm text-gray-500">Payment Mode</p>
                                        <p class="font-medium">{{ $opd_patient->payment_mode ?? 'N/A' }}</p>
                                    </div>
                                    <div>
                                        <p class="text-sm text-gray-500">Standard Charge</p>
                                        <p class="font-medium">₹{{ number_format($opd_patient->standard_charge, 2) }}</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="mt-8 pt-6 border-t border-gray-200">
                            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                                <div>
                                    <p class="text-sm text-gray-500">Created On</p>
                                    <p class="font-medium">{{ $opd_patient->created_at->format('jS M, Y h:i A') }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Last Updated</p>
                                    <p class="font-medium">{{ $opd_patient->updated_at->format('jS M, Y h:i A') }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Created By</p>
                                    <p class="font-medium">System</p>
                                </div>
                                <div>
                                    <p class="text-sm text-gray-500">Status</p>
                                    <span
                                        class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                        Active
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Visits Tab -->
                    <div id="visits" class="tab-content hidden">
                        <div class="bg-white p-6 rounded-lg border border-gray-200">
                            <h3 class="text-lg font-medium text-gray-700 mb-4">Patient Visits</h3>
                            @if (isset($appointments) && $appointments->count())
                                <div class="overflow-x-auto">
                                    <table class="min-w-full divide-y divide-gray-200">
                                        <thead>
                                            <tr class="bg-gray-50">
                                                <th
                                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                                    OPD No</th>
                                                <th
                                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                                    Doctor</th>
                                                <th
                                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                                    Appointment Date</th>
                                                <th
                                                    class="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">
                                                    Standard Charge</th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-100">
                                            @foreach ($appointments as $visit)
                                                <tr>
                                                    <td class="px-4 py-2 font-semibold text-pink-600">
                                                        {{ $opd_patient->opd_no }}
                                                    </td>
                                                    <td class="px-4 py-2">
                                                        <div class="font-medium">
                                                            {{ optional($visit->doctor)->name ?? 'N/A' }}</div>
                                                        <div class="text-xs text-gray-500">
                                                            {{ optional($visit->doctor)->email ?? '' }}</div>
                                                    </td>
                                                    <td class="px-4 py-2">
                                                        <div>
                                                            {{ \Carbon\Carbon::parse($visit->appointment_date)->format('g:i A') }}
                                                        </div>
                                                        <div class="text-xs text-gray-500">
                                                            {{ \Carbon\Carbon::parse($visit->appointment_date)->format('jS M, Y') }}
                                                        </div>
                                                    </td>
                                                    <td class="px-4 py-2">
                                                        ₹{{ number_format($opd_patient->standard_charge, 2) }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <div class="text-center py-8 text-gray-500">
                                    <i class="fas fa-calendar-alt text-4xl text-gray-300 mb-4"></i>
                                    <p>No visits found for this patient.</p>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Diagnosis Tab -->
                    <div id="diagnosis" class="tab-content hidden">
                        <div class="bg-white p-6 rounded-lg border border-gray-200">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-medium text-gray-700">Diagnosis Records</h3>
                                <button
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-pink-600 hover:bg-pink-700 focus:outline-none"
                                    onclick="document.getElementById('diagnosisModal').classList.remove('hidden')">
                                    <i class="fas fa-plus mr-2"></i> Add Diagnosis
                                </button>
                            </div>
                            @if (isset($diagnoses) && $diagnoses->count())
                                <div class="overflow-x-auto">
                                    <table class="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead>
                                            <tr class="bg-gray-50">
                                                <th class="px-4 py-2 text-left font-semibold text-gray-600">#</th>
                                                <th class="px-4 py-2 text-left font-semibold text-gray-600">Report Type
                                                </th>
                                                <th class="px-4 py-2 text-left font-semibold text-gray-600">Report Date
                                                </th>
                                                <th class="px-4 py-2 text-left font-semibold text-gray-600">Document</th>
                                                <th class="px-4 py-2 text-left font-semibold text-gray-600">Description
                                                </th>
                                                <th class="px-4 py-2 text-center font-semibold text-gray-600">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody class="bg-white divide-y divide-gray-100">
                                            @foreach ($diagnoses as $index => $diagnosis)
                                                <tr>
                                                    <td class="px-4 py-2">{{ $index + 1 }}</td>
                                                    <td class="px-4 py-2 font-medium text-gray-800">
                                                        {{ $diagnosis->report_type }}</td>
                                                    <td class="px-4 py-2">
                                                        {{ \Carbon\Carbon::parse($diagnosis->report_date)->format('jS M, Y') }}
                                                    </td>
                                                    <td class="px-4 py-2">
                                                        @if ($diagnosis->document)
                                                            <a href="{{ asset($diagnosis->document) }}" target="_blank"
                                                                class="inline-flex items-center px-2 py-1 bg-pink-50 text-pink-600 rounded hover:bg-pink-100 transition">
                                                                <i class="fas fa-file-alt mr-1"></i> View
                                                            </a>
                                                        @else
                                                            <span class="text-gray-400">N/A</span>
                                                        @endif
                                                    </td>
                                                    <td class="px-4 py-2">{{ $diagnosis->description }}</td>
                                                    <td class="px-4 py-2 text-center">
                                                        <button
                                                            class="inline-flex items-center px-2 py-1 text-xs font-medium rounded bg-yellow-100 text-yellow-800 hover:bg-yellow-200 mr-2"
                                                            onclick="editDiagnosis({{ $diagnosis->id }}, '{{ addslashes($diagnosis->report_type) }}', '{{ $diagnosis->report_date }}', '{{ addslashes($diagnosis->description) }}', '{{ $diagnosis->document ? asset($diagnosis->document) : '' }}')">
                                                            <i class="fas fa-edit mr-1"></i> Edit
                                                        </button>
                                                        <form
                                                            action="{{ route('admin.diagnosis.destroy', $diagnosis->id) }}"
                                                            method="POST" class="inline-block"
                                                            onsubmit="return confirm('Are you sure you want to delete this diagnosis?');">
                                                            @csrf
                                                            @method('DELETE')
                                                            <button type="submit"
                                                                class="inline-flex items-center px-2 py-1 text-xs font-medium rounded bg-red-100 text-red-700 hover:bg-red-200">
                                                                <i class="fas fa-trash mr-1"></i> Delete
                                                            </button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <div class="text-center py-8 text-gray-500">
                                    <i class="fas fa-stethoscope text-4xl text-gray-300 mb-4"></i>
                                    <p>No diagnosis records found.</p>
                                </div>
                            @endif
                        </div>

                        <!-- Diagnosis Modal (Add/Edit) -->
                        {{-- <div id="diagnosisModal"
                        class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden">
                        <div class="bg-white rounded-lg shadow-lg w-full max-w-lg p-6 relative">
                            <button class="absolute top-2 right-2 text-gray-400 hover:text-gray-600 text-xl"
                                onclick="document.getElementById('diagnosisModal').classList.add('hidden')">&times;</button>
                            <h2 id="diagnosisModalTitle" class="text-lg font-semibold mb-4 text-pink-600">Add
                                Diagnosis</h2>
                            <form id="diagnosisForm" action="{{ route('admin.diagnosis.store') }}" method="POST"
                                enctype="multipart/form-data">
                                @csrf
                                <input type="hidden" name="opd_patient_id" value="{{ $opd_patient->id }}">
                                <input type="hidden" name="diagnosis_id" id="diagnosis_id">
                                <input type="hidden" name="_method" id="diagnosis_method" value="POST">
                                @if ($errors->any())
                                    <div class="mb-4">
                                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-2 rounded">
                                            <ul class="list-disc pl-5 text-sm">
                                                @foreach ($errors->all() as $error)
                                                    <li>{{ $error }}</li>
                                                @endforeach
                                            </ul>
                                        </div>
                                    </div>
                                @endif
                                <div class="mb-4">
                                    <label class="block text-sm font-medium mb-1">Report Type</label>
                                    <input type="text" name="report_type" id="report_type"
                                        class="w-full border rounded p-2" required>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-medium mb-1">Report Date</label>
                                    <input type="date" name="report_date" id="report_date"
                                        class="w-full border rounded p-2" required>
                                </div>
                                <div class="mb-4" id="diagnosis-document-preview" style="display:none;">
                                    <label class="block text-sm font-medium mb-1">Current Document</label>
                                    <a href="#" target="_blank" id="diagnosis-document-link"
                                        class="text-pink-600 underline">View Document</a>
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-medium mb-1">Document</label>
                                    <input type="file" name="document" id="document"
                                        class="w-full border rounded p-2">
                                </div>
                                <div class="mb-4">
                                    <label class="block text-sm font-medium mb-1">Description</label>
                                    <textarea name="description" id="description" class="w-full border rounded p-2" rows="3"></textarea>
                                </div>
                                <div class="flex justify-end">
                                    <button type="button"
                                        class="mr-2 px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 diagnosis-cancel-btn">Cancel</button>
                                    <button type="submit"
                                        class="px-4 py-2 rounded bg-pink-600 text-white hover:bg-pink-700">Save</button>
                                </div>
                            </form>
                        </div>
                    </div> --}}
                        <!-- Diagnosis Modal (Add/Edit) -->
                        <div id="diagnosisModal"
                            class="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50 hidden">
                            <div class="bg-white rounded-lg shadow-lg w-full max-w-md p-4 relative"
                                style="max-height: 90vh; overflow: hidden;">
                                <button class="absolute top-2 right-2 text-gray-400 hover:text-gray-600 text-xl"
                                    onclick="document.getElementById('diagnosisModal').classList.add('hidden')">&times;</button>
                                <h2 id="diagnosisModalTitle" class="text-base font-semibold mb-3 text-pink-600">Add
                                    Diagnosis</h2>
                                <form id="diagnosisForm" action="{{ route('admin.diagnosis.store') }}" method="POST"
                                    enctype="multipart/form-data" class="overflow-y-auto" style="max-height: 70vh;">
                                    @csrf
                                    <input type="hidden" name="opd_patient_id" value="{{ $opd_patient->id }}">
                                    <input type="hidden" name="diagnosis_id" id="diagnosis_id">
                                    <input type="hidden" name="_method" id="diagnosis_method" value="POST">
                                    @if ($errors->any())
                                        <div class="mb-3">
                                            <div
                                                class="bg-red-100 border border-red-400 text-red-700 px-3 py-2 rounded text-xs">
                                                <ul class="list-disc pl-4">
                                                    @foreach ($errors->all() as $error)
                                                        <li>{{ $error }}</li>
                                                    @endforeach
                                                </ul>
                                            </div>
                                        </div>
                                    @endif
                                    <div class="mb-3">
                                        <label class="block text-xs font-medium mb-1">Report Type</label>
                                        <input type="text" name="report_type" id="report_type"
                                            class="w-full border rounded p-2 text-sm" required>
                                    </div>
                                    <div class="mb-3">
                                        <label class="block text-xs font-medium mb-1">Report Date</label>
                                        <input type="date" name="report_date" id="report_date"
                                            class="w-full border rounded p-2 text-sm" required>
                                    </div>
                                    <div class="mb-3" id="diagnosis-document-preview" style="display:none;">
                                        <label class="block text-xs font-medium mb-1">Current Document</label>
                                        <a href="#" target="_blank" id="diagnosis-document-link"
                                            class="text-pink-600 underline text-xs">View Document</a>
                                    </div>
                                    <div class="mb-3">
                                        <label class="block text-xs font-medium mb-1">Document</label>
                                        <input type="file" name="document" id="document"
                                            class="w-full border rounded p-2 text-xs">
                                    </div>
                                    <div class="mb-3">
                                        <label class="block text-xs font-medium mb-1">Description</label>
                                        <textarea name="description" id="description" class="w-full border rounded p-2 text-sm" rows="2"></textarea>
                                    </div>
                                    <div class="flex justify-end gap-2 mt-2">
                                        <button type="button"
                                            class="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300 text-xs diagnosis-cancel-btn">Cancel</button>
                                        <button type="submit"
                                            class="px-3 py-1 rounded bg-pink-600 text-white hover:bg-pink-700 text-xs">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- Diagnosis Tests Tab -->
                    <!-- Diagnosis Tests Tab -->
                    <div id="diagnosis-tests" class="tab-content hidden">
                        <div class="bg-white p-6 rounded-lg border border-gray-200">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-medium text-gray-700">Diagnosis Tests</h3>
                                <button
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-pink-600 hover:bg-pink-700"
                                    onclick="openDiagnosisTestModal()">+ Add Diagnosis Tests</button>
                            </div>
                            <div id="diagnosisTestTableWrap">
                                @if (isset($diagnosis_tests) && $diagnosis_tests->count())
                                    <div class="overflow-x-auto">
                                        <table class="min-w-full divide-y divide-gray-200 text-sm">
                                            <thead>
                                                <tr class="bg-gray-50">
                                                    <th class="px-4 py-2">Patient Name</th>
                                                    <th class="px-4 py-2">Doctor Name</th>
                                                    <th class="px-4 py-2">Total Tests</th>
                                                    <th class="px-4 py-2">Date</th>
                                                    <th class="px-4 py-2 text-center">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody class="bg-white divide-y divide-gray-100">
                                                @forelse ($diagnosis_tests_groups as $group_no => $tests)
                                                    <tr>
                                                        <td class="px-4 py-2">{{ $opd_patient->patient->name ?? '' }}</td>
                                                        <td class="px-4 py-2">{{ $opd_patient->doctor->name ?? '' }}</td>
                                                        <td class="px-4 py-2">{{ $tests->count() }}</td>
                                                        <td class="px-4 py-2">
                                                            {{ $tests->first()->created_at ? $tests->first()->created_at->format('d M Y, h:i A') : '' }}
                                                        </td>
                                                        <td class="px-4 py-2 text-center">
                                                            <a href="{{ route('diagnosis-tests.pdf', ['groupTestNo' => $group_no]) }}"
                                                                target="_blank"
                                                                class="px-3 py-1 bg-green-100 text-green-800 rounded inline-flex items-center mr-2">
                                                                <i class="fas fa-file-pdf mr-1"></i> PDF
                                                            </a>
                                                            <button class="px-3 py-1 bg-blue-100 text-blue-800 rounded"
                                                                onclick="previewDiagnosisTestAll('{{ $group_no }}')">
                                                                <i class="fas fa-eye"></i> Preview
                                                            </button>
                                                        </td>
                                                    </tr>
                                                @empty
                                                    <tr>
                                                        <td colspan="5" class="text-center py-4 text-gray-400">No
                                                            diagnosis tests found.</td>
                                                    </tr>
                                                @endforelse
                                            </tbody>
                                        </table>
                                    </div>
                                @else
                                    <div class="text-center py-8 text-gray-500">
                                        <i class="fas fa-vials text-4xl text-gray-300 mb-4"></i>
                                        <p>No diagnosis tests found.</p>
                                    </div>
                                @endif
                            </div>
                        </div>


                        <!-- Diagnosis Test Preview Modal -->
                        <div id="diagnosisTestPreviewModal"
                            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden p-4">
                            <div class="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[95vh] flex flex-col">
                                <!-- Modal Header -->
                                <div class="flex items-center justify-between p-6 border-b border-gray-200">
                                    <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                                        <i class="fas fa-vials mr-2 text-pink-600"></i>
                                        Diagnosis Test Details
                                    </h2>
                                    <div class="flex items-center space-x-4">
                                        <a id="diagnosisPdfBtn" href="#" target="_blank"
                                            class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded shadow hover:bg-green-700 transition-colors">
                                            <i class="fas fa-file-pdf mr-2"></i> Download PDF
                                        </a>
                                        <button type="button" aria-label="Close"
                                            class="text-gray-400 hover:text-gray-600 text-2xl"
                                            onclick="closeDiagnosisTestPreviewModal()">
                                            &times;
                                        </button>
                                    </div>
                                </div>

                                <!-- Modal Body -->
                                <div class="overflow-y-auto flex-1 p-6">
                                    <!-- Clinic/Doctor Info -->
                                    <div class="flex flex-wrap justify-between items-center mb-6">
                                        <div class="mb-4 md:mb-0">
                                            <img src="{{ asset('img/site-logo.png') }}" alt="Logo"
                                                class="h-12 mb-2">
                                            <div class="text-sm font-semibold text-gray-700">
                                                {{ setting('hospital_name') }}</div>
                                            <div class="text-xs text-gray-500">
                                                <i class="fas fa-map-marker-alt mr-1"></i>
                                                {{ setting('address') }}
                                            </div>
                                            <div class="text-xs text-gray-500">
                                                <i class="fas fa-phone-alt mr-1"></i> +91 {{ setting('phone') }} |
                                                <i class="fas fa-globe ml-1 mr-1"></i> {{ setting('website') }}
                                            </div>
                                        </div>
                                        <div class="text-right">
                                            <div class="text-xs text-gray-500">Generated Date:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewCreatedOn">--
                                            </div>
                                            <div class="text-xs text-gray-500 mt-2">Date:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewTestDate">--
                                            </div>
                                        </div>
                                    </div>

                                    <hr class="my-4 border-gray-200">

                                    <!-- Patient & OPD Info -->
                                    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                                        <div class="bg-gray-50 p-3 rounded-lg">
                                            <div class="text-xs text-gray-500">OPD No:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewOpdNo">--</div>
                                        </div>
                                        <div class="bg-gray-50 p-3 rounded-lg">
                                            <div class="text-xs text-gray-500">Patient Name:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewPatientName">--
                                            </div>
                                        </div>
                                        <div class="bg-gray-50 p-3 rounded-lg">
                                            <div class="text-xs text-gray-500">Doctor:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewDoctorName">--
                                            </div>
                                        </div>

                                        <div class="bg-gray-50 p-3 rounded-lg">
                                            <div class="text-xs text-gray-500">UHID:</div>
                                            <div class="font-semibold text-gray-800" id="diagnosisPreviewUhid">--</div>
                                        </div>
                                    </div>

                                    <!-- Test Details -->
                                    <div class="mb-4">
                                        <h3 class="text-md font-semibold text-gray-700 mb-2 flex items-center">
                                            <i class="fas fa-flask mr-2 text-blue-500"></i>
                                            Test Details
                                        </h3>
                                        <div class="overflow-x-auto">
                                            <table class="min-w-full text-sm border border-gray-200">
                                                <thead class="bg-gray-100">
                                                    <tr>
                                                        <th class="px-4 py-2 text-left font-medium text-gray-700 border">#
                                                        </th>
                                                        <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Test Name</th>
                                                        {{-- <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Test Code</th> --}}
                                                        <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Type</th>
                                                        <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Urgency</th>
                                                        <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Test Date</th>
                                                        {{-- <th class="px-4 py-2 text-left font-medium text-gray-700 border">
                                                            Price</th> --}}
                                                    </tr>
                                                </thead>
                                                <tbody id="diagnosisPreviewTestsTable" class="divide-y divide-gray-200">
                                                    <!-- Will be populated by JavaScript -->
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    <!-- Footer Notes -->
                                    <div class="text-xs text-gray-500 mt-6 border-t pt-4">
                                        <p class="mb-1"><i class="fas fa-info-circle mr-1"></i> This is an
                                            electronically generated report. No signature is required.</p>
                                        <p><i class="fas fa-clock mr-1"></i> Report generated on: <span
                                                id="diagnosisPreviewGeneratedOn">{{ now()->format('d M Y, h:i A') }}</span>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <script>
                            function previewDiagnosisTestAll(group_no) {
                                // Show loading state
                                const modal = document.getElementById('diagnosisTestPreviewModal');
                                modal.classList.remove('hidden');
                                const tbody = document.getElementById('diagnosisPreviewTestsTable');
                                tbody.innerHTML = '<tr><td colspan="7" class="text-center py-4">Loading test details...</td></tr>';

                                fetch(`/admin/diagnosis-tests?opd_patient_id={{ $opd_patient->id }}&group_test_no=${group_no}`)
                                    .then(response => {
                                        if (!response.ok) {
                                            throw new Error('Network response was not ok');
                                        }
                                        return response.json();
                                    })
                                    .then(data => {
                                        // Safely update elements only if they exist
                                        const setTextIfExists = (id, text) => {
                                            const element = document.getElementById(id);
                                            if (element) element.textContent = text || '--';
                                        };

                                        // Basic Info
                                        setTextIfExists('diagnosisPreviewCreatedOn', data.tests?.[0]?.created_at_formatted);
                                        setTextIfExists('diagnosisPreviewTestDate', data.tests?.[0]?.test_date ? formatDate(data.tests[0]
                                            .test_date) : '--');
                                        setTextIfExists('diagnosisPreviewOpdNo', data.opd_no);
                                        setTextIfExists('diagnosisPreviewPatientName', data.patient?.name);
                                        setTextIfExists('diagnosisPreviewDoctorName', data.doctor?.name);
                                        setTextIfExists('diagnosisPreviewUhid', data.uhid);

                                        // Tests Table
                                        tbody.innerHTML = '';

                                        if (data.tests?.length) {
                                            data.tests.forEach((test, index) => {
                                                const row = document.createElement('tr');
                                                row.className = 'hover:bg-gray-50';
                                                row.innerHTML = `
                        <td class="px-4 py-2 border">${index + 1}</td>
                        <td class="px-4 py-2 border font-medium">${test.test_name?.replace(' - ', '') || '--'}</td>

                        <td class="px-4 py-2 border">${test.test_type || '--'}</td>
                        <td class="px-4 py-2 border">
                            <span class="px-2 py-1 text-xs rounded-full ${getUrgencyClass(test.urgency)}">
                                ${test.urgency || 'Routine'}
                            </span>
                        </td>
                        <td class="px-4 py-2 border">${test.test_date ? formatDate(test.test_date) : '--'}</td>
                      
                    `;
                                                tbody.appendChild(row);
                                            });
                                        } else {
                                            tbody.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center py-4 text-gray-400">No test details available</td>
                    </tr>
                `;
                                        }

                                        // Update PDF button if exists
                                        const pdfBtn = document.getElementById('diagnosisPdfBtn');
                                        if (pdfBtn) {
                                            pdfBtn.href =
                                                `/admin/diagnosis-tests/pdf/${group_no}`;
                                        }
                                    })
                                    .catch(error => {
                                        console.error('Error loading diagnosis tests:', error);
                                        tbody.innerHTML = `
                <tr>
                    <td colspan="7" class="text-center py-4 text-red-500">
                        Error loading test details: ${error.message}
                    </td>
                </tr>
            `;
                                    });
                            }

                            // Helper functions
                            function formatDate(dateString) {
                                if (!dateString) return '--';
                                const date = new Date(dateString);
                                return isNaN(date) ? dateString : date.toLocaleDateString('en-GB', {
                                    day: 'numeric',
                                    month: 'short',
                                    year: 'numeric'
                                });
                            }

                            function getUrgencyClass(urgency) {
                                switch (urgency) {
                                    case 'Stat':
                                        return 'bg-red-100 text-red-800';
                                    case 'Urgent':
                                        return 'bg-orange-100 text-orange-800';
                                    default:
                                        return 'bg-blue-100 text-blue-800';
                                }
                            }

                            function closeDiagnosisTestPreviewModal() {
                                document.getElementById('diagnosisTestPreviewModal').classList.add('hidden');
                            }
                        </script>

                        <!-- Diagnosis Test Modal (Multiple Rows) -->
                        <!-- Diagnosis Test Modal (Professional & Responsive) -->
                        <!-- Diagnosis Test Modal -->
                        {{-- <div id="diagnosisTestModal"
                            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden p-4">
                            <div class="bg-white rounded-xl shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
                                <!-- Modal Header -->
                                <div class="flex items-center justify-between p-6 border-b border-gray-200">
                                    <h2 id="diagnosisTestModalTitle" class="text-xl font-semibold text-gray-800">
                                        <i class="fas fa-vials mr-2 text-pink-600"></i>
                                        <span>Add Diagnosis Tests</span>
                                    </h2>
                                    <button class="text-gray-400 hover:text-gray-600 text-2xl"
                                        onclick="closeDiagnosisTestModal()">
                                        &times;
                                    </button>
                                </div>

                                <!-- Modal Body -->
                                <form id="diagnosisTestForm" method="POST" class="overflow-y-auto flex-1 p-6"
                                    onsubmit="return false;">
                                    @csrf
                                    <input type="hidden" name="opd_patient_id" value="{{ $opd_patient->id }}">
                                    <input type="hidden" name="patient_id" value="{{ $opd_patient->patient_id }}">
                                    <input type="hidden" name="doctor_id" value="{{ $opd_patient->doctor_id }}">
                                    <input type="hidden" name="opd_no" value="{{ $opd_patient->opd_no }}">

                                    <div class="flex justify-between items-center mb-3">
                                        <h3 class="text-sm font-medium text-gray-700">Diagnosis Test Items</h3>
                                        <button type="button" id="addDiagnosisTestRow"
                                            class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none">
                                            <i class="fas fa-plus mr-1"></i> Add Test Row
                                        </button>
                                    </div>

                                    <!-- Table -->
                                    <div class="overflow-x-auto">
                                        <table class="min-w-full divide-y divide-gray-200 border border-gray-200"
                                            id="diagnosisTestRowsTable">
                                            <thead>
                                                <tr class="bg-gray-50">
                                                    <th class="px-3 py-2 border">#</th>
                                                    <th class="px-3 py-2 border">Category</th>
                                                    <th class="px-3 py-2 border">Test Type</th>
                                                    <th class="px-3 py-2 border">Charge</th>
                                                    <th class="px-3 py-2 border">Urgency</th>
                                                    <th class="px-3 py-2 border">Date</th>
                                                    <th class="px-3 py-2 border">Instructions</th>
                                                    <th class="px-3 py-2 border">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="diagnosisTestRowsBody" class="bg-white divide-y divide-gray-200">
                                                <tr>
                                                    <td class="px-3 py-2 border">1</td>
                                                    <td class="px-3 py-2">
                                                        <select name="charge_category_id[]"
                                                            class="w-full border rounded p-1 text-sm charge-category"
                                                            required onchange="loadChargeTypes(this)">
                                                            <option value="">Select Category</option>
                                                            @foreach ($chargeCategories as $category)
                                                                <option value="{{ $category->id }}">
                                                                    {{ $category->charge_category }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <select name="charge_type_id[]"
                                                            class="w-full border rounded p-1 text-sm charge-type" required
                                                            onchange="loadStandardCharge(this)">
                                                            <option value="">Select Type</option>
                                                            <!-- Will be populated via AJAX -->
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <input type="number" name="standard_charge[]"
                                                            class="w-full border rounded p-1 text-sm standard-charge"
                                                            readonly>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <select name="urgency[]" class="w-full border rounded p-1 text-sm"
                                                            required>
                                                            <option value="">Select Urgency</option>
                                                            <option value="Routine">Routine</option>
                                                            <option value="Stat">Urgent</option>
                                                            <option value="Urgent">Very Urgent</option>
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <input type="date" name="test_date[]"
                                                            class="w-full border rounded p-1 text-sm" required>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <input type="text" name="special_instructions[]"
                                                            class="w-full border rounded p-1 text-sm">
                                                    </td>
                                                    <td class="px-3 py-2 text-center">
                                                        <button type="button"
                                                            class="deleteDiagnosisTestRow text-red-500 hover:text-red-700 px-2"
                                                            title="Delete">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal Footer -->
                                    <div class="flex justify-end gap-3 pt-6 border-t border-gray-200 mt-6">
                                        <button type="button" onclick="closeDiagnosisTestModal()"
                                            class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                                            Cancel
                                        </button>
                                        <button type="submit"
                                            class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-pink-600 hover:bg-pink-700 focus:outline-none">
                                            Save All
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div> --}}


                        <!-- Diagnosis Test Modal -->
                        <div id="diagnosisTestModal"
                            class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden p-4">
                            <div class="bg-white rounded-xl shadow-xl w-full max-w-3xl max-h-[90vh] flex flex-col">
                                <!-- Modal Header -->
                                <div class="flex items-center justify-between p-6 border-b border-gray-200">
                                    <h2 id="diagnosisTestModalTitle" class="text-xl font-semibold text-gray-800">
                                        <i class="fas fa-vials mr-2 text-pink-600"></i>
                                        <span>Add Diagnosis Tests</span>
                                    </h2>
                                    <button class="text-gray-400 hover:text-gray-600 text-2xl"
                                        onclick="closeDiagnosisTestModal()">
                                        &times;
                                    </button>
                                </div>

                                <!-- Modal Body -->
                                <form id="diagnosisTestForm" method="POST" class="overflow-y-auto flex-1 p-6"
                                    onsubmit="return false;">
                                    @csrf
                                    <input type="hidden" name="opd_patient_id" value="{{ $opd_patient->id }}">
                                    <input type="hidden" name="patient_id" value="{{ $opd_patient->patient_id }}">
                                    <input type="hidden" name="doctor_id" value="{{ $opd_patient->doctor_id }}">
                                    <input type="hidden" name="opd_no" value="{{ $opd_patient->opd_no }}">

                                    <div class="flex justify-between items-center mb-3">
                                        <h3 class="text-sm font-medium text-gray-700">Diagnosis Test Items</h3>
                                        <button type="button" id="addDiagnosisTestRow"
                                            class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none">
                                            <i class="fas fa-plus mr-1"></i> Add Test Row
                                        </button>
                                    </div>

                                    <!-- Table -->
                                    <div class="overflow-x-auto">
                                        <table class="min-w-full divide-y divide-gray-200 border border-gray-200"
                                            id="diagnosisTestRowsTable">
                                            <thead>
                                                <tr class="bg-gray-50">
                                                    <th class="px-3 py-2 border">#</th>
                                                    <th class="px-3 py-2 border">Test Type</th>
                                                    <th class="px-3 py-2 border">Category</th>
                                                    <th class="px-3 py-2 border hidden">Charge</th>
                                                    <th class="px-3 py-2 border">Urgency</th>
                                                    <th class="px-3 py-2 border">Date</th>
                                                    <th class="px-3 py-2 border">Instructions</th>
                                                    <th class="px-3 py-2 border">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody id="diagnosisTestRowsBody" class="bg-white divide-y divide-gray-200">
                                                <tr>
                                                    <td class="px-3 py-2 border">1</td>
                                                    <td class="px-3 py-2">
                                                        <select name="charge_type_id[]"
                                                            class="w-full border rounded p-1 text-sm charge-type" required
                                                            onchange="loadChargeCategories(this)">
                                                            <option value="">Select Type</option>
                                                            @foreach ($chargeTypes as $type)
                                                                <option value="{{ $type->id }}">{{ $type->name }}
                                                                </option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <select name="charge_category_id[]"
                                                            class="w-full border rounded p-1 text-sm charge-category"
                                                            required onchange="loadStandardCharge(this)">
                                                            <option value="">Select Category</option>
                                                            <!-- Will be populated via AJAX -->
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2 hidden">
                                                        <input type="number" name="standard_charge[]"
                                                            class="w-full border rounded p-1 text-sm standard-charge "
                                                            readonly>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <select name="urgency[]" class="w-full border rounded p-1 text-sm"
                                                            required>
                                                            <option value="">Select Urgency</option>
                                                            <option value="Routine">Routine</option>
                                                            <option value="Stat">Urgent</option>
                                                            <option value="Urgent">Very Urgent</option>
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <input type="date" name="test_date[]"
                                                            class="w-full border rounded p-1 text-sm" required>
                                                    </td>
                                                    <td class="px-3 py-2">
                                                        <input type="text" name="special_instructions[]"
                                                            class="w-full border rounded p-1 text-sm">
                                                    </td>
                                                    <td class="px-3 py-2 text-center">
                                                        <button type="button"
                                                            class="deleteDiagnosisTestRow text-red-500 hover:text-red-700 px-2"
                                                            title="Delete">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>

                                    <!-- Modal Footer -->
                                    <div class="flex justify-end gap-3 pt-6 border-t border-gray-200 mt-6">
                                        <button type="button" onclick="closeDiagnosisTestModal()"
                                            class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none">
                                            Cancel
                                        </button>
                                        <button type="submit"
                                            class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-pink-600 hover:bg-pink-700 focus:outline-none">
                                            Save All
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>






                    <!-- Prescriptions Tab -->

                    <!-- Prescriptions Tab -->
                    <div id="prescriptions" class="tab-content hidden">
                        <div class="bg-white p-6 rounded-lg border border-gray-200">
                            <div class="flex justify-between items-center mb-4">
                                <h3 class="text-lg font-medium text-gray-700">Prescriptions</h3>
                                <button
                                    class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-pink-600 hover:bg-pink-700"
                                    onclick="openPrescriptionModal()">+ Add Prescription</button>
                            </div>
                            @if (isset($prescriptions) && $prescriptions->count())
                                <div class="overflow-x-auto">
                                    <table class="min-w-full divide-y divide-gray-200 text-sm">
                                        <thead>
                                            <tr class="bg-gray-50">
                                                <th class="px-4 py-2">#</th>
                                                <th class="px-4 py-2">OPD No</th>
                                                <th class="px-4 py-2">Patient Name</th>
                                                <th class="px-4 py-2">Doctor Name</th>
                                                <th class="px-4 py-2">Created On</th>
                                                <th class="px-4 py-2 text-center">Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($prescriptions as $index => $pres)
                                                <tr>
                                                    <td class="px-4 py-2">{{ $index + 1 }}</td>
                                                    <td class="px-4 py-2">{{ $opd_patient->opd_no }}</td>
                                                    <td class="px-4 py-2">{{ $opd_patient->patient->name ?? '' }}</td>
                                                    <td class="px-4 py-2">{{ $opd_patient->doctor->name ?? '' }}</td>
                                                    <td class="px-4 py-2">
                                                        {{ \Carbon\Carbon::parse($pres->created_at)->format('jS M, Y h:i A') }}
                                                    </td>
                                                    <td class="px-4 py-2 text-center">
                                                        <a href="{{ route('opd.prescriptions.pdf', $pres->id) }}"
                                                            target="_blank"
                                                            class="inline-flex items-center px-2 py-1 bg-green-600 text-white rounded shadow hover:bg-green-700">
                                                            <i class="fas fa-print mr-2"></i>Print
                                                        </a>
                                                        <button class="px-2 py-1 bg-blue-100 text-blue-800 rounded mr-2"
                                                            onclick="previewPrescription({{ $pres->id }})">
                                                            <i class="fas fa-eye"></i> Preview
                                                        </button>
                                                        <button
                                                            class="px-2 py-1 bg-yellow-100 text-yellow-800 rounded mr-2"
                                                            onclick="editPrescription({{ $pres->id }})">Edit</button>
                                                        <form action="{{ route('opd.prescriptions.destroy', $pres->id) }}"
                                                            method="POST" class="inline-block"
                                                            onsubmit="return confirm('Delete this prescription?')">
                                                            @csrf @method('DELETE')
                                                            <button type="submit"
                                                                class="px-2 py-1 bg-red-100 text-red-700 rounded">Delete</button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <div class="text-center py-8 text-gray-500">
                                    <i class="fas fa-prescription-bottle-alt text-4xl text-gray-300 mb-4"></i>
                                    <p>No prescriptions found.</p>
                                </div>
                            @endif
                        </div>
                    </div>

                    <!-- Prescription Modal (Add/Edit) -->
                    <!-- Prescription Modal (Add/Edit) -->
                    <div id="prescriptionModal"
                        class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden p-4">
                        <div class="bg-white rounded-xl shadow-xl w-full max-w-4xl max-h-[90vh] flex flex-col">
                            <!-- Modal Header -->
                            <div class="flex items-center justify-between p-6 border-b border-gray-200">
                                <h2 id="prescriptionModalTitle" class="text-xl font-semibold text-gray-800">
                                    <i class="fas fa-prescription-bottle-alt mr-2 text-blue-600"></i>
                                    <span>Add Prescription</span>
                                </h2>
                                <button class="text-gray-400 hover:text-gray-600 text-2xl"
                                    onclick="closePrescriptionModal()">
                                    &times;
                                </button>
                            </div>

                            <!-- Modal Body -->
                            <form id="prescriptionForm" action="{{ route('opd.prescriptions.store') }}" method="POST"
                                class="overflow-y-auto flex-1 p-6">
                                @csrf
                                <input type="hidden" name="patient_id" value="{{ $opd_patient->patient_id }}">
                                <input type="hidden" name="doctor_id" value="{{ $opd_patient->doctor_id }}">
                                <input type="hidden" name="_method" id="prescription_method" value="POST">
                                <input type="hidden" name="prescription_id" id="prescription_id">

                                <!-- Basic Information Section -->
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">Prescription Date:
                                            <span class="text-red-500">*</span>
                                        </label>
                                        <input type="date" name="prescription_date" id="prescription_date"
                                            class="w-full border rounded p-2 text-sm" required
                                            value="{{ old('prescription_date', date('Y-m-d')) }}">
                                    </div>

                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-1">
                                            Status <span class="text-red-500">*</span>
                                        </label>
                                        <select name="status" id="status"
                                            class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                                            required>
                                            <option value="active" selected>Active</option>
                                            <option value="draft">Draft</option>
                                        </select>
                                    </div>
                                </div>

                                <!-- Header Notes -->
                                <div class="mb-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-1">
                                        Notes
                                    </label>
                                    <textarea
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                                        rows="2" name="headernotes" id="headernotes" placeholder="Enter any header notes..."></textarea>
                                </div>

                                <!-- Divider -->
                                <div class="border-t border-gray-200 my-4"></div>

                                <!-- Prescription Items Section -->
                                <div class="mb-4">
                                    <div class="flex justify-between items-center mb-3">
                                        <h3 class="text-sm font-medium text-gray-700">Prescription Items</h3>
                                        <button type="button" id="addOpdPrescriptionItem"
                                            class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                            <i class="fas fa-plus mr-1"></i> Add Item
                                        </button>
                                    </div>

                                    <div class="overflow-x-auto">
                                        <table class="min-w-full divide-y divide-gray-200 border border-gray-200"
                                            id="opdPrescriptionTbl">
                                            <thead class="bg-gray-50">
                                                <tr>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-8">
                                                        #</th>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Category</th>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Medicine</th>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Dosage</th>
                                                    {{-- <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Duration</th>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Interval</th> --}}
                                                    {{-- <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Time</th> --}}
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                        Instructions</th>
                                                    <th scope="col"
                                                        class="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-10">
                                                        Action</th>
                                                </tr>
                                            </thead>
                                            <tbody
                                                class="bg-white divide-y divide-gray-200 opd-prescription-item-container">
                                                <tr>
                                                    <td class="px-3 py-2 whitespace-nowrap text-sm text-gray-500 text-center opd-prescription-item-number"
                                                        data-item-number="1">1</td>
                                                    <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 opdCategoryId"
                                                            required name="category_id[]">
                                                            <option value="">Select Category</option>
                                                            @foreach ($medicine_categories as $cat)
                                                                <option value="{{ $cat->id }}">
                                                                    {{ $cat->medicine_category }}</option>
                                                            @endforeach
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 medicineId"
                                                            required name="medicine_id[]">
                                                            <option value="">Select Medicine</option>
                                                        </select>
                                                    </td>
                                                    <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                                            name="dosage[]" required>
                                                            <option value="">Select Dosage</option>
                                                            <option value="BBF">BBF</option>
                                                            <option value="OD">OD</option>
                                                            <option value="BD">BD</option>
                                                            <option value="TDS">TDS</option>
                                                            <option value="QID">QID</option>
                                                            <option value="SOS">SOS</option>
                                                        </select>
                                                    </td>
                                                    {{-- <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 opdDuration"
                                                            name="duration[]" required>
                                                            <option value="">Select</option>
                                                            <option value="1">1 day</option>
                                                            <option value="3">3 days</option>
                                                            <option value="7">1 week</option>
                                                            <option value="14">2 weeks</option>
                                                            <option value="30">1 month</option>
                                                        </select>
                                                    </td> --}}
                                                    {{-- <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 opdDoseInterval"
                                                            name="doseInterval[]" required>
                                                            <option value="">Select</option>
                                                            <option value="1">Morning</option>
                                                            <option value="2">Morning & Evening</option>
                                                            <option value="3">Morning, Noon, Evening</option>
                                                            <option value="4">4 times a day</option>
                                                        </select>
                                                    </td> --}}
                                                    {{-- <td class="px-3 py-2 whitespace-nowrap">
                                                        <select
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 opdPrescriptionMedicineMealId"
                                                            name="time[]" required>
                                                            <option value="">Select</option>
                                                            <option value="0">After Meal</option>
                                                            <option value="1">Before Meal</option>
                                                            <option value="2">Bed Time</option>
                                                        </select>
                                                    </td> --}}
                                                    <td class="px-3 py-2">
                                                        <textarea placeholder="Remarks..."
                                                            class="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 instruction"
                                                            rows="1" name="instructions[]"></textarea>
                                                    </td>
                                                    <td class="px-3 py-2 whitespace-nowrap text-center">
                                                        <button type="button"
                                                            class="text-red-500 hover:text-red-700 deleteopdPrescription"
                                                            title="Delete">
                                                            <i class="fas fa-trash-alt"></i>
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>

                                <!-- Footer Notes -->
                                <div class="mt-6">
                                    <label class="block text-sm font-medium text-gray-700 mb-1">
                                        Investigation Advice
                                    </label>
                                    <textarea
                                        class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 text-sm"
                                        rows="2" name="footernotes" id="footernotes" placeholder="Enter any footer notes..."></textarea>
                                </div>

                                <!-- Modal Footer -->
                                <div class="flex justify-end gap-3 pt-6 border-t border-gray-200 mt-6">
                                    <button type="button" onclick="closePrescriptionModal()"
                                        class="px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        Cancel
                                    </button>
                                    <button type="submit"
                                        class="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                        Save Prescription
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Prescription Preview Modal -->
            <!-- Prescription Preview Modal -->
            <div id="prescriptionPreviewModal"
                class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
                <div class="bg-white rounded-xl shadow-2xl w-full max-w-3xl max-h-[95vh] overflow-y-auto relative p-6">
                    <!-- Modal Header -->
                    <div class="flex items-center justify-between border-b pb-4 mb-4">
                        <h2 class="text-xl font-semibold text-gray-800 flex items-center">
                            <i class="fas fa-prescription-bottle-alt mr-2 text-blue-600"></i>
                            Prescription Details
                        </h2>
                        <button type="button" aria-label="Close" class="text-gray-400 hover:text-gray-600 text-2xl"
                            onclick="closePrescriptionPreviewModal()">
                            &times;
                        </button>
                    </div>

                    <!-- Print/Download Button -->
                    <div class="flex justify-end mb-4">
                        <a id="prescriptionPdfBtn" href="#" target="_blank"
                            class="inline-flex items-center px-4 py-2 bg-green-600 text-white rounded shadow hover:bg-green-700">
                            <i class="fas fa-file-pdf mr-2"></i> Download PDF
                        </a>
                    </div>

                    <!-- Modal Body -->
                    <div id="prescriptionPreviewContent" class="bg-white p-4 rounded" style="min-width: 700px;">
                        <!-- Clinic/Doctor Info -->
                        <div class="flex flex-wrap justify-between items-center mb-4">
                            <div>
                                <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Logo"
                                    class="h-12 mb-2">
                                <div class="text-sm text-gray-700 font-semibold">{{ setting('app_name') }}</div>
                                <div class="text-xs text-gray-500">{{ setting('address') }}</div>
                                <div class="text-xs text-gray-500">Email: {{ setting('email') }} | Phone:
                                    {{ setting('phone') }}</div>
                            </div>
                            <div class="text-right">
                                <div class="text-xs text-gray-500">Created On:</div>
                                <div class="font-semibold text-gray-800" id="previewCreatedOn">--</div>
                            </div>
                        </div>
                        <hr class="my-2">

                        <!-- Patient & OPD Info -->
                        <div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
                            <div>
                                <div class="text-xs text-gray-500">OPD No:</div>
                                <div class="font-semibold text-gray-800" id="previewOpdNo">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Patient Name:</div>
                                <div class="font-semibold text-gray-800" id="previewPatientName">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Doctor:</div>
                                <div class="font-semibold text-gray-800" id="previewDoctorName">--</div>
                            </div>
                            {{-- <div>
                                <div class="text-xs text-gray-500">Case ID:</div>
                                <div class="font-semibold text-gray-800" id="previewCaseId">--</div>
                            </div> --}}
                            <div>
                                <div class="text-xs text-gray-500">Height:</div>
                                <div class="font-semibold text-gray-800" id="previewHeight">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Weight:</div>
                                <div class="font-semibold text-gray-800" id="previewWeight">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Symptoms:</div>
                                <div class="font-semibold text-gray-800" id="previewSymptoms">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Blood Pressure:</div>
                                <div class="font-semibold text-gray-800" id="previewBloodPressure">--</div>
                            </div>
                            <div>
                                <div class="text-xs text-gray-500">Gender:</div>
                                <div class="font-semibold text-gray-800" id="previewGender">--</div>
                            </div>
                            {{-- <div>
                                <div class="text-xs text-gray-500">Age:</div>
                                <div class="font-semibold text-gray-800" id="previewAge">--</div>
                            </div> --}}
                            <div>
                                <div class="text-xs text-gray-500">Appointment Date:</div>
                                <div class="font-semibold text-gray-800" id="previewAppointmentDate">--</div>
                            </div>
                        </div>
                        <hr class="my-2">

                        <!-- Header Note -->
                        <div class="mb-2">
                            <div class="text-xs text-gray-500">Header Note:</div>
                            <div class="font-medium text-gray-700" id="previewHeaderNote">--</div>
                        </div>
                        <hr class="my-2">

                        <!-- Medicines Table -->
                        <div class="overflow-x-auto">
                            <table class="min-w-full text-sm border">
                                <thead>
                                    <tr class="bg-gray-50">
                                        <th class="px-3 py-2 border">Category</th>
                                        <th class="px-3 py-2 border">Medicine</th>
                                        <th class="px-3 py-2 border">Dosage</th>
                                        {{-- <th class="px-3 py-2 border">Interval</th>
                                        <th class="px-3 py-2 border">Duration</th> --}}
                                        {{-- <th class="px-3 py-2 border">Time</th> --}}
                                        <th class="px-3 py-2 border">Instructions</th>
                                    </tr>
                                </thead>
                                <tbody id="previewMedicinesTable">
                                    <!-- JS will fill rows here -->
                                </tbody>
                            </table>
                        </div>
                        <hr class="my-2">

                        <!-- Footer Note -->
                        <div class="mt-2">
                            <div class="text-xs text-gray-500">Additional Prescription:</div>
                            <div class="font-medium text-gray-700" id="previewFooterNote">--</div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                function previewPrescription(id) {
                    fetch("{{ url('admin/opd/prescriptions') }}/" + id)
                        .then(res => res.json())
                        .then(data => {
                            document.getElementById('previewCreatedOn').innerText = data.created_at ?
                                new Date(data.created_at).toLocaleString('en-GB', {
                                    day: 'numeric',
                                    month: 'short',
                                    year: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                }) : '--';
                            document.getElementById('previewOpdNo').innerText = "{{ $opd_patient->opd_no }}";
                            document.getElementById('previewPatientName').innerText = "{{ $opd_patient->patient->name }}";
                            document.getElementById('previewDoctorName').innerText = "{{ $opd_patient->doctor->name }}";
                            // document.getElementById('previewCaseId').innerText = "{{ $opd_patient->case ?? 'N/A' }}";
                            document.getElementById('previewHeight').innerText = "{{ $opd_patient->height ?? 'N/A' }}";
                            document.getElementById('previewWeight').innerText = "{{ $opd_patient->weight ?? 'N/A' }}";
                            document.getElementById('previewSymptoms').innerText = "{{ $opd_patient->symptoms ?? 'N/A' }}";
                            document.getElementById('previewBloodPressure').innerText =
                                "{{ $opd_patient->blood_pressure ?? 'N/A' }}";
                            document.getElementById('previewGender').innerText = "{{ $opd_patient->patient->gender ?? '' }}";
                            // document.getElementById('previewAge').innerText = "{{ $opd_patient->patient->age ?? '' }}";
                            document.getElementById('previewAppointmentDate').innerText =
                                "{{ \Carbon\Carbon::parse($opd_patient->appointment_date)->format('jS M, Y h:i A') }}";
                            document.getElementById('previewHeaderNote').innerText = data.headernotes || '--';
                            document.getElementById('previewFooterNote').innerText = data.footernotes || '--';
                            document.getElementById('prescriptionPdfBtn').href = "{{ url('admin/opd/prescriptions') }}/" +
                                id +
                                "/pdf";

                            // Fill medicines table (same as before)
                            let tbody = document.getElementById('previewMedicinesTable');
                            tbody.innerHTML = '';
                            if (data.medicines && data.medicines.length) {
                                data.medicines.forEach(function(med) {
                                    let tr = document.createElement('tr');
                                    tr.innerHTML = `
                        <td class="px-3 py-2 border">${getCategoryName(med.category_id)}</td>
                        <td class="px-3 py-2 border">${getMedicineName(med.medicine_id)}</td>
                        <td class="px-3 py-2 border">${med.dosage || ''}</td>
                   
                        <td class="px-3 py-2 border">${getTimeText(med.time)}</td>
                    
                    `;
                                    tbody.appendChild(tr);
                                });
                            } else {
                                let tr = document.createElement('tr');
                                tr.innerHTML =
                                    `<td colspan="7" class="text-center text-gray-400 py-4">No medicines found.</td>`;
                                tbody.appendChild(tr);
                            }

                            document.getElementById('prescriptionPreviewModal').classList.remove('hidden');
                        });

                    // Helper functions for display text
                    function getCategoryName(id) {
                        @php
                            $catArr = [];
                            foreach ($medicine_categories as $cat) {
                                $catArr[$cat->id] = $cat->medicine_category;
                            }
                        @endphp
                        const cats = @json($catArr);
                        return cats[id] || '';
                    }

                    function getMedicineName(id) {
                        @php
                            $medArr = [];
                            foreach (\App\Models\Medicine::all() as $med) {
                                $medArr[$med->id] = $med->medicine;
                            }
                        @endphp
                        const meds = @json($medArr);
                        return meds[id] || '';
                    }

                    function getDoseIntervalText(val) {
                        switch (val) {
                            case "1":
                                return "Morning";
                            case "2":
                                return "Morning & Evening";
                            case "3":
                                return "Morning, Noon, Evening";
                            case "4":
                                return "4 times a day";
                            default:
                                return "";
                        }
                    }

                    function getDurationText(val) {
                        switch (val) {
                            case "1":
                                return "1 day";
                            case "3":
                                return "3 days";
                            case "7":
                                return "1 week";
                            case "14":
                                return "2 weeks";
                            case "30":
                                return "1 month";
                            default:
                                return "";
                        }
                    }

                    function getTimeText(val) {
                        switch (val) {
                            case "0":
                                return "After Meal";
                            case "1":
                                return "Before Meal";
                            case "2":
                                return "Bed Time";
                            default:
                                return "";
                        }
                    }


                }

                function closePrescriptionPreviewModal() {
                    document.getElementById('prescriptionPreviewModal').classList.add('hidden');
                }
            </script>


            <script>
                // Tab switching functionality
                document.querySelectorAll('.tab-button').forEach(button => {
                    button.addEventListener('click', function() {
                        // Update tab buttons
                        document.querySelectorAll('.tab-button').forEach(btn => {
                            btn.classList.remove('active', 'border-pink-500', 'text-pink-600');
                            btn.classList.add('border-transparent', 'text-gray-500');
                        });
                        this.classList.add('active', 'border-pink-500', 'text-pink-600');
                        this.classList.remove('border-transparent', 'text-gray-500');

                        // Update tab contents
                        document.querySelectorAll('.tab-content').forEach(content => {
                            content.classList.add('hidden');
                        });
                        document.getElementById(this.dataset.tab).classList.remove('hidden');
                    });
                });
            </script>
            <script>
                // Edit Diagnosis Modal Fill
                function editDiagnosis(id, reportType, reportDate, description, documentUrl = null) {
                    document.getElementById('diagnosisModalTitle').innerText = 'Edit Diagnosis';
                    document.getElementById('diagnosis_id').value = id;
                    document.getElementById('report_type').value = reportType;
                    document.getElementById('report_date').value = reportDate;
                    document.getElementById('description').value = description;
                    document.getElementById('diagnosisForm').action = "{{ url('admin/diagnosis') }}/" + id;
                    document.getElementById('diagnosis_method').value = "PUT";
                    // Show current document if exists
                    if (documentUrl) {
                        document.getElementById('diagnosis-document-link').href = documentUrl;
                        document.getElementById('diagnosis-document-preview').style.display = '';
                    } else {
                        document.getElementById('diagnosis-document-preview').style.display = 'none';
                    }
                    document.getElementById('diagnosisModal').classList.remove('hidden');
                }
                // Reset modal on open for add
                document.querySelectorAll('[onclick*="diagnosisModal"]').forEach(btn => {
                    btn.addEventListener('click', function() {
                        document.getElementById('diagnosisModalTitle').innerText = 'Add Diagnosis';
                        document.getElementById('diagnosisForm').reset();
                        document.getElementById('diagnosis_id').value = '';
                        document.getElementById('diagnosisForm').action = "{{ route('admin.diagnosis.store') }}";
                        document.getElementById('diagnosis_method').value = "POST";
                        document.getElementById('diagnosis-document-preview').style.display = 'none';
                    });
                });
                // Cancel button for diagnosis modal
                document.querySelectorAll('.diagnosis-cancel-btn').forEach(btn => {
                    btn.addEventListener('click', function() {
                        document.getElementById('diagnosisModal').classList.add('hidden');
                    });
                });
            </script>

            <script>
                // Open/Close Modal
                function openDiagnosisTestModal() {
                    document.getElementById('diagnosisTestForm').reset();
                    document.getElementById('diagnosisTestRowsBody').innerHTML = document.getElementById('diagnosisTestRowsBody')
                        .children[0].outerHTML;
                    document.getElementById('diagnosisTestModal').classList.remove('hidden');
                }

                function closeDiagnosisTestModal() {
                    document.getElementById('diagnosisTestModal').classList.add('hidden');
                }

                // Add new row
                document.getElementById('addDiagnosisTestRow').onclick = function() {
                    let tbody = document.getElementById('diagnosisTestRowsBody');
                    let newRow = tbody.children[0].cloneNode(true);
                    newRow.querySelectorAll('input, select').forEach(el => el.value = '');
                    tbody.appendChild(newRow);
                };
                // Delete row
                document.addEventListener('click', function(e) {
                    if (e.target.classList.contains('deleteDiagnosisTestRow')) {
                        let tbody = document.getElementById('diagnosisTestRowsBody');
                        if (tbody.children.length > 1) e.target.closest('tr').remove();
                    }
                });

                // AJAX submit for multiple tests
                document.getElementById('diagnosisTestForm').addEventListener('submit', function(e) {
                    e.preventDefault();
                    let form = this;
                    let formData = new FormData(form);
                    fetch("{{ route('admin.diagnosis-tests.store') }}", {
                            method: 'POST',
                            headers: {
                                'X-CSRF-TOKEN': '{{ csrf_token() }}'
                            },
                            body: formData
                        })
                        .then(res => res.json())
                        .then(data => {
                            if (data.success) {
                                // Show success message
                                showDiagnosisSuccess('Diagnosis tests saved successfully!');
                                setTimeout(() => location.reload(), 1200); // 1.2 sec baad reload
                            } else if (data.errors) alert(Object.values(data.errors).join('\n'));
                            else alert('Something went wrong!');
                        })
                        .catch(() => alert('Server error!'));
                });


                document.addEventListener('click', function(e) {
                    if (e.target.closest('.deleteDiagnosisTestRow')) {
                        const row = e.target.closest('tr');
                        // Prevent deleting the last row
                        const tbody = document.getElementById('diagnosisTestRowsBody');
                        if (tbody.rows.length > 1) {
                            row.remove();
                        } else {
                            // Optionally clear the row instead of removing
                            row.querySelectorAll('input, select').forEach(el => el.value = '');
                        }
                        // Optionally update row numbers here if you show them
                    }
                });

                function showDiagnosisSuccess(msg) {
                    let el = document.createElement('div');
                    el.className =
                        "fixed top-6 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded shadow-lg z-50 text-base font-semibold";
                    el.innerText = msg;
                    document.body.appendChild(el);
                    setTimeout(() => el.remove(), 1000);
                }
            </script>

            {{-- <script>
                // Load charge types based on selected category
                function loadChargeTypes(selectElement) {
                    const chargeCategoryId = selectElement.value;
                    const chargeTypeSelect = selectElement.closest('tr').querySelector('.charge-type');
                    const standardChargeInput = selectElement.closest('tr').querySelector('.standard-charge');

                    // Reset dependent fields
                    chargeTypeSelect.innerHTML = '<option value="">Select Type</option>';
                    standardChargeInput.value = '';

                    if (!chargeCategoryId) return;

                    fetch(`/admin/get-charge-types?charge_category_id=${chargeCategoryId}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(chargeType => {
                                const option = document.createElement('option');
                                option.value = chargeType.id;
                                option.textContent = chargeType.name;
                                chargeTypeSelect.appendChild(option);
                            });
                        });
                }

                // Load standard charge based on selected charge type
                function loadStandardCharge(selectElement) {
                    const chargeCategoryId = selectElement.closest('tr').querySelector('.charge-category').value;
                    const chargeTypeId = selectElement.value;
                    const standardChargeInput = selectElement.closest('tr').querySelector('.standard-charge');

                    if (!chargeCategoryId || !chargeTypeId) {
                        standardChargeInput.value = '';
                        return;
                    }

                    fetch(`/admin/get-standard-charge?charge_category_id=${chargeCategoryId}&charge_type_id=${chargeTypeId}`)
                        .then(response => response.json())
                        .then(data => {
                            standardChargeInput.value = data.standard_charge || '';
                        });
                }

                // Update the add row function to clone with proper event handlers
                document.getElementById('addDiagnosisTestRow').onclick = function() {
                    let tbody = document.getElementById('diagnosisTestRowsBody');
                    let newRow = tbody.children[0].cloneNode(true);

                    // Clear all values in the new row
                    newRow.querySelectorAll('select').forEach(el => {
                        el.selectedIndex = 0;
                        // Reattach event handlers
                        if (el.classList.contains('charge-category')) {
                            el.onchange = function() {
                                loadChargeTypes(this);
                            };
                        } else if (el.classList.contains('charge-type')) {
                            el.onchange = function() {
                                loadStandardCharge(this);
                            };
                        }
                    });
                    newRow.querySelectorAll('input').forEach(el => el.value = '');

                    tbody.appendChild(newRow);
                }; --}}



            {{-- </script> --}}

            <script>
                // Load charge categories based on selected test type
                function loadChargeCategories(selectElement) {
                    const chargeTypeId = selectElement.value;
                    const chargeCategorySelect = selectElement.closest('tr').querySelector('.charge-category');
                    const standardChargeInput = selectElement.closest('tr').querySelector('.standard-charge');

                    // Reset dependent fields
                    chargeCategorySelect.innerHTML = '<option value="">Select Category</option>';
                    standardChargeInput.value = '';

                    if (!chargeTypeId) return;

                    fetch(`/admin/get-charge-categories?charge_type_id=${chargeTypeId}`)
                        .then(response => response.json())
                        .then(data => {
                            data.forEach(category => {
                                const option = document.createElement('option');
                                option.value = category.id;
                                option.textContent = category.charge_category;
                                chargeCategorySelect.appendChild(option);
                            });
                        });
                }

                // Load standard charge based on selected charge category
                function loadStandardCharge(selectElement) {
                    const chargeCategoryId = selectElement.value;
                    const chargeTypeSelect = selectElement.closest('tr').querySelector('.charge-type');
                    const chargeTypeId = chargeTypeSelect.value;
                    const standardChargeInput = selectElement.closest('tr').querySelector('.standard-charge');

                    if (!chargeCategoryId || !chargeTypeId) {
                        standardChargeInput.value = '';
                        return;
                    }

                    fetch(`/admin/get-standard-charge?charge_category_id=${chargeCategoryId}&charge_type_id=${chargeTypeId}`)
                        .then(response => response.json())
                        .then(data => {
                            standardChargeInput.value = data.standard_charge || '';
                        });
                }

                // Add new row with proper event handlers
                document.getElementById('addDiagnosisTestRow').onclick = function() {
                    let tbody = document.getElementById('diagnosisTestRowsBody');
                    let newRow = tbody.children[0].cloneNode(true);

                    // Clear all values in the new row
                    newRow.querySelectorAll('select').forEach(el => {
                        el.selectedIndex = 0;
                        // Reattach event handlers
                        if (el.classList.contains('charge-type')) {
                            el.onchange = function() {
                                loadChargeCategories(this);
                            };
                        } else if (el.classList.contains('charge-category')) {
                            el.onchange = function() {
                                loadStandardCharge(this);
                            };
                        }
                    });
                    newRow.querySelectorAll('input').forEach(el => el.value = '');

                    // Update row number
                    newRow.querySelector('td:first-child').textContent = tbody.children.length + 1;

                    tbody.appendChild(newRow);
                };

                // Delete row handler
                document.addEventListener('click', function(e) {
                    if (e.target.classList.contains('deleteDiagnosisTestRow')) {
                        const tbody = document.getElementById('diagnosisTestRowsBody');
                        if (tbody.children.length > 1) {
                            e.target.closest('tr').remove();
                            // Update row numbers after deletion
                            Array.from(tbody.children).forEach((row, index) => {
                                row.querySelector('td:first-child').textContent = index + 1;
                            });
                        }
                    }
                });

                // Form submission
                // document.getElementById('diagnosisTestForm').addEventListener('submit', function(e) {
                //     e.preventDefault();
                //     let form = this;
                //     let formData = new FormData(form);

                //     fetch("{{ route('admin.diagnosis-tests.store') }}", {
                //             method: 'POST',
                //             headers: {
                //                 'X-CSRF-TOKEN': '{{ csrf_token() }}',
                //                 'Accept': 'application/json'
                //             },
                //             body: formData
                //         })
                //         .then(response => response.json())
                //         .then(data => {
                //             if (data.success) {
                //                 showDiagnosisSuccess('Diagnosis tests saved successfully!');
                //                 setTimeout(() => location.reload(), 1200);
                //             } else if (data.errors) {
                //                 alert(Object.values(data.errors).join('\n'));
                //             } else {
                //                 alert('Something went wrong!');
                //             }
                //         })
                //         .catch(error => {
                //             console.error('Error:', error);
                //             alert('Server error occurred!');
                //         });
                // });

                function showDiagnosisSuccess(msg) {
                    let el = document.createElement('div');
                    el.className =
                        "fixed top-6 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-6 py-3 rounded shadow-lg z-50 text-base font-semibold";
                    el.innerText = msg;
                    document.body.appendChild(el);
                    setTimeout(() => el.remove(), 1000);
                }

                // Modal open/close functions
                function openDiagnosisTestModal() {
                    document.getElementById('diagnosisTestForm').reset();
                    document.getElementById('diagnosisTestRowsBody').innerHTML = document.getElementById('diagnosisTestRowsBody')
                        .children[0].outerHTML;
                    document.getElementById('diagnosisTestModal').classList.remove('hidden');
                }

                function closeDiagnosisTestModal() {
                    document.getElementById('diagnosisTestModal').classList.add('hidden');
                }
            </script>

            <style>
                .tab-button {
                    transition: all 0.2s ease;
                    position: relative;
                }

                .tab-button.active {
                    color: #ec4899;
                    /* pink-500 */
                    border-color: #ec4899;
                    /* pink-500 */
                }

                .tab-button:hover:not(.active) {
                    color: #be185d;
                    /* pink-700 */
                    border-color: #f9a8d4;
                    /* pink-300 */
                }
            </style>
            <script>
                function openPrescriptionModal() {
                    document.getElementById('prescriptionModalTitle').innerText = 'Add Prescription';
                    document.getElementById('prescriptionForm').reset();
                    document.getElementById('prescriptionForm').action = "{{ route('opd.prescriptions.store') }}";
                    document.getElementById('prescription_method').value = "POST";
                    document.getElementById('prescriptionModal').classList.remove('hidden');
                }

                function closePrescriptionModal() {
                    document.getElementById('prescriptionModal').classList.add('hidden');
                }

                // Add new prescription row
                document.getElementById('addOpdPrescriptionItem').onclick = function() {
                    let tbody = document.querySelector('.opd-prescription-item-container');
                    let rowCount = tbody.children.length + 1;
                    let newRow = tbody.children[0].cloneNode(true);
                    newRow.querySelectorAll('input, select, textarea').forEach(el => el.value = '');
                    newRow.querySelector('.opd-prescription-item-number').textContent = rowCount;
                    tbody.appendChild(newRow);
                };

                // Delete prescription row
                document.addEventListener('click', function(e) {
                    if (e.target.closest('.deleteopdPrescription')) {
                        let tbody = document.querySelector('.opd-prescription-item-container');
                        if (tbody.children.length > 0) {
                            e.target.closest('tr').remove();
                        }
                    }
                });

                // Dynamic medicine dropdown
                document.addEventListener('change', function(e) {
                    if (e.target.classList.contains('opdCategoryId')) {
                        let categoryId = e.target.value;
                        let medicineSelect = e.target.closest('tr').querySelector('.medicineId');
                        medicineSelect.innerHTML = '<option value="">Loading...</option>';
                        fetch("{{ url('admin/medicines/by-category') }}/" + categoryId)
                            .then(res => res.json())
                            .then(data => {
                                let options = '<option value="">Select Medicine</option>';
                                data.forEach(function(med) {
                                    options += `<option value="${med.id}">${med.medicine}</option>`;
                                });
                                medicineSelect.innerHTML = options;
                            });
                    }
                });

                function editPrescription(id) {
                    fetch("{{ url('admin/opd/prescriptions') }}/" + id)
                        .then(res => res.json())
                        .then(data => {
                            document.getElementById('prescriptionModalTitle').innerText = 'Edit Prescription';
                            document.getElementById('prescriptionForm').action = "{{ url('admin/opd/prescriptions') }}/" + id;
                            document.getElementById('prescription_method').value = "PUT";
                            document.getElementById('prescription_id').value = id;
                            document.getElementById('prescription_date').value = data.prescription_date;
                            document.getElementById('headernotes').value = data.headernotes;
                            document.getElementById('footernotes').value = data.footernotes;
                            document.getElementById('status').value = data.status;

                            // Fill medicines
                            let tbody = document.querySelector('.opd-prescription-item-container');
                            tbody.innerHTML = '';
                            data.medicines.forEach(function(med, idx) {
                                let row = document.createElement('tr');
                                row.innerHTML = `
                    <td class="px-3 py-2 text-center opd-prescription-item-number">${idx+1}</td>
                    <td>
                        <select class="opdCategoryId" required name="category_id[]">
                            @foreach ($medicine_categories as $cat)
                                <option value="{{ $cat->id }}">${'{{ $cat->medicine_category }}'}</option>
                            @endforeach
                        </select>
                    </td>
                    <td>
                        <select class="medicineId" required name="medicine_id[]">
                            <option value="">Select Medicine</option>
                        </select>
                    </td>
                    <td>
                        <select class="dosage" name="dosage[]" required>
                            
                                        <option value="${med.dosage }">${med.dosage }</option>
                                        <option value="OD">OD</option>
                                        <option value="BD">BD</option>
                                        <option value="TDS">TDS</option>
                                        <option value="Q1D">Q1D</option>
                    
                        </select>
                    </td>
                  
              
                    <td>
                        <select class="opdPrescriptionMedicineMealId" name="time[]" required>
                            <option value="">Select</option>
                            <option value="0">After Meal</option>
                            <option value="1">Before Meal</option>
                            <option value="2">At Bed Time</option>
                        </select>
                    </td>
               
                    <td class="text-center">
                        <button type="button" class="text-red-500 deleteopdPrescription" title="Delete">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </td>
                `;
                                tbody.appendChild(row);

                                // Set selected values
                                row.querySelector('.opdCategoryId').value = med.category_id;
                                // row.querySelector('.opdDuration').value = med.duration;
                                // row.querySelector('.opdDoseInterval').value = med.doseInterval;
                                row.querySelector('.opdPrescriptionMedicineMealId').value = med.time;

                                // Fetch medicines for category and set selected
                                fetch("{{ url('/admin/medicines/by-category') }}/" + med.category_id)
                                    .then(res => res.json())
                                    .then(meds => {
                                        let medSelect = row.querySelector('.medicineId');
                                        medSelect.innerHTML = '<option value="">Select Medicine</option>';
                                        meds.forEach(function(m) {
                                            medSelect.innerHTML +=
                                                `<option value="${m.id}">${m.medicine}</option>`;
                                        });
                                        medSelect.value = med.medicine_id;
                                    });
                            });

                            document.getElementById('prescriptionModal').classList.remove('hidden');
                        });
                }
            </script>

        </div>
    </body>
@endsection
