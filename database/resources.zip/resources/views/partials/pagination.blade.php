@if($users->isNotEmpty())
<div class="flex justify-between items-center mt-4">
    <!-- Custom Pagination -->
    <div class="flex space-x-2 items-center">
        {{-- Previous Page --}}
        @if ($users->onFirstPage())
        <span class="px-4 py-2 text-gray-400 border customborder border-main-color rounded-lg">
            &larr;
        </span>
        @else
        <a href="{{ $users->previousPageUrl() }}{{ request()->has('perPage') ? '&perPage=' . request('perPage') : '' }}"
            class="px-4 py-2 customborder border-main-color rounded-lg hover-main-color">
            &larr;
        </a>
        @endif

        {{-- Page Numbers --}}
        @for ($i = 1; $i <= $users->lastPage(); $i++)
            @if ($i == $users->currentPage())
            <span class="px-4 py-2 text-white bg-[var(--main-color)] border-main-color border rounded-lg">
                {{ $i }}
            </span>
            @else
            <a href="{{ $users->url($i) }}{{ request()->has('perPage') ? '&perPage=' . request('perPage') : '' }}"
                class="px-4 py-2 customborder border-main-color rounded-lg hover-purple-color">
                {{ $i }}
            </a>
            @endif
            @endfor

            {{-- Next Page --}}
            @if ($users->hasMorePages())
            <a href="{{ $users->nextPageUrl() }}{{ request()->has('perPage') ? '&perPage=' . request('perPage') : '' }}"
                class="px-4 py-2 customborder border-main-color rounded-lg hover-main-color">
                &rarr;
            </a>
            @else
            <span class="px-4 py-2 text-gray-400 border customborder border-main-color rounded-lg">
                &rarr;
            </span>
            @endif
    </div>

    <!-- Page Size Dropdown -->
    <form method="GET">
        <select name="perPage" onchange="this.form.submit()"
            class="customborder border-main-color p-2 rounded-lg hover-main-color">
            @foreach([10, 20, 50, 100] as $size)
            <option value="{{ $size }}" {{ request('perPage') == $size ? 'selected' : '' }}>
                {{ $size }} / Page
            </option>
            @endforeach
        </select>
        <!-- <input type="hidden" name="search" value="{{ request('search') }}"> -->
    </form>
</div>
@endif