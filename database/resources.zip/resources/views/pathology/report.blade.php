<!DOCTYPE html>
<html>

<head>
    <title>Pathology Billing Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #fff;
            color: #222;
            line-height: 1.3;
            margin: 0;
            padding: 0;
        }

        /* Section Titles */
        .section-title {
            font-size: 1rem;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
            color: #333;
        }

        /* Patient Information Table */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
            table-layout: fixed;
        }

        .info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border-bottom: 1px solid #333;
            word-wrap: break-word;
        }

        .right {
            border-right: 1px solid #333;
        }

        .info-table td {
            width: 25%;
        }

        .info-table td:first-child {
            background-color: #f9f9f9;
        }

        /* Category Section */
        .category-section {
            text-align: center;
            margin: 10px 0;
            padding: 7.5px;
        }

        .category-title {
            font-size: 1.3rem;
            font-weight: bold;
            margin-bottom: 5px;
        }

        .test-name {
            font-size: 1.1rem;
            font-weight: bold;
        }

        /* Test Parameters Table */
        .test-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        .test-table th,
        .test-table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: left;
        }

        .test-table th {
            background: #f8f8f8;
        }

        /* --- HIGHLIGHT LOGIC CSS --- */
        /* Bold text and maybe red color if you want */
        .reference-outside-row {
            font-weight: bold !important;
            color: #000 !important;
            /* Printing me Black hi safe rehta hai, screen ke liye Red kar sakte ho */
        }

        /* --------------------------- */

        /* Test Result Box */
        .test-result {
            margin-top: 15px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #e5e7eb;
        }

        /* Note Section */
        .note-section {
            margin-top: 20px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 4px;
            border: 1px solid #e5e7eb;
        }

        /* Footer Container */
        .footer-container {
            position: absolute;
            bottom: 55px;
            left: 0;
            right: 0;
            padding: 10px;
            margin-top: 20px;
        }

        .hospital-footer {
            text-align: center;
            border-top: 1px solid #e91e63;
            margin-top: 10px;
            padding-top: 5px;
            font-size: 11px;
        }

        .emergency-contact {
            font-weight: bold;
            color: #e91e63;
            margin-bottom: 5px;
        }

        @media print {
            .print-btn {
                display: none;
            }

            .bill-container {
                border: none;
                padding: 10px;
            }

            .footer-container {
                position: fixed;
                bottom: 0;
            }
        }
    </style>
</head>

<body>
    <div class="bill-container">
        @if(setting('show_header_pathology_report', 'yes') == 'yes')
        <table width="100%"
            style=" border-bottom:2px solid {!! setting('theme_color', '#e91e63') !!}; margin-bottom:20px; padding-bottom:15px;">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ public_path('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Hospital Logo"
                        style="height:70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63 ') !!}; margin-bottom:5px;">
                        {{ setting('hospital_name', 'Hospital') }}
                    </div>
                    <div style="font-size:12px; color:#555;">
                        {{ setting('address', 'Address') }}<br>
                        Phone: +91 {{ setting('phone', '0000000000') }}, {{ setting('mobile', '0000000000') }}<br>
                        Website: <a href="{{ setting('website', 'https://www.patliputranetralaya.in/') }}"
                            style="color:{!! setting('theme_color', '#e91e63') !!}; text-decoration:none;">
                            {{ setting('website', 'www.patliputranetralaya.in') }}
                        </a>
                    </div>
                </td>
            </tr>
        </table>
        @else
        <div style="height: {{ setting('spacer_pathology_report', '180') }}px;"></div>
        @endif

        <div style="text-align:center; font-weight:bold; font-size:16px; text-decoration: underline; margin-top:5px; margin-bottom:15px; color: #333;">
            DEPARTMENT OF PATHOLOGY
        </div>

        <div class="section-title">Patient Information</div>
        <table class="info-table">
            <tr>
                <td><strong>Report No:</strong></td>
                <td class="right">{{ $invoice }}</td>
                <td><strong>Date:</strong></td>
                <td>{{ now()->format('d-m-Y h:i A') }}</td>
            </tr>
            <tr>
                <td><strong>Patient Name:</strong></td>
                <td class="right">{{ $bill->patient->name ?? 'N/A' }}</td>
                <td><strong>Patient ID:</strong></td>
                <td>{{ App\Models\Patient::where('user_id', $bill->patient->id)->first()->patient_unique_id ?? 'N/A' }}
                </td>
            </tr>
            <tr>
                <td><strong>Age/Gender:</strong></td>
                <td class="right">
                    {{ $bill->patient->age ?? '0' }} Y 
                    @if($bill->patient->age_month)
                        {{ $bill->patient->age_month }} M
                    @endif
                    / {{ $bill->patient->gender ?? 'N/A' }}
                </td>
                <td><strong>Contact No:</strong></td>
                <td>{{ $bill->patient->phone ?? 'N/A' }}</td>
            </tr>
            <tr>
                <td><strong>Referring Doctor:</strong></td>
                <td class="right">{{ $bill->doctor->name ?? 'N/A' }}</td>
                <td><strong>Report Delivery:</strong></td>
                <td>{{ $report_delivery_time }}</td>
            </tr>
        </table>

        <div class="category-section">
            <div class="category-title">{{ $category->name ?? 'N/A' }}</div>
            <div class="test-name">{{ $tests->test_name ?? 'N/A' }}</div>
        </div>

        <table class="test-table">
            <thead>
                <tr>
                    <th width="40%">Test Parameter Name</th>
                    <th width="30%">Reference Range</th>
                    <th width="30%">Report Value</th>
                </tr>
            </thead>
            <tbody>
                @php
                    function isOutOfRange($value, $reference_range)
                    {
                        // 0. Safety Checks
                        if (
                            empty($value) ||
                            empty($reference_range) ||
                            $value === 'N/A' ||
                            $reference_range === 'N/A'
                        ) {
                            return false;
                        }

                        // ============================================================
                        // STEP 1: NORMALIZE DASHES (Fix for Hemoglobin Issue)
                        // Reference range mein jo lamba dash (–) hai usko standard (-) banayenge
                        // ============================================================
                        $ref_clean_dash = str_replace(['–', '—'], '-', $reference_range);

                        // Standard cleaning
                        $clean_val = trim($value);
                        $clean_ref = trim($ref_clean_dash);

                        $val_lower = strtolower($clean_val);
                        $ref_lower = strtolower($clean_ref);

                        // ============================================================
                        // LOGIC A: COMMA SEPARATED LIST (Fix for Rh Factor)
                        // Cases: "+, -" OR "Negative, Trace"
                        // Agar comma hai, aur ye Numeric Range nahi hai (jaise 4,000 - 5,000)
                        // ============================================================
                        if (strpos($clean_ref, ',') !== false) {
                            // Check: Kya ye numeric range hai with comma? (e.g. 4,000 - 11,000)
                            $has_dash = strpos($clean_ref, '-') !== false;
                            // Agar Letters ya '+' symbol hai, toh Dash hone ke bawajood ye LIST hi hai (e.g. "+, -")
                            $has_text_or_symbol =
                                preg_match('/[a-zA-Z]/', $clean_ref) || strpos($clean_ref, '+') !== false;

                            // Agar Dash nahi hai, YA Dash hai par saath me Text/Symbol bhi hai -> Toh ye List hai
                            if (!$has_dash || $has_text_or_symbol) {
                                // Comma se tod kar list banao: ['+', '-']
                                $allowed_list = array_map('trim', explode(',', $ref_lower));

                                // Agar current value is list me nahi hai -> HIGHLIGHT
                                // Example: Value '*' list ['+', '-'] me nahi hai -> True
                                return !in_array($val_lower, $allowed_list);
                            }
                        }

                        // ============================================================
                        // LOGIC B: NUMERIC CHECKS (Ranges & Inequalities)
                        // Cases: "13.0 - 17.0" (Hemoglobin) | "< 20"
                        // ============================================================

                        // Value se units (g/dL) aur commas hata kar number nikalo
                        // "11 g/dL" -> "11"
                        $val_num_str = preg_replace('/[^\d.-]/', '', str_replace(',', '', $clean_val));

                        // Agar value number nahi hai (e.g. "Present"), toh Numeric logic skip karo
                        if ($val_num_str === '' || !is_numeric($val_num_str)) {
                            // Fallback: Direct Text Match (e.g. Ref="Nil", Val="++")
                            if (!preg_match('/[<>-]/', $clean_ref)) {
                                return $val_lower !== $ref_lower;
                            }
                            return false;
                        }

                        $val_float = floatval($val_num_str);
                        // Ref se comma hatao calculation ke liye
                        $ref_num_clean = str_replace(',', '', $clean_ref);

                        // 1. Range Check (Min - Max)
                        if (strpos($clean_ref, '-') !== false) {
                            $parts = explode('-', $ref_num_clean);
                            if (count($parts) >= 2) {
                                $min = floatval(trim($parts[0]));
                                $max = floatval(trim($parts[1]));

                                // Highlight if Less than Min OR Greater than Max
                                // Example: 11 < 13.0 -> Returns True (Highlight)
                                return $val_float < $min || $val_float > $max;
                            }
                        }

                        // 2. Inequality Check (<, >, <=, >=)
                        if (preg_match('/[<>]=?/', $clean_ref)) {
                            $threshold = floatval(preg_replace('/[^\d.-]/', '', $ref_num_clean));

                            if (strpos($clean_ref, '<=') !== false) {
                                return $val_float > $threshold;
                            }
                            if (strpos($clean_ref, '>=') !== false) {
                                return $val_float < $threshold;
                            }
                            if (strpos($clean_ref, '<') !== false) {
                                return $val_float >= $threshold;
                            }
                            if (strpos($clean_ref, '>') !== false) {
                                return $val_float <= $threshold;
                            }
                        }

                        return false;
                    }
                @endphp

                @foreach ($parameters as $parameter)
                    @php
                        $is_out_of_range = isOutOfRange($parameter['value'] ?? '', $parameter['reference_range'] ?? '');
                    @endphp
                    <tr>
                        <td>{{ $parameter['name'] ?? 'N/A' }}</td>
                        <td>{{ $parameter['reference_range'] ?? 'N/A' }}</td>
                        <td class="{{ $is_out_of_range ? 'reference-outside-row' : '' }}">
                            {{ $parameter['value'] ?? 'N/A' }}
                            {{ isset($parameter['unit']) && $parameter['unit'] !== '-' ? ' ' . $parameter['unit'] : '' }}
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        @if ($report->result)
            <div class="test-result">
                <strong>Result:</strong> {{ $report->result ?? 'N/A' }}
            </div>
        @endif

        @if ($bill->Note)
            <div class="note-section">
                <strong>Note:</strong> {{ $bill->Note }}
            </div>
        @endif

        <div style="text-align: center; margin-top: 25px; margin-bottom: 15px; font-size: 11px; font-weight: bold; color: #555; letter-spacing: 1px;">
            *** END OF REPORT ***
        </div>

        <div class="footer-container">
            
            <!-- Optional Hospital Info -->
            @if(setting('show_footer_pathology_report', 'yes') == 'yes')
            <!-- Signature Section -->
            <table style="width: 100%; border-collapse: collapse; border: none; margin-bottom: 10px;">
                <tr>
                    <td style="width: 50%; text-align: left; vertical-align: bottom; border: none; padding: 0;">
                        <div style="height: 35px;"></div>
                        @if(setting('pathology_left_sig_name', 'MD Sahboob Alam'))
                            <div style="font-size: 12px; font-weight: bold; color: #333; margin-bottom: 3px;">
                                {{ setting('pathology_left_sig_name', 'MD Sahboob Alam') }}
                            </div>
                        @endif
                        @if(setting('pathology_left_sig_designation', 'B.M.L.T. (Technician)'))
                            <div style="font-size: 11px; color: #555;">
                                {{ setting('pathology_left_sig_designation', 'B.M.L.T. (Technician)') }}
                            </div>
                        @endif
                    </td>
                    <td style="width: 50%; text-align: right; vertical-align: bottom; border: none; padding: 0;">
                        <div style="display: inline-block; text-align: left;">
                            <div style="height: 35px;"></div>
                            @if(setting('pathology_right_sig_name'))
                                <div style="font-size: 12px; font-weight: bold; color: #333; margin-bottom: 3px;">
                                    {{ setting('pathology_right_sig_name') }}
                                </div>
                            @endif
                            @if(setting('pathology_right_sig_designation', 'MBBS, DCP (Pathologist)'))
                                <div style="font-size: 11px; color: #555;">
                                    {{ setting('pathology_right_sig_designation', 'MBBS, DCP (Pathologist)') }}
                                </div>
                            @endif
                        </div>
                    </td>
                </tr>
            </table>

            <!-- Disclaimer Line -->
            <div style="border-top: 1px solid #d1d5db; margin-top: 15px; padding-top: 10px; text-align: center;">
                <span style="color: #2b6cb0; font-weight: bold; font-size: 11px;">
                    This report is not meant for medico legal purpose. Correlate clinically if abnormal report found.
                </span>
            </div>

            <!-- <div class="hospital-footer">
                <div class="emergency-contact">
                    For Emergency Reports: +91 {{ setting('phone', '0000000000') }}
                </div>
                <div>
                    Website: <a href="{{ setting('website', 'https://www.patliputranetralaya.in/') }}"
                        style="color:{!! setting('theme_color', '#e91e63') !!}; text-decoration:none;">{{ setting('website', 'www.patliputranetralaya.in') }}</a>
                    | Email: pathology@hospital.com
                </div>
                <div>
                    {{ setting('address', 'Patna: Opposite SBI, Bhootnath Road, Patna-800026') }}
                </div>
            </div> -->
            @endif
        </div>
    </div>
</body>

</html>
