@extends('layouts.admin')
@section('title', 'IPD Patients')
<style>
    .custom-container {
        display: flex;
        width: 100%;
        gap: 20px;
        /* Optional spacing between columns */
    }

    .left-section,
    .right-section {
        flex: 1;
        /* This means each takes 50% of the available width */
        padding: 10px;
        box-sizing: border-box;
        border: none;
        min-height: 200px;
        /* for demo visibility */
    }

    .billing-container {
        background-color: #f9f9f9;
        padding: 10px;
    }

    .billinput {
        padding: 8px;
        width: 100px;
        background-color: rgba(225, 218, 218, 0.88);
    }
</style>
@section('content')

    <body class="bg-gray-100 p-6">

        <div class="max-w-6xl mx-auto bg-white p-6 rounded-lg shadow-md">
            <div class="flex justify-between items-center mb-4">
                <h1 class="text-2xl font-bold text-gray-800">IPD Patients Details</h1>
            </div>

            <div class="mt-4">
                <div class="flex justify-between items-center mb-4">
                    <a href="{{ url()->previous() }}">
                        <button class="text-main-color customborder px-4 py-2 rounded-lg hover:bg-main-color">
                            &larr; Back
                        </button>
                    </a>
                    <a href="{{ route('admin.ipd.edit', $ipd_patient->id) }}">
                        <button class="text-main-color customborder px-4 py-2 rounded-lg hover:bg-main-color">
                            Edit
                        </button>
                    </a>
                </div>

                {{-- Tab Menu --}}
                <ul class="flex flex-wrap space-x-6 border-b mb-4" id="tabs">
                    @php $tabs = ['overview' => 'Overview', 'diagnosis' => 'Diagnosis Uploads',  'charges' => 'Bill Entry', 'prescriptions' => 'Prescriptions',  'payments' => 'Payments Receive', 'bills' => 'Bill Details']; @endphp
                    @foreach ($tabs as $key => $label)
                        <li class="tab-item pb-2 border-b-2 cursor-pointer hover:border-blue-500 text-gray-700"
                            data-tab="{{ $key }}" id="tab-{{ $key }}">
                            {{ $label }}
                        </li>
                    @endforeach
                </ul>

                {{-- Tab Contents --}}
                <div id="tab-contents">
                    <div id="content-overview" class="tab-content">
                        <!-- Patient Header Card -->
                        <div class="bg-gradient-to-r from-blue-500 to-blue-600 p-6 rounded-lg shadow-md mb-6 text-white">
                            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                                <div class="flex items-center space-x-4 md:col-span-2">
                                    <img src="{{ $ipd_patient->patient->image ? asset('avatar/' . $ipd_patient->patient->image) : asset('/img/default_user.png') }}"
                                        alt="Patient Image" class="w-24 h-24 rounded-full border-4 border-white">
                                    <div>
                                        <h2 class="text-2xl font-bold">{{ $ipd_patient->patient->name }}</h2>
                                        <p class="text-blue-100">UHID: {{ $patient->patient_unique_id ?? 'N/A' }}</p>
                                        <p class="text-blue-100">IPD No: {{ $ipd_patient->ipd_no ?? 'N/A' }}</p>
                                    </div>
                                </div>
                                <div>
                                    <p class="text-sm text-blue-100">Admission Date</p>
                                    <p class="text-lg font-semibold">{{ $ipd_patient->admission_date ? \Carbon\Carbon::parse($ipd_patient->admission_date)->format('d M Y') : 'N/A' }}</p>
                                </div>
                                <div>
                                    <p class="text-sm text-blue-100">Status</p>
                                    <p class="text-lg font-semibold">{{ $ipd_patient->discharge_date ? 'Discharged' : 'Admitted' }}</p>
                                    @if($ipd_patient->discharge_date)
                                        <p class="text-xs text-blue-100">{{ \Carbon\Carbon::parse($ipd_patient->discharge_date)->format('d M Y') }}</p>
                                    @endif
                                </div>
                            </div>
                        </div>

                        <!-- IPD & Medical Information -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <!-- IPD Details -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-hospital-alt mr-2 text-blue-500"></i>IPD Information
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Case Type:</span>
                                        <span class="font-semibold">{{ $ipd_patient->case ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Bed Assigned:</span>
                                        <span class="font-semibold">{{ $ipd_patient->beds ? $ipd_patient->beds->name : 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Bed Type:</span>
                                        <span class="font-semibold">{{ $ipd_patient->bed_type ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Admission Time:</span>
                                        <span class="font-semibold">{{ $ipd_patient->admission_date ? \Carbon\Carbon::parse($ipd_patient->admission_date)->format('g:i A') : 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Vital Signs -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4 ">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-heartbeat mr-2 text-green-500"></i>Vital Signs
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Height:</span>
                                        <span class="font-semibold">{{ $ipd_patient->height ? $ipd_patient->height . ' cm' : 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Blood Pressure:</span>
                                        <span class="font-semibold">{{ $ipd_patient->blood_pressure ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Primary Symptoms:</span>
                                        <span class="font-semibold text-right">{{ $ipd_patient->symptoms ? Str::limit($ipd_patient->symptoms, 30) : 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Notes:</span>
                                        <span class="font-semibold text-right text-xs">{{ $ipd_patient->notes ? Str::limit($ipd_patient->notes, 25) : 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Personal Information -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <!-- Basic Information -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4 ">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-user mr-2 text-purple-500"></i>Basic Information
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Gender:</span>
                                        <span class="font-semibold">{{ ucfirst($ipd_patient->patient->gender ?? 'N/A') }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Date of Birth:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->dob ? \Carbon\Carbon::parse($ipd_patient->patient->dob)->format('d M Y') : 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Age:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->age ?? 'N/A' }} years</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Blood Group:</span>
                                        <span class="font-semibold bg-red-100 text-red-700 px-2 py-1 rounded">{{ $ipd_patient->patient->blood_group ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Marital Status:</span>
                                        <span class="font-semibold">{{ ucfirst($ipd_patient->patient->marital_status ?? 'N/A') }}</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Aadhar No:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->adhar_number ?? 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Contact Information -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4 ">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-phone mr-2 text-orange-500"></i>Contact Information
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Phone:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->phone ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Alternate Phone:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->alternate_phone ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between border-b pb-2">
                                        <span class="text-gray-600">Email:</span>
                                        <span class="font-semibold text-xs break-all">{{ $ipd_patient->patient->email ?? 'N/A' }}</span>
                                    </div>
                                    <div class="flex justify-between">
                                        <span class="text-gray-600">Guardian Name:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->guardian_name ?? 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Address & Medical History -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                            <!-- Address -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4 ">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-map-marker-alt mr-2 text-indigo-500"></i>Address
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="border-b pb-2">
                                        <span class="text-gray-600 block mb-1">Primary Address:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->address ?? 'N/A' }}</span>
                                    </div>
                                    <div>
                                        <span class="text-gray-600 block mb-1">Alternate Address:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->alternate_address ?? 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>

                            <!-- Medical History -->
                            <div class="bg-white p-6 rounded-lg shadow-md border-l-4">
                                <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                    <i class="fas fa-stethoscope mr-2 text-red-500"></i>Medical History
                                </h3>
                                <div class="space-y-3 text-sm">
                                    <div class="border-b pb-2">
                                        <span class="text-gray-600 block mb-1">Allergies:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->allergies ?? 'None' }}</span>
                                    </div>
                                    <div>
                                        <span class="text-gray-600 block mb-1">Remarks:</span>
                                        <span class="font-semibold">{{ $ipd_patient->patient->remarks ?? 'N/A' }}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Consultant Doctor -->
                        <div class="bg-white p-6 rounded-lg shadow-md border-l-4  mb-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                                <i class="fas fa-user-md mr-2 text-teal-500"></i>Consultant Doctor
                            </h3>
                            <div class="flex items-center space-x-6">
                                <img src="{{ $ipd_patient->doctor->image ? asset('avatar/' . $ipd_patient->doctor->image) : asset('img/doctor.png') }}"
                                    alt="Doctor Image" class="w-20 h-20 rounded-full border-2 border-teal-500">
                                <div class="flex-1">
                                    <p class="text-lg font-semibold text-gray-800">Dr. {{ $ipd_patient->doctor->name ?? 'N/A' }}</p>
                                    <p class="text-gray-600 text-sm">{{ $ipd_patient->doctor->email ?? 'N/A' }}</p>
                                    <p class="text-gray-600 text-sm">{{ $ipd_patient->doctor->phone ?? 'N/A' }}</p>
                                </div>
                            </div>
                        </div>

                    </div>

                    {{-- Other Sections --}}
                    @foreach (array_keys($tabs) as $key)
                        @if ($key !== 'overview')
                            <div id="content-{{ $key }}" class="tab-content hidden">
                                @if ($key === 'charges')
                                    @include('ipd.charge')
                                @else
                                    <div class="bg-white p-6 rounded-lg shadow-md">
                                        <p class="text-gray-600">No data available for <strong>{{ $key }}</strong>
                                            yet.</p>
                                    </div>
                                @endif
                            </div>
                        @endif
                    @endforeach

                  

                </div>
            </div>
        </div>
        @include('prescription.pricription_detail_model')
        @include('ipd.payment')
        @include('ipd.opration')


        {{-- Diagnosis Upload Modal --}}
        <div id="diagnosisUploadModal" class="fixed inset-0 z-50 hidden overflow-y-auto">
            <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                <div class="fixed inset-0 transition-opacity modal-overlay" aria-hidden="true">
                    <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
                </div>

                <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>

                <div
                    class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                    <form id="diagnosisUploadForm" enctype="multipart/form-data">
                        @csrf
                        <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                            <h3 class="text-lg leading-6 font-medium text-gray-900 mb-4">Upload Diagnosis Report</h3>

                            <div class="space-y-4">
                                <div>
                                    <label for="report_type" class="block text-sm font-medium text-gray-700">Report Type
                                        *</label>
                                    <input type="text" name="report_type" id="report_type" required
                                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                        placeholder="e.g., Blood Test, X-Ray, MRI Scan">
                                </div>

                                <div>
                                    <label for="report_date" class="block text-sm font-medium text-gray-700">Report Date
                                        *</label>
                                    <input type="date" name="report_date" id="report_date" required
                                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                                </div>

                                <div>
                                    <label for="document" class="block text-sm font-medium text-gray-700">Document</label>
                                    <input type="file" name="document" id="document"
                                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                        accept=".jpg,.jpeg,.png,.pdf,.doc,.docx">
                                    <p class="mt-1 text-sm text-gray-500">Supported formats: JPG, PNG, PDF, DOC, DOCX (Max:
                                        10MB)</p>
                                </div>

                                <div>
                                    <label for="description"
                                        class="block text-sm font-medium text-gray-700">Description</label>
                                    <textarea name="description" id="description" rows="3"
                                        class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                                        placeholder="Additional notes about the report..."></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                            <button type="submit"
                                class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                                Upload Report
                            </button>
                            <button type="button" id="closeDiagnosisModal"
                                class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                                Cancel
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal script -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabs = document.querySelectorAll('.tab-item');
                const contents = document.querySelectorAll('.tab-content');

                function activateTab(tabId) {
                    contents.forEach(content => {
                        content.classList.add('hidden');
                    });
                    tabs.forEach(tab => {
                        tab.classList.remove('border-blue-500', 'text-blue-600', 'font-semibold');
                    });

                    document.getElementById('content-' + tabId).classList.remove('hidden');
                    document.getElementById('tab-' + tabId).classList.add('border-blue-500', 'text-blue-600',
                        'font-semibold');
                }

                tabs.forEach(tab => {
                    tab.addEventListener('click', function() {
                        const target = this.getAttribute('data-tab');
                        activateTab(target);
                    });
                });

                // Set default active tab

                // Diagnosis Uploads Tab Handler
                document.getElementById('tab-diagnosis').addEventListener('click', function() {
                    const diagnosisContent = document.getElementById('content-diagnosis');
                    diagnosisContent.innerHTML = `
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Diagnosis Uploads</h3>
                <button type="button" id="openDiagnosisModalBtn" 
                    class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                    Upload New Report
                </button>
            </div>
            <div id="diagnosisUploadsTableContainer">
                <p class="text-gray-600">Loading diagnosis uploads...</p>
            </div>
        </div>
    `;

                    const ipdPatientId = {{ $ipd_patient->id }};
                    fetchDiagnosisUploads(ipdPatientId);
                    setupDiagnosisModal();
                });
                activateTab('overview');

                document.getElementById('tab-prescriptions').addEventListener('click', function() {
                    const prescriptionsContent = document.getElementById('content-prescriptions');
                    prescriptionsContent.innerHTML = `
        <div class="bg-white p-6 rounded-lg shadow-md">
        <a href="{{ route('admin.ipd.add_prescription', $ipd_patient->id) }}">
            <button id="btn-add-prescription" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded float-right mb-4">
                Add Prescription
            </button>
        </a>

            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">IPD No</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Patients</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Doctors</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Created On</th>
                        <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Action</th>
                    </tr>
                </thead>
                            <tbody class="divide-y divide-gray-200">
                              
                            </tbody>
                        </table>
                    </div>
    `;
                    const patientId = "{{ $ipd_patient->patient_id }}";
                    fetchPrescriptionsByPatient(patientId);
                });
                // Charges tab click handler
                document.getElementById('tab-charges').addEventListener('click', function() {
                    // Initialize Select2 for charge category when tab is clicked
                    setTimeout(() => {
                        if (typeof $ !== 'undefined' && $.fn.select2) {
                            try {
                                // Destroy existing instance if it exists
                                $('#charge_category').select2('destroy');
                            } catch(e) {}
                            
                            // Reinitialize Select2
                            $('#charge_category').select2({
                                placeholder: 'Search and Select Category',
                                allowClear: true,
                                width: '100%'
                            });
                            console.log('Select2 initialized on charges tab');
                        }
                    }, 100);
                });

                document.getElementById('tab-payments').addEventListener('click', function() {
                    const operationsContent = document.getElementById('content-payments');
                    operationsContent.innerHTML = `
        <div class="bg-white p-6 rounded-lg shadow-md">
            <div class="flex justify-between items-center mb-4">
                <h3 class="text-lg font-semibold">Payments</h3>
                <button type="button" id="openpaymentModalBtn" class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded">
                    Add New Payment
                </button>
            </div>
            <div id="PaymentTableContainer"></div>
        </div>
    `;

                    const Id = "{{ $ipd_patient->ipd_no }}";
                    fetchpaymentbyPatient(Id);

                    // Wait until the DOM has rendered before attaching event listeners
                    setTimeout(() => {
                        const openBtn = document.getElementById('openpaymentModalBtn');
                        const closeBtn = document.getElementById('closeIpdPaymentModal');
                        const closeBottomBtn = document.getElementById('closeIpdModalBtnBottom');
                        const modal = document.getElementById('IpdPaymentModal');

                        if (openBtn && closeBtn && closeBottomBtn && modal) {
                            openBtn.addEventListener('click', () => {
                                modal.classList.remove('hidden');
                                modal.classList.add('flex');
                            });

                            closeBtn.addEventListener('click', () => {
                                modal.classList.add('hidden');
                                modal.classList.remove('flex');
                            });

                            closeBottomBtn.addEventListener('click', () => {
                                modal.classList.add('hidden');
                                modal.classList.remove('flex');
                            });
                        }
                    }, 0); // defer to ensure newly injected button is ready
                });





                function fetchPrescriptionsByPatient(patientId) {
                    var urlpre = "{{ route('admin.prescription.prescription_by_patient', ':patientId') }}";
                    urlpre = urlpre.replace(':patientId', patientId);
                    var index = 1; // Initialize index for numbering prescriptions
                    fetch(urlpre)
                        .then(response => response.json())
                        .then(data => {
                            console.log("prescription data", data);
                            const prescriptionsContent = document.getElementById('content-prescriptions');

                            if (Array.isArray(data) && data.length > 0) {
                                let tableHtml = `
                    <div class="bg-white p-6 rounded-lg shadow-md">
                     <a href="{{ route('admin.ipd.add_prescription', $ipd_patient->id) }}">
            <button id="btn-add-prescription" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded float-right mb-4">
                Add Prescription
            </button>
        </a>
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">IPD No</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Patient</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Doctor</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Created On</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                `;

                                data.forEach(prescription => {
                                    tableHtml += `
                        <tr>

                            <td class="px-4 py-2 text-sm text-gray-700">{{ $ipd_patient->ipd_no }}</td>
                            <td class="px-4 py-2 text-sm text-gray-700">${prescription.patient?.name ?? ''}</td>
                            <td class="px-4 py-2 text-sm text-gray-700">${prescription.doctor?.name ?? ''}</td>
                            <td class="px-4 py-2 text-sm text-gray-700">${prescription.created_at ?? ''}</td>
                            <td class="px-4 py-2 text-sm text-blue-600">
<i onclick="openModalprecription(${prescription.id})" class="fas fa-eye text-blue-600 cursor-pointer hover:text-blue-700" title="View Prescription"></i>
                                <form action="{{ route('admin.prescription.delete', '') }}/${prescription.id}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:underline ml-2"><i class="fas fa-trash" style="color:red"></i></button>
                                    
                                </form>
                                <a href="{{ route('admin.prescription.print', '') }}/${prescription.id}" target="_blank" class="text-green-600 hover:underline ml-2">
                                    <i class="fas fa-print" title="Print Prescription"></i>
                                </a>
                            </td>
                        </tr>
                    `;
                                });

                                tableHtml += `
                            </tbody>
                        </table>
                    </div>
                `;
                                prescriptionsContent.innerHTML = tableHtml;
                            } else {
                                prescriptionsContent.innerHTML = `
                    <div class="bg-white p-6 rounded-lg shadow-md">
<a href="{{ route('admin.ipd.add_prescription', $ipd_patient->id) }}">
            <button id="btn-add-prescription" class="bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded float-right mb-4">
                Add Prescription
            </button>
        </a>
                        <p class="text-gray-600">No prescriptions found for this patient.</p>
                    </div>
                `;
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            const prescriptionsContent = document.getElementById('content-prescriptions');
                            prescriptionsContent.innerHTML = `
                <div class="bg-white p-6 rounded-lg shadow-md">
                    <p class="text-red-500">An error occurred while fetching prescriptions.</p>
                </div>
            `;
                        });
                }


            });

            // Show prescription modal on button click
            document.addEventListener('click', function(e) {
                if (e.target && e.target.id === 'btn-add-prescription') {
                    var modal = new bootstrap.Modal(document.getElementById('prescriptionModal'));
                    modal.show();
                }
            });
        </script>
        <script>
            // Fetch diagnosis by patient ID
            function fetchDiagnosisByPatient(patientId) {
                fetch(`admin/diagnosis/test/Diagnosisbypatient/${patientId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Process and display the diagnosis data
                            console.log(data.data);
                        } else {
                            console.error('Failed to fetch diagnosis data');
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                    });
            }
        </script>
        <script>
            document.getElementById('tab-bills').addEventListener('click', function() {
                const operationsContent = document.getElementById('content-bills');

                operationsContent.innerHTML = `
        <div class="custom-container">
            <!-- Left Column -->
            <div class="left-section">
                <div class="billing-container" id="chargesBillingContainer">
                    <!-- Charges content will be inserted here dynamically -->
                </div>
               
            </div>

            <!-- Right Column -->
            <div class="right-section">
                <div id="payment">
                </div>
            </div>
        </div>
    `;

                const Id = "{{ $ipd_patient->patient_id }}";
                const ipdNo = "{{ $ipd_patient->ipd_no }}";
                fetchchargesforbilling(Id, ipdNo);
                fetchpaymentforbill(Id, ipdNo);
            });
        </script>
        <script>
            function formatDate(rawDate) {
                // Remove ordinal suffixes: st, nd, rd, th
                const cleanDate = rawDate.replace(/(\d+)(st|nd|rd|th)/, '$1');

                // Convert to Date object
                const date = new Date(cleanDate);

                if (isNaN(date)) return rawDate; // fallback if date is invalid

                // Format output: 23 Dec 2021
                const options = {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric'
                };
                return date.toLocaleDateString('en-GB', options);
            }
        </script>
        <script>
            function fetchchargesforbilling(id, ipdNo) {
                console.log("ipd id", id);

                var urlcharge = "{{ route('admin.ipd.charge', ':id') }}";
                urlcharge = urlcharge.replace(':id', ipdNo);

                fetch(urlcharge)
                    .then(response => response.json())
                    .then(data => {
                        console.log("charges data", data);

                        const charges = data.data;
                        const chargesContent = document.getElementById('chargesBillingContainer');
                        const totalcharges = document.getElementById('totel-charge');

                        if (charges.length > 0) {
                            let tableHtml = `
                    <div class="bg-white p-6 ">
                    <h1>Charge</h1>
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead>
                                <tr>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Date</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Charge Type</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Code</th>
                                    <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Amount</th>
                                  
                                   
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200">
                `;

                            // Get delete route base (without ID)
                            const deleteRouteTemplate = "{{ route('admin.charge.delete', ':id') }}";
                            var totalCharge = 0;
                            charges.forEach(charge => {
                                const deleteUrl = deleteRouteTemplate.replace(':id', charge.id);
                                totalCharge += parseFloat(charge.total);

                                tableHtml += `
                        <tr>
                            <td class="px-4 py-2 text-sm text-gray-700">${formatDate(charge.date)}</td>
                            <td class="px-4 py-2 text-sm text-gray-700">${charge.charge_type?charge.charge_type.name: '-'}</td>
                            <td class="px-4 py-2 text-sm text-gray-700">${charge.code ?? '-'}</td>
                            <td class="px-4 py-2 text-sm text-gray-700"> &#8377;${charge.total ?? '-'}</td>
                            
                        </tr>
                       
                    `;
                            });

                            tableHtml += ` <tr>
                        <td>Total Charge</td><td></td><td></td><td> &#8377;${totalCharge}</td>
                        </tr>
                            </tbody>
                        </table>
                       
                    </div>
                `;

                            chargesContent.innerHTML = tableHtml;


                        } else {
                            chargesContent.innerHTML = `
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Charge Type</th>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Code</th>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Standard Charge</th>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Applied Charge</th>
                              
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
                            <tr>
                                <td colspan="5" class="px-4 py-2 text-sm text-gray-700 text-center">No charges found for this patient.</td>
                            </tr>
                        </tbody>
                    </table>
                `;
                        }
                    })
                    .catch(error => console.error('Error fetching charges data:', error));
            }

            // Optional: utility function to format date
            function formatDate(dateString) {
                const options = {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                };
                return new Date(dateString).toLocaleDateString(undefined, options);
            }

            function fetchpaymentforbill(id, ipd_no) {
                console.log("ipd id", id);
                var ipd_id = {{ $ipd_patient->id }}
                var urldischarge = "{{ route('admin.ipd.discharge.patient', ':id') }}";
                urldischarge = urldischarge.replace(':id', ipd_id);
                var urlcharge = "{{ route('admin.Payment.billcharge', ':id') }}";
                urlcharge = urlcharge.replace(':id', ipd_no);
                const pdfRouteTemplate = "{{ route('admin.Payment.pdf', ['id' => ':id']) }}";
                const pdfUrl = pdfRouteTemplate.replace(':id', ipd_no);
                const dischargeRouteTemplate = "{{ route('admin.ipd.discharge', ['id' => ':id']) }}";
                const dischargeUrl = dischargeRouteTemplate.replace(':id', id);

                const dischargeDate = @json($ipd_patient->discharge_date);


                let totalPayment = 0;
                let totalDiscount = 0;

                fetch(urlcharge)
                    .then(response => response.json())
                    .then(data => {
                        console.log("bill charge=", data)
                        const ipdPayments = data.payments || [];
                        // const bedCharge = parseFloat(data.bed_charges_from_today) || 0;
                        const totalOtherCharges = parseFloat(data.total_other_charges) || 0;

                        const grossTotal = totalOtherCharges;

                        const PaymentTableContainer = document.getElementById('payment');

                        // Start table HTML
                        let tableHtml = `
                <div class="bg-white p-6">
                    <h1>Payment</h1>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Payment Mode</th>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Date</th>
                                <th class="px-4 py-2 text-left text-sm font-medium text-gray-500">Paid Amount</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200">
            `;

                        ipdPayments.forEach(payment => {
                            const paymentAmount = parseFloat(payment.amount || 0);
                            const paymentMode = payment.payment_mode?.name || 'N/A';
                            const formattedDate = formatDate(payment.payment_date);

                            // Check if payment mode is discount
                            if (paymentMode.toLowerCase() === 'discount') {
                                totalDiscount += paymentAmount;
                            } else {
                                totalPayment += paymentAmount;
                            }

                            tableHtml += `
                    <tr>
                        <td class="px-4 py-2 text-sm text-gray-700">${paymentMode}</td>
                        <td class="px-4 py-2 text-sm text-gray-700">${formattedDate}</td>
                        <td class="px-4 py-2 text-sm text-gray-700">&#8377;${paymentAmount}</td>
                    </tr>
                `;
                        });

                        const netPayable = (grossTotal - totalDiscount) - totalPayment;

                        tableHtml += `
                <tr><td>Total Payment</td><td></td><td> &#8377;${totalPayment}</td></tr>
                <tr><th>Bill Summary</th><th></th><th></th></tr>
               
                <tr><td>Total Charges:</td><td></td><td>&#8377;${totalOtherCharges.toFixed(2)}</td></tr>
                <tr><td>Gross Total:</td><td></td><td>&#8377;<span id="grossTotal">${grossTotal.toFixed(2)}</span></td></tr>
                <tr><td>Discount:</td><td></td><td>&#8377;<span id="discountTotal">${totalDiscount.toFixed(2)}</span></td></tr>
            {{--     <tr><td>Discount By:</td><td></td><td><input type="text"  class="billinput" id="discountby" /></td></tr>
                <tr><td>Discount In Percentage (%) :</td><td></td><td><input type="number" class="billinput" value="0" id="discount" /></td></tr>
                <tr><td>Tax In Percentage (%) :</td><td></td><td><input type="number" value="0" class="billinput" id="tax" /></td></tr>
                <tr><td>Other Charges:</td><td></td><td><input type="number" value="0" class="billinput" id="otherchage" /></td></tr>   --}}
               
                <tr><td>Paid Amount:</td><td></td><td>&#8377;${totalPayment}</td></tr>
                <tr><td>Net Payable Amount (Unpaid):</td><td></td><td>&#8377;<span id="netPayable">${netPayable.toFixed(2)}</span></td></tr>
                </tbody>
                </table>
                <br/>
<a id="printBillBtn" href="${pdfUrl}" target="_blank">
    <button style="background:green; padding:10px; border-radius:8px; color:white">Print Bill</button>
</a>

            `;
                        if (!dischargeDate) {
                            tableHtml += `
                    <form action="${urldischarge}" method="POST" id="ipddischarge" onsubmit="formSubmit2(event, this, false, 'ipddischarge')">
                        @csrf
                        @method('PUT')
                        <button type="submit" style="margin-top: 10px; background: red; color: white; padding: 8px 12px; border-radius: 6px;">Discharge Patient</button>
                    </form>
                `;
                        }

                        // Inject HTML first
                        PaymentTableContainer.innerHTML = tableHtml;

                        // Add event listeners after elements are in the DOM
                        const discountInput = document.getElementById('discount');
                        const taxInput = document.getElementById('tax');
                        const otherChargeInput = document.getElementById('otherchage');

                        const printBillBtn = document.getElementById('printBillBtn');
                        const discountby = document.getElementById('discountby');

                        const calculateBill = () => {
                            let finalTotal = 0;
                            const discount = parseFloat(discountInput.value) || 0;
                            const tax = parseFloat(taxInput.value) || 0;
                            const otherCharge = parseFloat(otherChargeInput.value) || 0;
                            const discountByName = discountby.value || 'N/A';
                            let discountedTotal = grossTotal - (discount / 100 * grossTotal);
                            let taxedTotal = discountedTotal + (tax / 100 * discountedTotal);
                            if (discount > 0 || tax > 0 || otherCharge > 0) {
                                finalTotal = taxedTotal + otherCharge;
                            } else {
                                finalTotal = parseFloat(document.getElementById('grossTotal').value);

                            }


                            let unpaidAmount = finalTotal - totalPayment;

                            document.getElementById('netPayable').innerText = unpaidAmount.toFixed(2);

                            // Update PDF URL with parameters
                            const updatedPdfUrl =
                                `${pdfUrl}?discount=${discount}&tax=${tax}&otherCharge=${otherCharge}&finalTotal=${finalTotal.toFixed(2)}&discountBy=${encodeURIComponent(discountByName)}`;

                            printBillBtn.setAttribute('href', updatedPdfUrl);
                        };

                        discountInput.addEventListener('input', calculateBill);
                        taxInput.addEventListener('input', calculateBill);
                        otherChargeInput.addEventListener('input', calculateBill);
                    })
                    .catch(error => console.error('Error fetching payment data:', error));
            }

            // Utility to format date
            function formatDate(dateString) {
                const options = {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                };
                return new Date(dateString).toLocaleDateString(undefined, options);
            }


            // Diagnosis Upload Functions
            function setupDiagnosisModal() {
                const modal = document.getElementById('diagnosisUploadModal');
                const openBtn = document.getElementById('openDiagnosisModalBtn');
                const closeBtn = document.getElementById('closeDiagnosisModal');
                const form = document.getElementById('diagnosisUploadForm');

                if (openBtn) {
                    openBtn.addEventListener('click', () => {
                        modal.classList.remove('hidden');
                        document.getElementById('report_date').valueAsDate = new Date();
                    });
                }

                if (closeBtn) {
                    closeBtn.addEventListener('click', () => {
                        modal.classList.add('hidden');
                        form.reset();
                    });
                }

                modal.addEventListener('click', (e) => {
                    if (e.target === modal) {
                        modal.classList.add('hidden');
                        form.reset();
                    }
                });

                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    uploadDiagnosisReport();
                });
            }

            function fetchDiagnosisUploads(ipdPatientId) {
                const url = "{{ route('admin.ipd.diagnosis_uploads.index', ':id') }}".replace(':id', ipdPatientId);

                fetch(url)
                    .then(response => response.json())
                    .then(data => {
                        const container = document.getElementById('diagnosisUploadsTableContainer');

                        if (data.status === 'success' && data.data.length > 0) {
                            let tableHtml = `
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">#</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Report Type</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Report Date</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Document</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="bg-white divide-y divide-gray-200">
                `;
                            let downloadRouteTemplate =
                                "{{ route('admin.ipd.diagnosis_uploads.download', ['id' => ':id']) }}";

                            data.data.forEach((item, index) => {
                                const reportDate = new Date(item.report_date).toLocaleDateString();
                                const downloadUrl = item.document ? downloadRouteTemplate.replace(':id', item.id) :
                                    '#';
                                const documentName = item.document ? item.document.split('/').pop() : 'No document';

                                tableHtml += `
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${index + 1}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${item.report_type}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${reportDate}</td>
                          <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
    ${item.document ? 
        `<a href="${downloadUrl}" class="text-blue-600 hover:text-blue-900" target="_blank">
                    <i class="fas fa-download mr-1"></i>${documentName}
                </a>` : 
        '<span class="text-gray-400">No document</span>'
    }
</td>
                            <td class="px-6 py-4 text-sm text-gray-900">${item.description || '-'}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <button onclick="deleteDiagnosisUpload(${item.id})" 
                                    class="text-red-600 hover:text-red-900 ml-2" title="Delete Report">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    `;
                            });

                            tableHtml += `
                            </tbody>
                        </table>
                    </div>
                `;
                            container.innerHTML = tableHtml;
                        } else {
                            container.innerHTML = `
                    <div class="text-center py-8">
                        <i class="fas fa-file-medical text-gray-400 text-4xl mb-4"></i>
                        <p class="text-gray-500">No diagnosis reports uploaded yet.</p>
                        <p class="text-gray-400 text-sm mt-2">Click "Upload New Report" to add the first one.</p>
                    </div>
                `;
                        }
                    })
                    .catch(error => {
                        console.error('Error fetching diagnosis uploads:', error);
                        const container = document.getElementById('diagnosisUploadsTableContainer');
                        container.innerHTML = `
                <div class="text-center py-8 text-red-600">
                    <i class="fas fa-exclamation-triangle text-4xl mb-4"></i>
                    <p>Failed to load diagnosis reports.</p>
                </div>
            `;
                    });
            }

            function uploadDiagnosisReport() {
                const ipdPatientId = {{ $ipd_patient->id }};
                const form = document.getElementById('diagnosisUploadForm');
                const formData = new FormData(form);

                const submitBtn = form.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i>Uploading...';
                submitBtn.disabled = true;

                const url = "{{ route('admin.ipd.diagnosis_uploads.store', ':id') }}".replace(':id', ipdPatientId);

                fetch(url, {
                        method: 'POST',
                        body: formData,
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            document.getElementById('diagnosisUploadModal').classList.add('hidden');
                            form.reset();
                            // Show success notification
                            const notification = document.createElement('div');
                            notification.className =
                                'fixed top-4 right-4 p-4 rounded-lg shadow-lg text-white bg-green-500 z-50';
                            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas fa-check-circle mr-2"></i>
                    <span>Report uploaded successfully!</span>
                </div>
            `;
                            document.body.appendChild(notification);
                            setTimeout(() => notification.remove(), 3000);

                            fetchDiagnosisUploads(ipdPatientId);
                        } else {
                            throw new Error(data.message || 'Upload failed');
                        }
                    })
                    .catch(error => {
                        console.error('Error uploading report:', error);
                        // Show error notification
                        const notification = document.createElement('div');
                        notification.className = 'fixed top-4 right-4 p-4 rounded-lg shadow-lg text-white bg-red-500 z-50';
                        notification.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span>Failed to upload report!</span>
            </div>
        `;
                        document.body.appendChild(notification);
                        setTimeout(() => notification.remove(), 3000);
                    })
                    .finally(() => {
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                    });
            }

            function deleteDiagnosisUpload(id) {
                if (!confirm('Are you sure you want to delete this diagnosis report?')) return;

                const url = "{{ route('admin.ipd.diagnosis_uploads.destroy', ':id') }}".replace(':id', id);

                fetch(url, {
                        method: 'DELETE',
                        headers: {
                            'X-CSRF-TOKEN': '{{ csrf_token() }}',
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {
                            // Refresh the diagnosis tab
                            document.getElementById('tab-diagnosis').click();

                            // Show success notification
                            const notification = document.createElement('div');
                            notification.className =
                                'fixed top-4 right-4 p-4 rounded-lg shadow-lg text-white bg-green-500 z-50';
                            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas fa-check-circle mr-2"></i>
                    <span>Report deleted successfully!</span>
                </div>
            `;
                            document.body.appendChild(notification);
                            setTimeout(() => notification.remove(), 3000);
                        } else {
                            throw new Error(data.message || 'Delete failed');
                        }
                    })
                    .catch(error => {
                        console.error('Error deleting report:', error);
                        // Show error notification
                        const notification = document.createElement('div');
                        notification.className = 'fixed top-4 right-4 p-4 rounded-lg shadow-lg text-white bg-red-500 z-50';
                        notification.innerHTML = `
            <div class="flex items-center">
                <i class="fas fa-exclamation-triangle mr-2"></i>
                <span>Failed to delete report!</span>
            </div>
        `;
                        document.body.appendChild(notification);
                        setTimeout(() => notification.remove(), 3000);
                    });
            }
        </script>
    </body>

@endsection
