<!DOCTYPE html>
<html>

<head>
    <title>Admission Slip - {{ $ipdPatient->ipd_no }}</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 13px;
            background: #fff;
            color: #222;
            line-height: 1.4;
            margin: 0;
            padding: 0;
        }

        .bill-container {
            width: 750px;
            margin: 0 auto;
            /* Removed top margin for print accuracy */
            background: #fff;
            /* Border removed for actual print on letterhead, kept dashed for preview */
            border: 1px dashed #ccc;
            padding: 0 40px;
            /* Side padding */
            position: relative;
            min-height: 100vh;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
        }

        /* --- LETTERHEAD ADJUSTMENTS --- */
        .header-space {
            height: 180px;
            /* Increased for Letterhead Header */
            width: 100%;
            display: block;
        }
        
        
        /* --- HEADER STYLE --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#000') !!};
            padding-bottom: 5px;
            margin-bottom: 10px;
        }

        .footer-space {
            height: 100px;
            /* Increased for Letterhead Footer */
            width: 100%;
            display: block;
        }

        /* --------------------------- */

        .main-title {
            text-align: center;
            font-weight: bold;
            font-size: 18px;
            margin-bottom: 20px;
            text-decoration: underline;
            text-transform: uppercase;
            color: #000;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            border: 1px solid #000;
        }

        .info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border: 1px solid #000;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            width: 18%;
            font-weight: bold;
        }

        .info-table td:nth-child(even) {
            width: 32%;
            font-weight: bold;
        }

        .declaration-header {
            text-align: center;
            font-weight: bold;
            font-size: 15px;
            text-decoration: underline;
            margin: 15px 0 10px 0;
        }

        .declaration-content {
            text-align: justify;
            font-size: 13px;
            margin-bottom: 12px;
            line-height: 1.5;
        }

        .footer-info {
            margin-top: 15px;
            font-weight: bold;
            font-size: 13px;
            line-height: 1.8;
        }

        .signature-box {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 20px;
            padding-bottom: 35px;
        }

        .signature-item {
            text-align: center;
            font-weight: bold;
            font-size: 12px;
            width: 30%;
            border-top: 1px solid #333;
            padding-top: 5px;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            font-size: 14px;
            background-color: #333;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 1000;
        }

        @media print {
            body {
                margin: 0;
                padding: 0;
            }

            .print-btn {
                display: none;
            }

            .bill-container {
                border: none;
                /* No border in print */
                width: 100%;
                max-width: 100%;
                margin: 0;
                padding: 0 40px;
                /* Keep side padding */
            }

            .info-table td {
                background-color: transparent !important;
                /* Remove grey bg for clean print */
                -webkit-print-color-adjust: exact;
            }

            @page {
                margin: 0;
                /* Remove default page margins to control via CSS */
                size: A4 portrait;
            }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Slip</button>

    <div class="bill-container">

         <table class="header-table">
            <tr>
                <td style="width:80px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:20px; font-weight:bold; color: {!! setting('theme_color', '#000') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #333;">
                        {{ setting('tagline', 'Tagline Here') }}<br>
                        {{ setting('address', 'Address Line 1, City') }}<br>
                        Phone: +91 {{ setting('phone') }}
                    </div>
                </td>
            </tr>
        </table>

        <div class="main-title">ADMISSION DETAILS</div>

        <table class="info-table">
            <tr>
                <td>UHID :-</td>
                <td>{{ $uhid }}</td>
                <td>Admission No :-</td>
                <td>{{ $ipdPatient->ipd_no }}</td>
            </tr>
            <tr>
                <td>Patient Name :-</td>
                <td>{{ strtoupper($ipdPatient->patient->name) }}</td>
                <td>Admission Date :-</td>
                <td>{{ date('d-m-Y', strtotime($ipdPatient->admission_date)) }}</td>
            </tr>
            <tr>
                <td>Gender :-</td>
                <td>{{ ucfirst($ipdPatient->patient->gender) }}</td>
                <td>Admission Time :-</td>
                <td>{{ date('h:i A', strtotime($ipdPatient->admission_date)) }}</td>
            </tr>
            <tr>
                <td>Age :-</td>
                <td>{{ $ipdPatient->patient->age ?? '0' }} Year</td>
                <td>Ward-Bed No :-</td>
                <td>{{ $ipdPatient->beds->name ?? 'N/A' }}</td>
            </tr>
            <tr>
                <td>Guardian Name :-</td>
                <td> {{ $ipdPatient->patient->guardian_name }}</td>
                <td>Mobile :-</td>
                <td>{{ $ipdPatient->patient->phone }}</td>
            </tr>
            <tr>
                <td>Address :-</td>
                <td colspan="3">{{ $ipdPatient->patient->address }}</td>
            </tr>
            <tr>
                <td>Consultant :-</td>
                <td colspan="3">Dr. {{ strtoupper($ipdPatient->doctor->name) }}</td>

            </tr>
        </table>

        <div class="declaration-header">**घोषणा / सहमति पत्र**</div>

        <div class="declaration-content">
            मैं यह घोषणा करता/करती हूँ कि मैं अपने मरीज को अपनी पूर्ण इच्छा से इस अस्पताल में भर्ती करा रहा/रही हूँ। मैं
            यह पूर्णतः समझता/समझती हूँ कि यह एक निजी अस्पताल है तथा इलाज के दौरान होने वाले सभी खर्चों की जिम्मेदारी
            मेरी स्वयं की होगी।
        </div>

        <div class="declaration-content">
            मैं अस्पताल के सभी नियमों, शर्तों एवं नीतियों से पूर्णतः अवगत हूँ और बिना किसी दबाव, प्रलोभन या जबरदस्ती के
            यह निर्णय ले रहा/रही हूँ।
        </div>

        <div class="declaration-content">
            मैं यह भी पुष्टि करता/करती हूँ कि अपने मरीज के इलाज एवं अस्पताल में रहने के दौरान आवश्यक सभी भुगतान करने के
            लिए मैं पूर्णतः सहमत एवं सक्षम हूँ।
        </div>
        <div class="declaration-content">
            मैं अपने मरीज का इस अस्पताल में इलाज कराने के लिए अपनी स्वेच्छा से सहमति प्रदान करता/करती हूँ। मुझे इलाज के
            दौरान होने वाली संभावित जोखिमों, जटिलताओं एवं अनहोनी घटनाओं के बारे में अस्पताल के चिकित्सक द्वारा
            विस्तारपूर्वक समझाया गया है।
        </div>
        <div class="declaration-content">
            उपरोक्त सभी तथ्यों को भली-भांति समझने के उपरांत, मैं अपने मरीज के इलाज हेतु स्वेच्छा से सहमति देता/देती हूँ
            तथा अस्पताल प्रशासन, चिकित्सकों एवं चिकित्सा स्टाफ को आवश्यक उपचार प्रदान करने की अनुमति देता/देती हूँ। इलाज
            के दौरान किसी भी प्रकार की अनहोनी घटना के लिए मैं अस्पताल, उसके प्रबंधन, डॉक्टर अथवा किसी भी संबंधित व्यक्ति
            को उत्तरदायी नहीं ठहराऊँगा/ठहराऊँगी।
        </div>


        <div class="footer-info">
            <div>Guardian Name :- {{ strtoupper($ipdPatient->patient->guardian_name) }}</div>
            <div>Relation with Patient :- </div>
            <div>Address :- {{ $ipdPatient->patient->address }}</div>
            <div>Mobile Number :- {{ $ipdPatient->patient->phone }}</div>
        </div>

        <div style="flex: 1;"></div>

        <div class="signature-box">
            <div class="signature-item">
                Sign of Patient or Representative
            </div>
            <div class="signature-item">
                Signatory Relationship
            </div>
            <div class="signature-item">
                Sign of Admitting clerk
            </div>
        </div>

        <div class="footer-space"></div>

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>
