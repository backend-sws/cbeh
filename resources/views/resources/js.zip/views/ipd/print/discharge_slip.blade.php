<!DOCTYPE html>
<html>
<head>
    <title>Discharge & Gate Pass - {{ $ipdPatient->ipd_no }}</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif; /* Original Font */
            font-size: 16px;
            margin: 0; padding: 0;
        }
        .container {
            width: 750px;
            margin: 0 auto;
            padding: 10px;
        }
        
        /* --- HEADER STYLE --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#000') !!};
            padding-bottom: 5px;
            margin-bottom: 20px;
        }
        /* -------------------- */
        
        /* Common Box Style */
        .box {
            border: 2px solid #000;
            padding: 10px;
            margin-bottom: 20px; 
        }

        .title {
            text-align: center; font-weight: bold; font-size: 16px;
            text-decoration: underline; text-transform: uppercase; margin-bottom: 10px;
        }
        .sub-title {
            text-align: center; font-weight: bold; font-size: 14px; margin-bottom: 10px;
        }

        table.details { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
        table.details td { border: 1px solid #000; padding: 3px 6px; vertical-align: top; }
        
        .label { font-weight: bold; width: 18%; background: #eee; }
        .val { font-weight: bold; width: 32%; }

        .content-text { margin: 15px 0; line-height: 1.5; text-align: justify; }
        .signature { text-align: right; margin-top: 40px; font-weight: bold; }

        .print-btn {
            position: fixed; top: 10px; right: 10px; background: #333; color: #fff; padding: 10px; cursor: pointer;
        }

        @media print {
            .print-btn { display: none; }
            @page { margin: 5mm; size: A4; }
            .label { background: #eee !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>
    <button onclick="window.print()" class="print-btn">Print Slip</button>

    <div class="container">

        <table class="header-table">
            <tr>
                <td style="width:80px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:20px; font-weight:bold; color: {!! setting('theme_color', '#000') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #333;">
                        {{ setting('tagline', 'Tagline Here') }}<br>
                        {{ setting('address', 'Address Line 1, City') }}<br>
                        Phone: +91 {{ setting('phone') }}
                    </div>
                </td>
            </tr>
        </table>
        <div class="box">
            <div class="title">DISCHARGE REQUEST LETTER</div>
            {{-- <div class="sub-title">DRL NO: - {{ $ipdPatient->id }}</div> --}}

            <table class="details">
                <tr>
                    <td class="label">UHID</td> <td class="val">{{ $uhid }}</td>
                    <td class="label">Admission No</td> <td class="val">{{ $ipdPatient->ipd_no }}</td>
                </tr>
                <tr>
                    <td class="label">Patient Name</td> <td class="val">{{ strtoupper($ipdPatient->patient->name) }}</td>
                    <td class="label">Admission Date</td> <td class="val">{{ date('d-m-Y', strtotime($ipdPatient->admission_date)) }}</td>
                </tr>
                <tr>
                    <td class="label">Gender/Age</td> <td class="val">{{ ucfirst($ipdPatient->patient->gender) }} / {{ $ipdPatient->patient->age }}Y</td>
                    <td class="label">Ward-Bed</td> <td class="val">{{ $ipdPatient->beds->name ?? '-' }}</td>
                </tr>
                <tr>
                    <td class="label">Guardian</td> <td class="val">{{ $ipdPatient->patient->guardian_name }}</td>
                    <td class="label">Mobile</td> <td class="val">{{ $ipdPatient->patient->phone }}</td>
                </tr>
                <tr>
                    <td class="label">Consultant</td> <td class="val" colspan="3"> {{ strtoupper($ipdPatient->doctor->name) }}</td>
                    {{-- <td class="label">Payment Mode</td> <td class="val">Cash</td> --}}
                </tr>
            </table>

            <div class="content-text">
                <b>Dear In-Charge,</b><br><br>
                Please arrange for the discharge of the above mentioned patient from the ICU/Ward. All bills and dues related to hospital services, including Pathology, Pharmacy and other facilities have been cleared. There are no outstanding payments of dues pending.
                <br><br>
                We request your prompt attention to facilitate a smooth discharge process.
                <br>
                Thank you for your cooperation.
            </div>

            <div class="signature">Authorized Signature</div>
        </div>

        <div style="border-top: 2px dashed #000; margin: 20px 0; position: relative; text-align: center;">
            <span style="background: #fff; padding: 0 10px; font-size: 10px; position: relative; top: -8px;">CUT HERE</span>
        </div>

        
        <table class="header-table">
            <tr>
                <td style="width:80px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:20px; font-weight:bold; color: {!! setting('theme_color', '#000') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #333;">
                        {{ setting('tagline', 'Tagline Here') }}<br>
                        {{ setting('address', 'Address Line 1, City') }}<br>
                        Phone: +91 {{ setting('phone') }}
                    </div>
                </td>
            </tr>
        </table>

        <div class="box">
            <div class="title">GATE PASS</div>
            {{-- <div class="sub-title">PASS NO: - {{ $ipdPatient->id }}</div> --}}

            <table class="details">
                <tr>
                    <td class="label">UHID</td> <td class="val">{{ $uhid }}</td>
                    <td class="label">Admission No</td> <td class="val">{{ $ipdPatient->ipd_no }}</td>
                </tr>
                <tr>
                    <td class="label">Patient Name</td> <td class="val">{{ strtoupper($ipdPatient->patient->name) }}</td>
                    <td class="label">Admission Date</td> <td class="val">{{ date('d-m-Y', strtotime($ipdPatient->admission_date)) }}</td>
                </tr>
                <tr>
                    <td class="label">Consultant</td> <td class="val">Dr. {{ strtoupper($ipdPatient->doctor->name) }}</td>
                    <td class="label">Discharge Time</td> <td class="val">{{ date('d-m-Y h:i A') }}</td>
                </tr>
            </table>

            <div class="content-text">
                This is to certify that all dues have been settled and there are no outstanding payments pending. This gate pass is valid for the patient to exit the premises. Please ensure proper verification before allowing departure.
            </div>

            <div class="signature" style="margin-top: 50px;">Authorized Signature</div>
        </div>

    </div>
     <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>