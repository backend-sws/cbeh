<!DOCTYPE html>
<html>
<head>
    <title>No Dues Certificate - {{ $ipdPatient->ipd_no }}</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 13px;
            margin: 0; padding: 0;
        }
        .container {
            width: 700px;
            margin: 10px auto;
            padding: 10px;
            min-height: 95vh;
            position: relative;
            border: 1px dashed #ccc; /* Helper border for screen */
        }

        /* --- HEADER STYLE --- */
        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#000') !!};
            padding-bottom: 5px;
            margin-bottom: 10px;
        }

        /* --- PATIENT INFO BOX --- */
        /* .box {
            border: 2px solid #000;
            padding: 5px;
            margin-bottom: 20px;
        } */

        table.details { width: 100%; border-collapse: collapse; }
        table.details td { 
            border: 1px solid #000; 
            padding: 4px 6px; 
            vertical-align: top; 
        }
        .label { font-weight: bold; width: 15%; background: #eee; }
        .val { font-weight: bold; width: 35%; }

        /* --- TITLES --- */
        .main-title {
            text-align: center; font-weight: bold; font-size: 16px;
            text-decoration: underline; text-transform: uppercase; margin-bottom: 5px;
            margin-top: 10px;
        }
        .sub-title {
            text-align: center; font-weight: bold; font-size: 13px; margin-bottom: 15px;
        }
        .section-header {
            text-align: center; font-weight: bold; text-decoration: underline; margin: 20px 0 5px 0;
        }

        /* --- DATA TABLES (Bill & Payment) --- */
        table.data-table {
            width: 100%; border-collapse: collapse; margin-bottom: 10px;
        }
        table.data-table th {
            border: 1px solid #000; padding: 5px; background: #eee; text-align: center; font-weight: bold;
        }
        table.data-table td {
            border: 1px solid #000; padding: 5px; height: 30px; /* Fixed height for empty rows */
        }

        /* --- FOOTER SIGNATURES --- */
        .signature-box {
            display: flex; justify-content: space-between; align-items: flex-end;
            margin-top: 80px; margin-bottom: 10px;
        }
        .signature-item {
            text-align: center; font-weight: bold; font-size: 12px; width: 30%;
            border-top: 1px dashed #000; padding-top: 5px;
        }

        .print-btn {
            position: fixed; top: 10px; right: 10px; background: #333; color: #fff; padding: 10px; cursor: pointer;
        }

        @media print {
            .print-btn { display: none; }
            .container { border: none; margin: 0; width: 750px; }
            @page { margin: 5mm; size: A4; }
            .label, th { background: #eee !important; -webkit-print-color-adjust: exact; }
        }
    </style>
</head>
<body>
    <button onclick="window.print()" class="print-btn">Print No Dues</button>

    <div class="container">

        <table class="header-table">
            <tr>
                <td style="width:80px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height: 70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:20px; font-weight:bold; color: {!! setting('theme_color', '#000') !!}; margin-bottom: 5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size: 12px; color: #333;">
                        {{ setting('tagline', 'Tagline Here') }}<br>
                        {{ setting('address', 'Address Line 1, City') }}<br>
                        Phone: +91 {{ setting('phone') }}
                    </div>
                </td>
            </tr>
        </table>

        <div class="box">
            <table class="details">
                <tr>
                    <td class="label">UHID</td> <td class="val">{{ $uhid }}</td>
                    <td class="label">Admission No</td> <td class="val">{{ $ipdPatient->ipd_no }}</td>
                </tr>
                <tr>
                    <td class="label">Patient Name</td> <td class="val">{{ strtoupper($ipdPatient->patient->name) }}</td>
                    <td class="label">Admission Date</td> <td class="val">{{ date('d-m-Y', strtotime($ipdPatient->admission_date)) }}</td>
                </tr>
                <tr>
                    <td class="label">Gender/Age</td> <td class="val">{{ ucfirst($ipdPatient->patient->gender) }} / {{ $ipdPatient->patient->age }}Y</td>
                    <td class="label">Admission Time</td> <td class="val">{{ date('h:i A', strtotime($ipdPatient->admission_date)) }}</td>
                </tr>
                <tr>
                    <td class="label">Guardian</td> <td class="val">{{ $ipdPatient->patient->guardian_name }}</td>
                    <td class="label">Ward-Bed</td> <td class="val">{{ $ipdPatient->beds->name ?? '-' }}</td>
                </tr>
                <tr>
                    <td class="label">Address</td> <td class="val" colspan="3">{{ $ipdPatient->patient->address }}</td>
                </tr>
                <tr>
                    <td class="label">Discharge Date</td> <td class="val">{{ $ipdPatient->discharge_date ? date('d-m-Y', strtotime($ipdPatient->discharge_date)) : 'N/A' }}</td>
                    <td class="label">Discharge Time</td> <td class="val">{{ $ipdPatient->discharge_date ? date('h:i A', strtotime($ipdPatient->discharge_date)) : 'N/A' }}</td>
                </tr>
                <tr>
                    <td class="label">Consultant</td> <td class="val" colspan="3">{{ $ipdPatient->doctor->name }}</td>
                    <!--<td class="label">Payment Mode</td> <td class="val">Cash</td>-->
                </tr>
            </table>
        </div>

        <div class="main-title ">NO DUES CERTIFICATE</div>
        {{-- <div class="sub-title">NDC NO :- {{ $ipdPatient->id }}</div> --}}

        <table class="data-table">
            <thead>
                <tr>
                    <th width="40%">DEPARTMENT</th>
                    <th width="20%">DUES</th>
                    <th width="40%">SIGNATURE</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Hospital Bill</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Pharmacy Bill</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Pathology Bill</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Any Other (If any) Bill</td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>
           <div class="signature-box">
               <div style="visibility: hidden" class="signature-item">Verified By</div>
               <div style="visibility: hidden" class="signature-item">Approved By</div>
               <div class="signature-item">Patient/Guardian's Signature</div>
        </div>

           <div style="border-top: 2px dashed #000; margin: 20px 0; position: relative; text-align: center;">
            <span style="background: #fff; padding: 0 10px; font-size: 10px; position: relative; top: -8px;">CUT HERE</span>
        </div>

        {{-- <div class="section-header">FOR OFFICE OFFICIAL USE</div> --}}
        <div class="section-header">PAYMENT RECEIVED DETAILS (FOR OFFICE OFFICIAL USE)</div>

        <table class="data-table">
            <thead>
                <tr>
                    <th width="40%">DEPARTMENT</th>
                    <th width="20%">TOTAL BILL</th>
                    <th width="40%">RECEIVED AMOUNT</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Hospital</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Pharmacy</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Pathology</td>
                    <td></td>
                    <td></td>
                </tr>
                <tr>
                    <td>Any Other (If any)</td>
                    <td></td>
                    <td></td>
                </tr>
            </tbody>
        </table>

        <div class="signature-box">
            {{-- <div class="signature-item">Patient/Guardian's Signature</div> --}}
            <div class="signature-item">Verified By</div>
            <div class="signature-item">Approved By</div>
        </div>

    </div>
</body>
<script>
    window.onload = function() {
        window.print();
    };
</script>
</html>