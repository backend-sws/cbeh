<!DOCTYPE html>
<html>
<head>
    <title>POS Label - {{ $ipdPatient->ipd_no }}</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Arial', sans-serif;
            background-color: #fff;
            padding: 0;
            margin: 0;
        }

        @media print {
            @page {
                size: 2in 1in;
                margin: 0;
                padding: 0;
            }
            
            body {
                margin: 0;
                padding: 0;
            }
            
            .pos-label {
                margin: 0;
                padding: 0;
            }
        }

        .pos-label {
            width: 2in;
            height: 1in;
            padding: 5px;
            font-size: 8px;
            line-height: 1.15;
            font-family: 'Arial', sans-serif;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            background: #fff;
            text-align: center;
        }

        .label-header {
            border-bottom: 1px solid #000;
            padding-bottom: 3px;
            margin-bottom: 3px;
        }

        .label-row {
            display: flex;
            margin-bottom: 1px;
            width: 100%;
            font-size: 7.5px;
            justify-content: center;
        }

        .label-field {
            font-weight: normal;
            margin-right: 2px;
            color: #000;
        }

        .label-value {
            word-break: break-word;
            color: #000;
        }

        .label-name {
            font-weight: bold;
            font-size: 8.5px;
            margin: 1px 0;
        }

        .hospital-name {
            text-align: center;
            font-weight: bold;
            font-size: 6px;
            padding-bottom: 1px;
            margin-bottom: 2px;
        }

        .bottom-section {
            display: flex;
            font-size: 7px;
            padding-top: 2px;
            justify-content: center;
        }

        .bottom-item {
            flex: 1;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="pos-label">
   
        <!-- Main Content -->
        <div>
            <!-- UHID -->
            <div class="label-row">
                <span class="label-field">UHID:</span>
                <span class="label-value">{{ $uhid ?? 'N/A' }}</span>
            </div>

            <!-- Admission No -->
            <div class="label-row">
                <span class="label-field">ADMISSION NO:</span>
                <span class="label-value">{{ $ipdPatient->ipd_no ?? 'N/A' }}</span>
            </div>

            <!-- Name -->
            <div class="label-row label-name">
                  <span class="label-field">NAME:</span>
                <span class="label-value">{{ strtoupper($user->name ?? 'N/A') }}</span>
            </div>

            <!-- Gender -->
            <div class="label-row flex">
                <span class="label-field">GENDER:</span>
                <span class="label-value">{{ $ipdPatient->patient->gender ?? 'N/A' }}</span>
                 <span class="label-field">AGE:</span>
                <span class="label-value">{{ $ipdPatient->patient->age ?? 'N/A' }}</span>
            </div>

            <!-- Admission Date with Time -->
            <div class="label-row">
                <span class="label-field">ADMISSION DATE:</span>
                <span class="label-value">{{ $ipdPatient->admission_date ? \Carbon\Carbon::parse($ipdPatient->admission_date)->format('d/m/Y H:i') : 'N/A' }}</span>
            </div>
      

 
            <div class="label-row">
                <span class="label-field">MOBILE NO:</span>
                <span class="label-value">{{ $user->phone ?? 'N/A' }}</span>
            </div>
   
    </div>

    <script>
        // Auto-print on page load
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>
