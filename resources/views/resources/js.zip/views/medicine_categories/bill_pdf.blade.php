<!DOCTYPE html>
<html>

<head>
    <title>Medicine Bill - {{ $bill->bill_number }}</title>
    <style>
        /* --- Base Settings --- */
        html,
        body {
            margin: 0;
            padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            background: #f3f4f6;
            color: #222;
            line-height: 1.3;
        }

        .page-container {
            width: 750px;
            margin: 0 auto;
            background: #fff;
            min-height: 100vh;
            padding: 20px 40px;
            box-sizing: border-box;
            display: flex;
            flex-direction: column;
            position: relative;
        }

        .header-table {
            width: 100%;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 5px 8px;
            border: 1px solid #333;
            width: 25%;
        }

        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        .charges-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
            margin-bottom: 20px;
        }

        .charges-table th,
        .charges-table td {
            border: 1px solid #ccc;
            padding: 6px;
            text-align: right;
        }

        .charges-table th {
            background: #c2bebe;
            text-align: center;
            font-weight: bold;
            color: #1e293b;
        }

        .charges-table td:nth-child(2) {
            text-align: left;
        }

        /* --- LAYOUT FOR SUMMARY & QR --- */
        .summary-container {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-top: 10px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }

        .left-section {
            width: 45%; /* Thoda adjust kiya taaki text na kate */
            text-align: center;
            padding-right: 10px;
        }

        .right-section {
            width: 50%;
        }

        .summary-table {
            width: 100%;
            border-collapse: collapse;
        }

        .summary-table td {
            padding: 5px;
            border-bottom: 1px solid #eee;
            text-align: right;
        }

        .total-row {
            font-weight: bold;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            font-size: 14px;
        }

        .small-points {
            font-size: 9px;
            color: #555;
            text-align: left;
            margin-top: 10px;
            line-height: 1.4;
            border: 1px solid #eee;
            padding: 8px;
            background: #f9f9f9;
            border-radius: 4px;
        }

        .signature-section {
            margin-top: 0px;
            text-align: center;
        }

        .print-btn {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            z-index: 2000;
        }

        @media print {
            body { background: #fff; }
            .print-btn { display: none; }
            .page-container { width: 100%; margin: 0; padding: 0; border: none; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
    </style>
</head>

<body>

    <button onclick="window.print()" class="print-btn">Print Bill</button>

    <div class="page-container">

        <table class="header-table">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Logo"
                        style="height:70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size:12px; color:#555;">
                        {{ setting('tagline', 'Tagline') }}<br>
                        {{ setting('address', 'Hospital Address Here') }}<br>
                        Phone: +91 {{ setting('phone', '0000000000') }}
                    </div>
                </td>
            </tr>
        </table>

        <div style="text-align:center; font-weight:bold; font-size:16px; text-decoration: underline; color: #333;">
            DEPARTMENT OF PHARMACY
        </div>
        <div style="text-align:center; font-weight:bold; font-size:14px; text-decoration:underline; color: #555; margin-bottom: 10px;">
            INVOICE
        </div>

        <table class="info-table">
            <tr>
                <td>Bill Number:</td>
                <td>{{ $bill->bill_number }}</td>
                <td>Bill Date:</td>
                <td>{{ \Carbon\Carbon::parse($bill->bill_date)->format('d-M-Y') }}</td>
            </tr>
            <tr>
                <td>Patient Name:</td>
                <td><strong>{{ $bill->patient_name }}</strong></td>
                <td>Phone:</td>
                <td>{{ $bill->patient->phone ?? 'N/A' }}</td>
            </tr>
        </table>

        <table class="charges-table">
            <thead>
                <tr>
                    <th width="5%">S.No</th>
                    <th style="text-align: left;">Product Name</th>
                    <th width="12%">Batch No</th>
                    <th width="12%">Expiry</th>
                    <th width="10%">Qty</th>
                    <th width="12%">Rate</th>
                    <th width="15%">Amount</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($bill->saleMedicine as $index => $item)
                    <tr>
                        <td style="text-align: center;">{{ $index + 1 }}</td>
                        <td><strong>{{ $item->medicine->medicine }}</strong></td>
                        <td style="text-align: center;">{{ $item->lot_no ?? '-' }}</td>
                     <td style="text-align: center;">
    {{ $item->expiry_date ? \Carbon\Carbon::parse($item->expiry_date)->format('m/y') : '-' }}
</td>
                        <td style="text-align: center;">
                            @php
                                $stripSize = (int) ($item->medicine->strip_quantity > 0 ? $item->medicine->strip_quantity : 1);
                                $unitType = $item->unit_type ?? 'strip';
                                if ($unitType == 'strip') {
                                    $stripsCount = $item->quantity / $stripSize;
                                    echo (float) $stripsCount . ' x ' . $stripSize;
                                } else {
                                    echo $item->quantity . ' (Pcs)';
                                }
                            @endphp
                        </td>
                        <td>{{ number_format($item->price, 2) }}</td>
                        <td>{{ number_format($item->amount, 2) }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="summary-container">
            
            <div class="left-section">
                @if (setting('hospital_qr'))
                    <img src="{{ asset('img/' . setting('hospital_qr')) }}" style="height: 100px; width: 100px; border: 1px solid #ddd; padding: 5px;">
                @else
                    <div style="height: 100px; width: 100px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">
                        No QR
                    </div>
                @endif
                <div style="font-weight: bold; font-size: 11px; margin-top: 5px;">Scan & Pay</div>
                
                <div class="small-points">
                    <div>* E & O.E. </div>
                    <div>* This is a System Generated Receipt. </div>
                    <div>* This receipt is not Valid for Medico-legal Purpose. </div>
                    <div>* All Legal Claims are Subject to Patna Jurisdiction Only. </div>
                </div>
            </div>

            <div class="right-section">
                <table class="summary-table">
                    <tr>
                        <td>Sub Total:</td>
                        <td>₹ {{ number_format($bill->total, 2) }}</td>
                    </tr>
                    @if ($bill->tax_amount > 0)
                        <tr>
                            <td>Total Tax:</td>
                            <td>+ ₹ {{ number_format($bill->tax_amount, 2) }}</td>
                        </tr>
                    @endif
                    @if ($bill->discount > 0)
                        <tr>
                            <td>Discount:</td>
                            <td>- ₹ {{ number_format($bill->discount, 2) }}</td>
                        </tr>
                    @endif

                    @php
                        $rawTotal = $bill->total + $bill->tax_amount - $bill->discount;
                        $roundedTotal = round($rawTotal);
                        $roundOff = $roundedTotal - $rawTotal;
                    @endphp

                    @if(abs($roundOff) > 0)
                    <tr>
                        <td>Round Off:</td>
                        <td>
                            {{ $roundOff > 0 ? '+' : '-' }} ₹ {{ number_format(abs($roundOff), 2) }}
                        </td>
                    </tr>
                    @endif

                    <tr class="total-row">
                        <td style="border:none;">Net Amount:</td>
                        <td style="border:none;">₹ {{ number_format($roundedTotal, 2) }}</td>
                    </tr>

                    <tr><td colspan="2" style="height: 5px;"></td></tr>

                    {{-- Payment Status --}}
                    @php
                        $paidTotal = $bill->paid_cash + $bill->paid_online;
                        $balance = $roundedTotal - $paidTotal;
                    @endphp

                    @if ($bill->paid_cash > 0)
                        <tr><td>Paid (Cash):</td><td>₹ {{ number_format($bill->paid_cash, 2) }}</td></tr>
                    @endif
                    @if ($bill->paid_online > 0)
                        <tr><td>Paid (Online):</td><td>₹ {{ number_format($bill->paid_online, 2) }}</td></tr>
                    @endif

                    @if ($balance > 0.9)
                        <tr><td style="color:red; font-weight:bold;">Balance Due:</td><td style="color:red; font-weight:bold;">₹ {{ number_format($balance, 2) }}</td></tr>
                    @else
                        <tr><td colspan="2" style="text-align:center; background:#e6fffa; color:#047857; font-weight:bold; padding:8px;">PAID FULLY</td></tr>
                    @endif
                </table>
            </div>
        </div>

        <div class="signature-section">
            <div style="float: right; width: 200px;">
                <div style="height: 40px;"></div>
                <div style="border-top:1px solid #333;"></div>
                <div style="font-size:11px; margin-top:3px;">Authorized Signature</div>
            </div>
            <div style="clear: both;"></div>
        </div>

        <div style="padding-top:10px; margin-top: auto; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
            <div style="font-size: 20px; color: #000; font-family: 'Monotype Corsiva', cursive; font-style: italic;">
                Thank you for Payment. Visit Again!
            </div>
        </div>

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>