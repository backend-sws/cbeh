<!DOCTYPE html>
<html>

<head>
    <title>Payment Receipt - #{{ $payment->id }}</title>
    <style>
        /* Base Settings */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            background: #fff;
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 750px;
            margin: 0 auto;
            background: #fff;
            padding: 24px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            box-sizing: border-box;
            border: 1px solid #eee; /* Light border for screen view */
        }

        /* Wrappers to push footer down */
        .bill-content { flex: 1; }
        .bill-footer { margin-top: auto; }

        /* --- Header Styles --- */
        .section-title {
            font-size: 14px;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
        }

        /* --- Info Tables --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 10px;
            border: 1px solid #333;
        }
        .info-table td {
            padding: 6px 8px;
            vertical-align: top;
            border: 1px solid #333;
            width: 25%;
        }
        .info-table td:nth-child(odd) {
            background-color: #f9f9f9;
            font-weight: bold;
            color: #444;
        }

        /* --- Items Table --- */
        .items-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 12px;
        }
        .items-table th, .items-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        .items-table th {
            background: #c2bebe;
            font-weight: bold;
            color: #1e293b;
            text-align: center;
        }
        .items-table td:last-child {
            text-align: right;
            font-weight: bold;
        }

        /* --- Summary Table --- */
        .summary-table {
            width: 50%;
            margin-left: auto;
            margin-top: 15px;
            border-collapse: collapse;
        }
        .summary-table td {
            padding: 6px;
            border-bottom: 1px solid #eee;
            text-align: right;
        }
        .total-row {
            font-weight: bold;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            font-size: 14px;
        }

        /* --- Footer Split (QR & Sign) --- */
        .footer-split {
            display: flex;
            justify-content: space-between;
            align-items: flex-end;
            margin-top: 40px;
            margin-bottom: 10px;
            padding-top: 15px;
        }
        .qr-section { width: 35%; text-align: center; }
        .signature-section { width: 60%; }

        .print-btn {
            margin: 20px auto;
            display: block;
            padding: 10px 25px;
            font-size: 14px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
        }

         .small-points {
            font-size: 9px;
            color: #555;
            text-align: left;
            margin-top: 5px;
            line-height: 1.4;
        }

        @media print {
            .bill-container { width: 100%; border: none; padding: 0; margin: 0; min-height: 98vh; }
            .print-btn { display: none; }
            .bill-footer { page-break-inside: avoid; }
            * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
        }
    </style>
</head>

<body>
    <div class="bill-container">

        <div class="bill-content">
            <table width="100%" style="border-bottom:2px solid {!! setting('theme_color', '#e91e63') !!}; margin-bottom:15px; padding-bottom:10px;">
                <tr>
                    <td style="width:90px; vertical-align:top;">
                        <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Logo" style="height:70px;">
                    </td>
                    <td style="text-align:right; vertical-align:top;">
                        <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                            {{ setting('hospital_name', 'Hospital Name') }}
                        </div>
                        <div style="font-size:12px; color:#555;">
                            {{ setting('tagline', 'Tagline Here') }}<br>
                            {{ setting('address', 'Address Here') }}<br>
                            Phone: +91 {{ setting('phone', '0000000000') }}<br>
                            Email: {{ setting('email', 'email@example.com') }}
                        </div>
                    </td>
                </tr>
            </table>

            <div style="text-align:center; font-weight:bold; font-size:16px; margin-bottom:15px; text-decoration:underline;">
                DEPARTMENT OF PHARMACY
            </div>
            <div style="text-align:center; font-weight:bold; font-size:16px; margin-bottom:15px; text-decoration:underline;">
                PAYMENT RECEIPT
            </div>

            <div class="section-title">Patient & Payment Details</div>
            <table class="info-table">
                <tr>
                    <td>Receipt No:</td>
                    <td>#PAY-{{ $payment->id }}</td>
                    <td>Payment Date:</td>
                    <td>{{ \Carbon\Carbon::parse($payment->payment_date)->format('d-M-Y h:i A') }}</td>
                </tr>
                <tr>
                    <td>Patient Name:</td>
                    <td>
                        {{-- Handle both specific bill patient and general IPD patient --}}
                        @if($payment->ipdPatient)
                            {{ $payment->ipdPatient->patient->name }}
                        @elseif($payment->bill)
                            {{ $payment->bill->patient_name }}
                        @else
                            N/A
                        @endif
                    </td>
                    <td>Ref / IPD No:</td>
                    <td>
                        @if($payment->medicine_bill_id)
                            Bill #{{ $payment->bill->bill_number ?? '-' }}
                        @elseif($payment->ipdPatient)
                            IPD: {{ $payment->ipdPatient->ipd_no }}
                        @endif
                    </td>
                </tr>
                <tr>
                    <td>Payment Mode:</td>
                    <td>{{ $payment->payment_mode }}</td>
                    <td>Payment Note:</td>
                    <td>{{ $payment->note ?? '-' }}</td>
                </tr>
            </table>

            <div class="section-title">Transaction Details</div>
            <table class="items-table">
                <thead>
                    <tr>
                        <th width="10%">#</th>
                        <th width="60%">Description</th>
                        <th width="30%">Paid Amount (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td style="text-align: center;">1</td>
                        <td>
                            @if($payment->medicine_bill_id)
                                Payment received for Medicine Bill #{{ $payment->bill->bill_number ?? '' }}
                            @else
                                Payment received towards IPD Pharmacy Account
                            @endif

                            @if($payment->discount && $payment->discount > 0)
                                <br><small style="color: #666;">(Includes discount of ₹{{ number_format($payment->discount, 2) }})</small>
                            @endif
                        </td>
                        <td style="font-size: 14px;">₹ {{ number_format($payment->amount, 2) }}</td>
                    </tr>
                      <tr>
                        <td colspan="7" style="text-align: left; background: #f9f9f9; font-style: italic;">
                            In words :  ({{ amountToWords($payment->amount) }} Only)
                        </td>
                    </tr>
                </tbody>
            </table>

            <div style="margin-top: 10px;">
                <table class="summary-table">
                      {{-- Show Amount in Words --}}
                    {{-- <tr>
                        <td colspan="2" style="text-align: center; font-style: italic; color: #555; padding-top: 10px;">
                            ({{ amountToWords($payment->amount) }} Only)
                        </td>
                    </tr> --}}
                    <tr class="total-row">
                        <td style="border: none;">Amount Received:</td>
                        <td style="border: none;">₹ {{ number_format($payment->amount, 2) }}</td>
                    </tr>
                    
                    <tr><td colspan="2" style="padding:10px;"></td></tr>

                    {{-- Show Bill Value ONLY if it's a specific bill payment --}}
                    @if($payment->medicine_bill_id && $payment->bill)
                        <tr>
                            <td>Total Bill Value:</td>
                            <td>₹ {{ number_format($payment->bill->net_amount, 2) }}</td>
                        </tr>
                    @endif
                    
                  
                </table>
            </div>
        </div>

        <div class="bill-footer">
            <div class="footer-split">
                <div class="qr-section">
                    @if(setting('hospital_qr'))
                        <img src="{{ asset('img/' . setting('hospital_qr')) }}" style="height: 80px; width: 80px; border: 1px solid #ddd; padding: 3px;">
                    @else
                        <div style="height: 80px; width: 80px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">No QR</div>
                    @endif
                    <div style="font-weight: bold; font-size: 12px; margin-top: 5px;">Scan & Pay</div>
                     <div class="small-points">
                        <div>* E & O.E. </div>
                        <div>* This is a System Generated Receipt. </div>
                        <div>* This receipt is not Valid for Medico-legal Purpose. </div>
                        <div>* All Legal Claims are Subject to Patna Jurisdiction Only.  </div>
                    </div>
                </div>

                <div class="signature-section">
                    <table width="100%">
                        <tr>
                            <td style="width:100%; text-align:right; padding-right: 20px;">
                                <div style="height:40px;"></div>
                                <div style="border-top:1px solid #333; width:200px; display:inline-block;"></div>
                                <div style="font-size:11px; margin-top:3px; margin-right: 40px;">Authorized Signature</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div style="padding-top:10px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
                <div style="margin-top: 5px; font-size: 20px; color: #222; font-family: 'Monotype Corsiva', cursive; font-style: italic;">
                    Thank you for Payment. Visit Again!
                </div>
            </div>

            <button onclick="window.print()" class="print-btn">Print Receipt</button>
        </div>
    </div>

    <script>
        window.onload = function() {
            window.print(); 
        };
    </script>
</body>
</html>