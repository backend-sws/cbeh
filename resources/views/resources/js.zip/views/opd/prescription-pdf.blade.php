<!DOCTYPE html>
<html>

<head>
    <title>Prescription - {{ $opd_patient->opd_no }}</title>
    <style>
        /* Base Settings */
        html,
        body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #fff;
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 700px;
            margin: 10px auto;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            position: relative;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* --- Header Styles --- */
        .header {
            display: flex;
            align-items: center;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .section-title {
            font-size: 1rem;
            font-weight: bold;
            margin-top: 5px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
        }

        /* --- Patient Info Box --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 4px 6px;
            vertical-align: top;
            border: none;
            word-wrap: break-word;
            border: 1px solid #333;
        }

        /* --- Medicine Table --- */
        .med-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        .med-table th {
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            padding: 8px;
            text-align: left;
            font-weight: bold;
            border: 1px solid #ccc;
            /* Fix for printing background colors */
            -webkit-print-color-adjust: exact; 
            print-color-adjust: exact;
        }

        .med-table td {
            padding: 8px;
            border: 1px solid #ccc;
        }

        .med-table tr:nth-child(even) {
            background-color: #f2f2f2; /* Light gray for screen */
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
        }

        /* --- VITALS TABLE SPECIFIC STYLES --- */
        .vitals-table {
            width: 100%;
            border-collapse: collapse;
            border: 1px solid #333;
            margin-bottom: 10px;
        }

        .vitals-table td {
            border: 1px solid #333;
            padding: 6px 8px;
            vertical-align: top;
        }

        .vitals-table td {
            width: auto !important;
        }

        .vitals-label {
            font-weight: bold;
            background-color: #f9f9f9;
            white-space: nowrap;
            width: 1% !important;
            -webkit-print-color-adjust: exact;
        }

        .note-box {
            background: #fdfdfd;
            border-left: 4px solid {!! setting('theme_color', '#e91e63') !!};
            padding: 10px;
            margin: 10px 0;
            font-size: 12px;
            color: #444;
        }

        /* --- Footer --- */
        .print-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            padding: 12px 25px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            z-index: 9999;
        }

        .print-btn:hover {
            opacity: 0.9;
        }

        @media print {
            .print-btn {
                display: none;
            }

            .bill-container {
                border: none;
                padding: 0;
                width: 100%;
                margin: 0;
            }

            /* --- DARKER HEADER FIX --- */
            .med-table th {
                background-color: #333 !important; /* Dark Gray Background */
                color: #fff !important; /* White Text */
                -webkit-print-color-adjust: exact; 
                print-color-adjust: exact;
                border: 1px solid #000;
            }
            
            .med-table tr:nth-child(even) {
                background-color: #e0e0e0 !important; /* Slightly darker gray for rows */
                -webkit-print-color-adjust: exact;
            }
        }
    </style>
</head>

<body>
    <div class="bill-container">

        <table width="100%"
            style="border-bottom:2px solid {!! setting('theme_color', '#e91e63') !!}; margin-bottom:15px; padding-bottom:10px;">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Hospital Logo"
                        style="height:70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                        {{ setting('hospital_name', 'Hospital Name') }}
                    </div>
                    <div style="font-size:12px; color:#555;">
                        {{ setting('address', 'Address Here') }}<br>
                        Phone: +91 {{ setting('phone', '0000000000') }}<br>
                        Website: {{ setting('website', 'www.example.com') }}
                    </div>
                </td>
            </tr>
        </table>

        <div
            style="text-align:center; font-weight:bold; font-size:16px; margin-top:45px; text-decoration: underline; color: #333;">
            OPD PRESCRIPTION
        </div>
        <div class="section-title" style="margin-top: 5px;">Patient Information</div>
        <div class="patient-info-box">
            <table class="info-table">
                <tr>
                    <td width="15%"><strong>Name:</strong></td>
                    <td colspan="3" style="font-weight: bold; font-size: 13px;">
                        {{ $opd_patient->patient->name }}
                    </td>
                </tr>
                <tr>
                    <td width="15%"><strong>OPD No:</strong></td>
                    <td width="35%">{{ $opd_patient->opd_no }}</td>
                    <td width="15%"><strong>UHID:</strong></td>
                    <td width="35%">{{ $uhid }}</td>
                </tr>
                <tr>
                    <td><strong>Age/Gender:</strong></td>
                    <td>{{ $opd_patient->patient->age ?? '-' }} / {{ $opd_patient->patient->gender ?? '-' }}</td>
                    <td><strong>Date:</strong></td>
                    <td>{{ $prescription->created_at ? \Carbon\Carbon::parse($prescription->created_at)->format('d-M-Y h:i A') : '-' }}
                    </td>
                </tr>

                <tr>
                    <td><strong>Consultant:</strong></td>
                    <td colspan="3">{{ $opd_patient->doctor->name ?? '-' }}</td>
                </tr>
            </table>
        </div>

        @php
            $spo2 = $opd_patient->spo2 ?? ($opd_patient->SpO2 ?? null);
            $hasVitals =
                $opd_patient->height ||
                $opd_patient->weight ||
                $opd_patient->blood_pressure ||
                $spo2 ||
                $opd_patient->symptoms;
        @endphp

        @if ($hasVitals)
            <div class="section-title" style="margin-top: 15px;">Clinical Vitals</div>
            <table class="vitals-table">
                @if ($opd_patient->height || $opd_patient->weight || $opd_patient->blood_pressure || $spo2)
                    <tr>
                        @if ($opd_patient->height)
                            <td class="vitals-label">Height:</td>
                            <td>{{ $opd_patient->height }} cm</td>
                        @endif

                        @if ($opd_patient->weight)
                            <td class="vitals-label">Weight:</td>
                            <td>{{ $opd_patient->weight }} kg</td>
                        @endif

                        @if ($opd_patient->blood_pressure)
                            <td class="vitals-label">BP:</td>
                            <td>{{ $opd_patient->blood_pressure }} mmHg</td>
                        @endif

                        @if ($spo2)
                            <td class="vitals-label">SpO2:</td>
                            <td>{{ $spo2 }}%</td>
                        @endif
                    </tr>
                @endif

                @if ($opd_patient->symptoms)
                    <tr>
                        <td class="vitals-label">Symptoms:</td>
                        <td colspan="10">{{ $opd_patient->symptoms }}</td>
                    </tr>
                @endif
            </table>
        @endif

        @if ($prescription->headernotes)
            <div class="section-title">Diagnosis / Advice</div>
            <div class="note-box" style="white-space: pre-wrap; word-wrap: break-word;">{!! nl2br(e($prescription->headernotes)) !!}</div>
        @endif

        @if ($prescription->medicines && count($prescription->medicines) > 0)
            <div class="section-title">Prescribed Medicines</div>
            <table class="med-table">
                <thead>
                    <tr>
                        <th width="20%">Medicine Name</th>
                        <th width="10%">Dosage</th>
                        <th width="30%">Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($prescription->medicines as $med)
                        <tr>
                            <td><strong>{{ optional($med->medicine)->medicine }}</strong></td>
                            <td>{{ $med->dosage }}</td>
                            <td>{{ $med->instructions }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        @endif

        @if ($prescription->footernotes)
            <div class="section-title">Doctor Advice</div>
            <div class="note-box" style="white-space: pre-wrap; word-wrap: break-word;">{!! nl2br(e($prescription->footernotes)) !!}</div>
        @endif

        <table width="100%" style="margin-top:auto; margin-bottom: 20px;">
            <tr>
                <td style="width:50%;">
                </td>
                <td style="width:50%; text-align:right; padding-right: 20px;">
                    <div style="height: 60px;"></div>
                    <div style="border-top:1px solid #333; width:200px; display:inline-block; margin-bottom: 5px;">
                    </div>
                    <div style="font-weight: bold; margin-right: 35px;">Consultant's Signature</div>
                </td>
            </tr>
        </table>

        <div
            style="text-align:center; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; padding-top:10px; font-size:11px; ">
            <div style="font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!};">
                For Emergency Services: +91{{ setting('phone', '0000000000') }}
            </div>
            <div>
                {{ setting('address', 'Patna: Opposite SBI, Bhootnath Road, Patna-800026') }}
            </div>
        </div>

        <button onclick="window.print()" class="print-btn">Print Prescription</button>
    </div>

    <script>
        // Uncomment next line to auto print on load
        window.onload = function() {
            window.print();
        };
    </script>
</body>

</html>

