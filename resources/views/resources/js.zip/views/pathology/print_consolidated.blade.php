<!DOCTYPE html>
<html>
<head>
    <title>IPD Pathology Statement - {{ $ipdPatient->patient->name }}</title>
    <style>
        /* --- Base Settings --- */
        html, body {
            margin: 0; padding: 0;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            background: #f3f4f6; color: #222; line-height: 1.3;
        }

        /* --- Page Layout --- */
        .page-container {
            width: 750px; margin: 0 auto; background: #fff;
            min-height: 100vh; padding: 20px 40px;
            box-sizing: border-box; display: flex; flex-direction: column;
            position: relative;
        }

        .content-wrap { flex: 1; }

        /* --- Header Styles --- */
        .header-table {
            width: 100%; border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px; margin-bottom: 15px;
        }

        /* --- Info Tables --- */
        .info-table {
            width: 100%; border-collapse: collapse; margin-bottom: 10px; border: 1px solid #333;
        }
        .info-table td {
            padding: 5px 8px; vertical-align: top; border: 1px solid #333; width: 25%;
        }
        .info-table td:nth-child(odd) {
            background-color: #f9f9f9; font-weight: bold; color: #444;
        }

        /* --- Items Table --- */
        .items-table {
            width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 11px;
        }
        .items-table th, .items-table td {
            border: 1px solid #ccc; padding: 6px; text-align: center;
        }
        .items-table th {
            background: #c2bebe; text-align: center; font-weight: bold; color: #1e293b;
        }
        .items-table td.amount-col { text-align: center; }

        /* --- Section Header --- */
        .section-header {
            font-size: 13px; font-weight: bold; 
            color: {!! setting('theme_color', '#e91e63') !!}; 
            border-bottom: 1px dashed #ccc; margin-top: 20px; margin-bottom: 5px;
            text-transform: uppercase;
        }

        /* --- Summary Table --- */
        .summary-table {
            width: 45%; margin-left: auto; border-collapse: collapse; margin-top: 15px;
        }
        .summary-table td {
            padding: 5px; border-bottom: 1px solid #eee; text-align: right;
        }
        .total-row {
            font-weight: bold; background-color: {!! setting('theme_color', '#e91e63') !!}; color: white; font-size: 13px;
        }

        /* --- Footer --- */
        .footer-split {
            display: flex; justify-content: space-between; align-items: flex-end;
            margin-top: 20px; border-top: 1px solid #eee; padding-top: 10px;
        }
        .print-btn {
            position: fixed; top: 20px; right: 20px; padding: 10px 20px;
            background-color: {!! setting('theme_color', '#e91e63') !!}; color: white;
            border: none; border-radius: 4px; cursor: pointer; z-index: 2000;
        }

        @media print {
            body { background: #fff; }
            .print-btn { display: none; }
            .page-container { height: auto; min-height: auto; }
        }
    </style>
</head>
<body>

    <button onclick="window.print()" class="print-btn">Print Statement</button>

    <div class="page-container">
        <div class="content-wrap">

            <table class="header-table">
                <tr>
                    <td style="width:90px; vertical-align:top;">
                        <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" style="height:70px;">
                    </td>
                    <td style="text-align:right; vertical-align:top;">
                        <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                            {{ setting('hospital_name', 'Hospital Name') }}
                        </div>
                        <div style="font-size:12px; color:#555;">
                              {{ setting('tagline', 'Tagline') }}<br>
                            {{ setting('address', 'Hospital Address') }}<br>
                            Phone: +91 {{ setting('phone', '0000000000') }}
                        </div>
                    </td>
                </tr>
            </table>

            <div style="text-align:center; font-weight:bold; font-size:16px; text-decoration: underline; margin-top:5px; color: #333;">
               DEPARTMENT OF PATHOLOGY
            </div>
            <div style="text-align:center; font-weight:bold; font-size:14px;  margin-top:5px; color: #333;">
                CONSOLIDATED STATEMENT
            </div>


            <div class="section-header">Patient Details</div>
            <table class="info-table">
                <tr>
                    <td>Patient Name:</td>
                    <td><strong>{{ $ipdPatient->patient->name }}</strong></td>
                    <td>IPD No:</td>
                    <td><strong>{{ $ipdPatient->ipd_no }}</strong></td>
                </tr>
                <tr>
                    <td>Age/Gender:</td>
                    <td>{{ $ipdPatient->patient->age ?? '-' }} / {{ $ipdPatient->patient->gender ?? '-' }}</td>
                    <td>Contact:</td>
                    <td>{{ $ipdPatient->patient->phone ?? '-' }}</td>
                </tr>
                <tr>
                    <td>Doctor:</td>
                    <td colspan="3">{{ $ipdPatient->doctor->name ?? '-' }}</td>
                </tr>
            </table>

            <div class="section-header">Test Charges Summary</div>
            <table class="items-table">
                <thead>
                    <tr>
                        <th >Date</th>
                        <th >Bill No</th>
                        {{-- <th >Test</th> --}}
                        <th >Amount (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($bills as $bill)
                    <tr>
                        <td>{{ \Carbon\Carbon::parse($bill->bill_date)->format('d-M-Y') }}</td>
                        <td>{{ $bill->bill_no }}</td>
                        {{-- <td>
                            <ul style="margin: 0; padding-left: 15px;">
                                @foreach($bill->tests as $testItem)
                                    <li>{{ $testItem->test->test_name ?? 'Unknown' }}</li>
                                @endforeach
                            </ul>
                        </td> --}}
                        <td class="amount-col">{{ number_format($bill->amount, 2) }}</td>
                    </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="2" style="text-align: right; font-weight: bold; background: #f0f0f0;">Total Billed Amount:</td>
                        <td class="amount-col" style="font-weight: bold; background: #f0f0f0;">₹{{ number_format($totalBill, 2) }}</td>
                    </tr>
                </tfoot>
            </table>

            <div class="section-header" style="margin-top: 25px;">Payment History</div>
            <table class="items-table">
                <thead>
                    <tr>
                        <th width="15%">Date</th>
                        <th width="15%">Receipt No</th>
                        <th width="15%">Mode</th>
                        <th width="40%">Particulars / Note</th>
                        <th width="15%">Paid (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($payments as $txn)
                    <tr>
                        <td>{{ \Carbon\Carbon::parse($txn->payment_date)->format('d-M-Y') }}</td>
                        <td>#{{ $txn->id }}</td>
                        <td>{{ $txn->payment_mode }}</td>
                        <td>{{ $txn->note ?? '-' }}</td>
                        <td class="amount-col">{{ number_format($txn->amount, 2) }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" style="text-align: center; color: #999;">No payments recorded yet.</td>
                    </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3" style="text-align: right; font-weight: bold; background: #f0f0f0;">Total Received:</td>
                        <td class="amount-col" style="font-weight: bold; background: #f0f0f0;">₹{{ number_format($totalPaid, 2) }}</td>
                    </tr>
                </tfoot>
            </table>

            <table class="summary-table">
                <tr>
                    <td>Total Charges:</td>
                    <td>₹ {{ number_format($totalBill, 2) }}</td>
                </tr>
                <tr>
                    <td> Total Paid:</td>
                    <td> ₹ {{ number_format($totalPaid, 2) }}</td>
                </tr>
                <tr >
                    <td style="border: none;">
                        @if($balance > 0) NET DUE BALANCE:
                        @else ADVANCE BALANCE:
                        @endif
                    </td>
                    <td style="border: none;">
                        ₹ {{ number_format(abs($balance), 2) }}
                    </td>
                </tr>
                
            </table>

        </div>

         <div class="page-footer">
            <div class="footer-split">
                <div class="qr-section">
                    @if(setting('hospital_qr'))
                        <img src="{{ asset('img/' . setting('hospital_qr')) }}" style="height: 80px; width: 80px; border: 1px solid #ddd; padding: 3px;">
                    @else
                        <div style="height: 80px; width: 80px; border: 1px dashed #ccc; display:flex; align-items:center; justify-content:center; margin:0 auto; color:#999; font-size:10px;">No QR</div>
                    @endif
                    <div style="font-weight: bold; font-size: 12px; margin-top: 5px; color: #333;">Scan & Pay</div>
                    <div class="small-points">
                       <div>* E & O.E. </div>
                        <div>* This is a System Generated Receipt. </div>
                        <div>* This receipt is not Valid for Medico-legal Purpose. </div>
                        <div>* All Legal Claims are Subject to Patna Judicial Only.  </div>
                    </div>
                </div>

                <div class="signature-section">
                    <table width="100%">
                        <tr>
                            <td style="width:50%; text-align:center; border:none;">
                                <div style="height:30px;"></div>
                                <div style="border-top:1px solid #333; width:60%; margin:0 auto;"></div>
                                <div style="font-size:11px; margin-top:3px;">Authorized Signature</div>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <div style="padding-top:5px; margin-top: 10px; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; font-size:11px; text-align:center; color:#555;">
                <div style="margin-top: 2px; font-size: 18px; color: #000000; font-family: 'Monotype Corsiva', cursive; font-style: italic;">
                    Get Well Soon!
                </div>
            </div>
        </div>

    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>