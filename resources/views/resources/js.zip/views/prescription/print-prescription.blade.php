<!DOCTYPE html>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Prescription - {{ $prescription->patient->name }}</title>
    <style>
        /* Base Settings */
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            font-size: 12px;
            background: #fff;
            color: #222;
            line-height: 1.3;
        }

        .bill-container {
            width: 700px;
            margin: 10px auto;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 20px;
            position: relative;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* --- Header Styles --- */
        .header {
            display: flex;
            align-items: center;
            border-bottom: 2px solid {!! setting('theme_color', '#e91e63') !!};
            padding-bottom: 10px;
            margin-bottom: 15px;
        }

        .section-title {
            font-size: 1rem;
            font-weight: bold;
            margin-top: 15px;
            margin-bottom: 5px;
            color: {!! setting('theme_color', '#e91e63') !!};
            border-bottom: 1px dashed #ccc;
            padding-bottom: 3px;
        }

        /* --- Patient Info Box --- */
        .info-table {
            width: 100%;
            border-collapse: collapse;
            table-layout: fixed;
            border: 1px solid #333;
        }

        .info-table td {
            padding: 4px 6px;
            vertical-align: top;
            border: none;
            word-wrap: break-word;
            border: 1px solid #333;
        }

        /* --- Medicine Table --- */
        .med-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            font-size: 11px;
        }

        /* --- UPDATED HEADER STYLE (Light Gray) --- */
        .med-table th {
            background-color: #b5b1b1 !important; /* Light Gray */
            color: #1e293b !important; /* Dark Text */
            padding: 8px;
            text-align: left;
            font-weight: bold;
            border: 1px solid #ccc; 
        }

        .med-table td {
            padding: 8px;
            border: 1px solid #ccc;
        }

      

        /* --- Note Box --- */
        .note-box {
            background: #fdfdfd;
            border-left: 4px solid {!! setting('theme_color', '#e91e63') !!};
            padding: 10px;
            margin: 10px 0;
            font-size: 12px;
            color: #444;
        }

        /* --- Footer --- */
        .print-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            padding: 12px 25px;
            background-color: {!! setting('theme_color', '#e91e63') !!};
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
            z-index: 9999;
        }

        /* --- PRINT MEDIA QUERY --- */
        @media print {
            .print-btn { display: none; }

            .bill-container {
                border: none;
                padding: 0;
                width: 100%;
                margin: 0;
            }

            /* Medicine Table Fixes for Print */
            .med-table th {
                -webkit-print-color-adjust: exact !important;
                print-color-adjust: exact !important;
                background-color: #ccc !important; /* Force Light Gray */
                color: #000 !important; /* Force Black Text */
                border: 1px solid #000 !important; /* Black Border */
            }

            .med-table td {
                border: 1px solid #000 !important;
            }
            
            .info-table, .info-table td {
                border: 1px solid #000 !important;
            }
        }
    </style>
</head>

<body>
    <div class="bill-container">
        <table width="100%"
            style="border-bottom:2px solid {!! setting('theme_color', '#e91e63') !!}; margin-bottom:15px; padding-bottom:10px; ">
            <tr>
                <td style="width:90px; vertical-align:top;">
                    <img src="{{ asset('img/' . setting('logo', 'img/patnalogo.jpeg')) }}" alt="Hospital Logo"
                        style="height:70px;">
                </td>
                <td style="text-align:right; vertical-align:top;">
                    <div style="font-size:18px; font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!}; margin-bottom:5px;">
                        {{ setting('hospital_name', 'Hospital') }}
                    </div>
                    <div style="font-size:12px; color:#555;">
                        {{ setting('address', 'Address') }}<br>
                        Phone: +91 {{ setting('phone', '0000000000') }}, {{ setting('mobile', '0000000000') }}<br>
                        Website: {{ setting('website', 'www.patliputranetralaya.in') }}
                    </div>
                </td>
            </tr>
        </table>

        <div style="text-align:center; font-weight:bold; font-size:16px; margin-top:50px; text-decoration:underline;">
            PRESCRIPTION
        </div>

        <div class="section-title" style="margin-top: 5px;">Patient Information</div>
        <div class="patient-info-box">
            <table class="info-table">
                <tr>
                    <td width="15%"><strong>Name:</strong></td>
                    <td colspan="3" style="font-weight: bold; font-size: 13px;">
                        {{ $prescription->patient->name ?? 'N/A' }}
                    </td>
                </tr>
                <tr>
                    <td width="15%"><strong>Age/Gender:</strong></td>
                    <td width="35%">
                        {{ $prescription->patient->age ?? 'N/A' }} Years /
                        {{ $prescription->patient->gender ?? 'N/A' }}
                    </td>
                    <td width="15%"><strong>UHID:</strong></td>
                    <td width="35%">{{ $uhid ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td><strong>Phone:</strong></td>
                    <td>{{ $prescription->patient->phone ?? '' }}</td>
                    <td width="15%"><strong>Bed:</strong></td>
                    <td width="35%">{{ $beds->beds->name ?? 'N/A' }}</td>
                </tr>
                <tr>
                    <td width="15%"><strong>D.O.A:</strong></td>
                    <td width="35%">{{ $beds->admission_date ?? 'N/A' }}</td>
                    <td><strong>Date:</strong></td>
                    <td>
                        @if ($prescription->prescription_date)
                            {{ \Carbon\Carbon::parse($prescription->prescription_date)->format('d-M-Y') }}
                        @else
                            {{ \Carbon\Carbon::parse($prescription->created_at)->format('d-M-Y h:i A') }}
                        @endif
                    </td>
                </tr>
                <tr>
                    <td><strong>Consultant:</strong></td>
                    <td colspan="3">{{ $prescription->doctor->name ?? '' }}</td>
                </tr>
            </table>
        </div>

        @if ($prescription->headernotes)
            <div class="section-title">Doctor Notes</div>
            <div class="note-box" style="white-space: pre-wrap; word-wrap: break-word;">{!! nl2br(e($prescription->headernotes)) !!}</div>
        @endif

        @if ($prescription->medicines && count($prescription->medicines) > 0)
            <div class="section-title">Prescribed Medicines</div>
            <table class="med-table">
                <thead>
                    <tr>
                        <th width="5%">#</th>
                        <th width="25%">Medicine Name</th>
                        <th width="10%">Dosage</th>
                        <th width="10%">Remarks</th>
                    </tr>
                </thead>
                <tbody>
                    @php $counter = 1; @endphp
                    @if (isset($prescription->medicines) && count($prescription->medicines) > 0)
                        @foreach ($prescription->medicines as $med)
                            <tr>
                                <td>{{ $counter++ }}</td>
                                <td>
                                    <strong>{{ $med->medicine->medicine ?? 'N/A' }}</strong>
                                </td>
                                <td>{{ $med->dosage ?? 'N/A' }}</td>
                                {{-- <td>
                                    @php
                                        $times = [
                                            '0' => 'After food',
                                            '1' => 'Before food',
                                            '2' => 'Bed Time',
                                        ];
                                        echo $times[$med->time] ?? $med->time;
                                    @endphp
                                </td> --}}
                                <td>{{ $med->instructions ?? 'N/A' }}</td>
                            </tr>
                        @endforeach
                    @else
                        <tr>
                            <td colspan="4" style="text-align:center; color:#888; padding: 15px;">
                                No medicines prescribed.
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
        @endif

        @if ($prescription->footernotes)
            <div class="section-title">Investigation Advice</div>
            <div class="note-box" style="white-space: pre-wrap; word-wrap: break-word;">{!! nl2br(e($prescription->footernotes)) !!}</div>
        @endif

        <table width="100%" style="margin-top:auto; margin-bottom: 20px;">
            <tr>
                <td style="width:50%; text-align: center;"></td>
                <td style="width:50%; text-align:right; padding-right: 20px;">
                    <div style="height: 60px;"></div>
                    <div style="border-top:1px solid #333; width:200px; display:inline-block; margin-bottom: 5px;"></div>
                    <div style="font-weight: bold; margin-right: 35px;">Consultant's Signature</div>
                </td>
            </tr>
        </table>

        <div style="text-align:center; border-top:1px dashed {!! setting('theme_color', '#e91e63') !!}; padding-top:10px; font-size:11px; visibility: hidden;">
            <div style="font-weight:bold; color:{!! setting('theme_color', '#e91e63') !!};">
                For Emergency Services: +91{{ setting('phone', '0000000000') }}, {{ setting('mobile', '0000000000') }}
            </div>
            <div>
                {{ setting('address', 'Patna: Opposite SBI, Bhootnath Road, Patna-800026') }}
            </div>
            <div>
                Website: <a href="{{ setting('website', 'https://www.patliputranetralaya.in/') }}"
                    style="color:{!! setting('theme_color', '#e91e63') !!}; text-decoration:none;">
                    {{ setting('website', 'www.patliputranetralaya.in') }}
                </a>
            </div>
        </div>

        <button onclick="window.print()" class="print-btn">Print Prescription</button>
    </div>

    <script>
        window.onload = function() {
            window.print();
        };
    </script>
</body>
</html>