@extends('layouts.admin')

@section('title', 'System Settings')

@section('content')
    <div class=" mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div class="bg-white shadow rounded-lg overflow-hidden">

            @if (session('success'))
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4"
                    role="alert">
                    <strong class="font-bold">Success!</strong>
                    <span class="block sm:inline">{{ session('success') }}</span>
                </div>
            @endif

            @if (session('error'))
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <strong class="font-bold">Error!</strong>
                    <span class="block sm:inline">{{ session('error') }}</span>
                </div>
            @endif
            <div class="px-6 py-4 border-b border-gray-200">
                <h2 class="text-xl font-semibold text-gray-800">Hospital Settings</h2>
                <p class="mt-1 text-sm text-gray-600">Manage your hospital's basic information and appearance</p>
            </div>

            <form action="{{ route('admin.hospital-web-settings.update') }}" method="POST"
                enctype="multipart/form-data" class="divide-y divide-gray-200">
                @csrf

                <div class="px-6 py-4">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">General Information</h3>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label for="hospital_name" class="block text-sm font-medium text-gray-700 mb-1">Hospital
                                Name *</label>
                            <input type="text" id="hospital_name" name="hospital_name"
                                value="{{ setting('hospital_name') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500"
                                required>
                        </div>

                        <div>
                            <label for="tagline" class="block text-sm font-medium text-gray-700 mb-1">Tagline / Certification</label>
                            <input type="text" id="tagline" name="tagline" value="{{ setting('tagline') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500"
                                placeholder="e.g. ISO 9001:2015 Certified">
                        </div>

                        <div class="md:col-span-2">
                            <label for="address" class="block text-sm font-medium text-gray-700 mb-1">Address</label>
                            <input type="text" id="address" name="address" value="{{ setting('address') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500">
                        </div>

                        <div>
                            <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                            <input type="email" id="email" name="email" value="{{ setting('email') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500">
                        </div>

                        <div>
                            <label for="website" class="block text-sm font-medium text-gray-700 mb-1">Website</label>
                            <input type="text" id="website" name="website" value="{{ setting('website') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500">
                        </div>

                        <div>
                            <label for="phone" class="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                            <input type="text" id="phone" name="phone" value="{{ setting('phone') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500">
                        </div>

                        <div>
                            <label for="mobile" class="block text-sm font-medium text-gray-700 mb-1">Mobile</label>
                            <input type="text" id="mobile" name="mobile" value="{{ setting('mobile') }}"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500">
                        </div>

                        <div>
                            <label for="free_visit_day" class="block text-sm font-medium text-gray-700 mb-1">Free Visit Day</label>
                            <input type="number" id="free_visit_day" name="free_visit_day" 
                                value="{{ setting('free_visit_day', 1) }}"
                                min="1" max="30"
                                class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-pink-500 focus:border-pink-500"
                                placeholder="Enter number of days ">
                        </div>
                    </div>
                </div>

                <div class="px-6 py-4">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Hospital Logo</h3>

                    <div class="flex items-center">
                        <div class="mr-6">
                            <p class="text-sm font-medium text-gray-700 mb-2">Current Logo</p>
                            @if (setting('logo'))
                                <img src="{{ asset('img/' . setting('logo')) }}" alt="Hospital Logo"
                                    class="h-16 w-auto object-contain">
                            @else
                                <div
                                    class="h-16 w-16 bg-gray-200 rounded flex items-center justify-center text-gray-400">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                    </svg>
                                </div>
                            @endif
                        </div>

                        <div class="flex-1">
                            <label for="logo" class="block text-sm font-medium text-gray-700 mb-1">Upload New
                                Logo</label>
                            <div class="mt-1 flex items-center">
                                <input type="file" id="logo" name="logo"
                                    class="block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-md file:border-0
                                file:text-sm file:font-semibold
                                file:bg-pink-50 file:text-pink-700
                                hover:file:bg-pink-100">
                            </div>
                            <p class="mt-1 text-xs text-gray-500">PNG, JPG, GIF up to 2MB</p>
                        </div>
                    </div>
                </div>

                <div class="px-6 py-4 border-t border-gray-200">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Payment QR Code</h3>

                    <div class="flex items-center">
                        <div class="mr-6">
                            <p class="text-sm font-medium text-gray-700 mb-2">Current QR</p>
                            @if (setting('hospital_qr'))
                                <img src="{{ asset('img/' . setting('hospital_qr')) }}" alt="Payment QR"
                                    class="h-24 w-auto object-contain border border-gray-200 rounded p-1">
                            @else
                                <div
                                    class="h-24 w-24 bg-gray-200 rounded flex items-center justify-center text-gray-400">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none"
                                        viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M12 4v1m6 11h2m-6 0h-2v4h2v-4zM6 6h6v6H6V6zm12 0h-6v6h6V6zm-6 12H6v-6h6v6z" />
                                    </svg>
                                </div>
                            @endif
                        </div>

                        <div class="flex-1">
                            <label for="hospital_qr" class="block text-sm font-medium text-gray-700 mb-1">Upload New QR Code</label>
                            <div class="mt-1 flex items-center">
                                <input type="file" id="hospital_qr" name="hospital_qr"
                                    class="block w-full text-sm text-gray-500
                                file:mr-4 file:py-2 file:px-4
                                file:rounded-md file:border-0
                                file:text-sm file:font-semibold
                                file:bg-pink-50 file:text-pink-700
                                hover:file:bg-pink-100">
                            </div>
                            <p class="mt-1 text-xs text-gray-500">PNG, JPG, GIF (Recommended size: 300x300px)</p>
                        </div>
                    </div>
                </div>

                <div class="px-6 py-4">
                    <h3 class="text-lg font-medium text-gray-900 mb-4">Theme Settings</h3>

                    <div>
                        <label for="theme_color" class="block text-sm font-medium text-gray-700 mb-1">Theme
                            Color</label>
                        <div class="flex items-center">
                            <input type="color" id="theme_color" name="theme_color"
                                value="{{ setting('theme_color', '#3B82F6') }}"
                                class="h-10 w-10 rounded border border-gray-300 cursor-pointer">
                            <span class="ml-3 text-sm text-gray-600">Click to select a color</span>
                        </div>
                    </div>
                </div>

                <div class="px-6 py-4 bg-gray-50 text-right">
                    <button type="submit"
                        class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-pink-600 hover:bg-pink-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500">
                        Save Settings
                    </button>
                </div>
            </form>
        </div>
    </div>
@endsection